#!/bin/bash
cd "$(dirname "$0")"
echo "Starting BizFlow POS..."
java -Xmx1024m -Dfile.encoding=UTF-8 -jar BizFlow-POS.jar "$@"
