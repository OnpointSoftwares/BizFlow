# BizFlow POS - Linux Installation Guide

This guide explains how to install and run BizFlow POS on Linux systems.

## Requirements
- Java Runtime Environment (JRE) 11 or later
- Debian/Ubuntu: Optionally `dpkg-deb` for installing `.deb` packages

## Option 1: Install from .deb (Debian/Ubuntu)
1. Install the package:
   ```bash
   sudo dpkg -i bizflow-pos_1.0.0_all.deb
   sudo apt-get -f install  # if dependencies are missing
   ```
2. Launch the application:
   ```bash
   bizflow-pos
   ```
   or from the Applications menu as "BizFlow POS".

## Option 2: Portable TAR.GZ
1. Extract the archive:
   ```bash
   tar -xzf BizFlow-POS-Linux-1.0.0.tar.gz
   cd BizFlow-POS-Linux
   ```
2. Run the application:
   ```bash
   ./run-linux.sh
   ```

## Option 3: Installer Script
From the project root (or the `dist/BizFlow-POS-Linux` folder), run:
```bash
sudo ./installer/install-linux.sh
```
This installs to `/opt/bizflow-pos` and creates a launcher `bizflow-pos`.

## Default Credentials
- Username: `admin`
- Password: `admin123`

## Data Files
- `pos.db` (SQLite database)
- `settings.properties`

These files are located in the application directory and may be modified by the application.

## Uninstall (.deb)
```bash
sudo apt remove bizflow-pos
```

## Troubleshooting
- Ensure Java 11+ is installed:
  ```bash
  java -version
  ```
- If the app fails to launch, run from terminal to view logs:
  ```bash
  bizflow-pos
  ```
- On some desktops, you may need to refresh the applications database:
  ```bash
  sudo update-desktop-database /usr/share/applications/
  ```
