#!/bin/bash
echo "Starting BizFlow POS..."
java -Xmx1024m -Dfile.encoding=UTF-8 -jar BizFlow-POS.jar
