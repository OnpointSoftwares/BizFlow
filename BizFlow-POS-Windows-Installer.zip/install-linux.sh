#!/bin/bash
set -e
cd "$(dirname "$0")"

APP_DIR="/opt/bizflow-pos"
BIN_LINK="/usr/local/bin/bizflow-pos"
DESKTOP_FILE="/usr/share/applications/bizflow-pos.desktop"
ICON_PATH="/usr/share/pixmaps/bizflow-pos.xpm"

echo "Installing BizFlow POS..."

# Create app directory
sudo mkdir -p "$APP_DIR"

# Copy files
sudo cp -r ../dist/BizFlow-POS-Linux/* "$APP_DIR/"

# Create launcher
sudo bash -c "cat > $BIN_LINK" << 'EOF'
#!/bin/bash
cd /opt/bizflow-pos
exec java -Xmx1024m -Dfile.encoding=UTF-8 -jar BizFlow-POS.jar "$@"
EOF
sudo chmod 755 "$BIN_LINK"

# Create desktop entry
sudo bash -c "cat > $DESKTOP_FILE" << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=BizFlow POS
Comment=Professional Point of Sale System
Exec=/usr/local/bin/bizflow-pos
Icon=bizflow-pos
Terminal=false
Categories=Office;Finance;
StartupNotify=true
EOF

# Create simple icon (placeholder)
sudo bash -c "cat > $ICON_PATH" << 'EOF'
/* XPM */
static char * bizflow_pos_xpm[] = {
"32 32 3 1",
" \tc None",
".\tc #1E88E5",
"+\tc #FFFFFF",
"                                ",
"  ..............................",
"  .++++++++++++++++++++++++++++.",
"  .+         BizFlow          +.",
"  .+            POS           +.",
"  .++++++++++++++++++++++++++++.",
"  ..............................",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                "};
EOF

# Permissions for writable files
sudo chmod 666 "$APP_DIR/pos.db" 2>/dev/null || true
sudo chmod 666 "$APP_DIR/settings.properties" 2>/dev/null || true

# Update desktop database if present
if command -v update-desktop-database >/dev/null 2>&1; then
  sudo update-desktop-database /usr/share/applications/ 2>/dev/null || true
fi

echo "Installation complete. Run: bizflow-pos"
