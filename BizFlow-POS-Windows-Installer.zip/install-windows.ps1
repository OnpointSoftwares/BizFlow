# BizFlow POS - Windows Installer Script
# Run in PowerShell as Administrator

$ErrorActionPreference = 'Stop'

$AppName = 'BizFlow POS'
$Company = 'BizFlow'
$InstallDir = Join-Path ${env:ProgramFiles} 'BizFlow POS'
$ShortcutDir = Join-Path ${env:ProgramData} 'Microsoft\Windows\Start Menu\Programs'
$DesktopDir = [Environment]::GetFolderPath('Desktop')

Write-Host 'Installing BizFlow POS...' -ForegroundColor Cyan

# Ensure running as admin
$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Error 'Please run this script as Administrator.'
}

# Create install directory
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

# Copy files from this script location
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item -Path (Join-Path $ScriptDir 'BizFlow-POS.jar') -Destination $InstallDir -Force
Copy-Item -Path (Join-Path $ScriptDir 'README.md') -Destination $InstallDir -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $ScriptDir 'settings.properties') -Destination $InstallDir -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $ScriptDir 'pos.db') -Destination $InstallDir -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $ScriptDir 'lib') -Destination $InstallDir -Recurse -Force

# Create launcher batch
$LauncherBat = @" 
@echo off
cd /d "%~dp0"
java -Xmx1024m -Dfile.encoding=UTF-8 -jar BizFlow-POS.jar %*
"@
Set-Content -LiteralPath (Join-Path $InstallDir 'run.bat') -Value $LauncherBat -Encoding ASCII

# Create Start Menu shortcut
$Shell = New-Object -ComObject WScript.Shell
$LnkPath = Join-Path $ShortcutDir "$AppName.lnk"
$Shortcut = $Shell.CreateShortcut($LnkPath)
$Shortcut.TargetPath = (Join-Path $InstallDir 'run.bat')
$Shortcut.WorkingDirectory = $InstallDir
$Shortcut.WindowStyle = 1
$Shortcut.IconLocation = "$env:SystemRoot\\System32\\shell32.dll, 221"
$Shortcut.Description = 'Professional Point of Sale System'
$Shortcut.Save()

# Create Desktop shortcut
$DeskLink = Join-Path $DesktopDir "$AppName.lnk"
$Shortcut = $Shell.CreateShortcut($DeskLink)
$Shortcut.TargetPath = (Join-Path $InstallDir 'run.bat')
$Shortcut.WorkingDirectory = $InstallDir
$Shortcut.WindowStyle = 1
$Shortcut.IconLocation = "$env:SystemRoot\\System32\\shell32.dll, 221"
$Shortcut.Description = 'Professional Point of Sale System'
$Shortcut.Save()

Write-Host 'Installation completed.' -ForegroundColor Green
Write-Host 'Launch from Start Menu or Desktop: BizFlow POS'
