#!/usr/bin/env bash
set -euo pipefail
if [ ! -d lib ]; then
  echo "lib/ not found. Create it and place sqlite-jdbc-<version>.jar (and optional jars) inside." >&2
  exit 1
fi
java -cp "out:lib/*" pos.Main
