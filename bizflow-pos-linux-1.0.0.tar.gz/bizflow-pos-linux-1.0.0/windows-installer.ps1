# PowerShell script for Windows installation
# Run this as Administrator for best results

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "This script requires Administrator privileges. Restarting with elevated permissions..." -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -File `"{0}"" -f $PSCommandPath)
    exit
}

# Set error action preference
$ErrorActionPreference = "Stop"

# Configuration
$appName = "BizFlow POS"
$installDir = "$env:ProgramFiles\$appName"
$desktopDir = [Environment]::GetFolderPath("Desktop")
$startMenuDir = [Environment]::GetFolderPath("Programs") + "\$appName"
$javaUrl = "https://download.java.com/java/GA/jdk11/9/GPL/openjdk-11.0.2_windows-x64_bin.zip"

Write-Host "=== $appName Installer ===" -ForegroundColor Cyan

# Check if Java 11+ is installed
Write-Host "Checking Java installation..." -NoNewline
$javaVersion = (java -version 2>&1 | Select-String -Pattern 'version' | Select-Object -First 1).ToString().Split('"')[1]

if ($javaVersion -and [System.Version]($javaVersion.Split('-')[0]) -ge [System.Version]"11.0.0") {
    Write-Host " Java $javaVersion is already installed" -ForegroundColor Green
} else {
    Write-Host " Java 11+ not found. Installing OpenJDK 11..." -ForegroundColor Yellow
    
    # Download and install Java
    $tempDir = "$env:TEMP\java_install"
    New-Item -ItemType Directory -Force -Path $tempDir | Out-Null
    $javaZip = "$tempDir\openjdk11.zip"
    
    Write-Host "Downloading OpenJDK 11..."
    Invoke-WebRequest -Uri $javaUrl -OutFile $javaZip
    
    Write-Host "Installing Java..."
    Expand-Archive -Path $javaZip -DestinationPath $tempDir -Force
    $javaDir = Get-ChildItem -Path $tempDir -Directory | Where-Object { $_.Name -like "jdk-11*" } | Select-Object -First 1
    
    # Add Java to PATH
    $javaBin = "$($javaDir.FullName)\bin"
    $env:Path = "$javaBin;" + $env:Path
    [Environment]::SetEnvironmentVariable("Path", $env:Path, [System.EnvironmentVariableTarget]::Machine)
    
    # Set JAVA_HOME
    [Environment]::SetEnvironmentVariable("JAVA_HOME", $javaDir.FullName, [System.EnvironmentVariableTarget]::Machine)
    $env:JAVA_HOME = $javaDir.FullName
    
    Write-Host "Java 11 installed successfully" -ForegroundColor Green
}

# Create installation directory
Write-Host "Installing $appName..."
if (Test-Path $installDir) {
    Remove-Item -Path $installDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $installDir | Out-Null

# Copy application files
Write-Host "Copying application files..."
Copy-Item -Path ".\*" -Destination $installDir -Recurse -Force

# Create desktop shortcut
Write-Host "Creating shortcuts..."
$wshShell = New-Object -ComObject WScript.Shell
$shortcut = $wshShell.CreateShortcut("$desktopDir\$appName.lnk")
$shortcut.TargetPath = "$installDir\run-pos.bat"
$shortcut.WorkingDirectory = $installDir
$shortcut.IconLocation = "$installDir\assets\icon.ico"
$shortcut.Save()

# Create start menu shortcut
if (-not (Test-Path $startMenuDir)) {
    New-Item -ItemType Directory -Force -Path $startMenuDir | Out-Null
}
$startShortcut = $wshShell.CreateShortcut("$startMenuDir\$appName.lnk")
$startShortcut.TargetPath = "$installDir\run-pos.bat"
$startShortcut.WorkingDirectory = $installDir
$startShortcut.IconLocation = "$installDir\assets\icon.ico"
$startShortcut.Save()

# Create uninstaller
$uninstallScript = @"
# Self-elevate the script if required
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"`$PSCommandPath`"" -Verb RunAs
    Exit
}

# Remove application files
Remove-Item -Path "$installDir" -Recurse -Force

# Remove shortcuts
Remove-Item -Path "$desktopDir\$appName.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "$startMenuDir\$appName.lnk" -Force -ErrorAction SilentlyContinue

# Remove from PATH (if we added it)
# Note: This is a simplified version - in production, you'd want to be more careful about modifying PATH

Write-Host "$appName has been uninstalled successfully." -ForegroundColor Green
pause
"@

Set-Content -Path "$installDir\Uninstall-$appName.ps1" -Value $uninstallScript

# Create a batch file to run the application
$runScript = @"
@echo off
setlocal
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

REM Check if Java is installed
where java >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Java is not installed or not in PATH.
    echo Please install Java 11 or later and try again.
    pause
    exit /b 1
)

REM Run the application
java -cp ".;lib\*" pos.Main %*
"@

Set-Content -Path "$installDir\run-pos.bat" -Value $runScript

# Set up the application data directory
$appDataDir = "$env:APPDATA\$appName"
if (-not (Test-Path $appDataDir)) {
    New-Item -ItemType Directory -Force -Path $appDataDir | Out-Null
}

# Set environment variable for database path
$dbPath = "$appDataDir\bizflow_pos.db"
[Environment]::SetEnvironmentVariable("BIZFLOW_DB_PATH", $dbPath, [System.EnvironmentVariableTarget]::User)

Write-Host "`n$appName has been installed successfully!" -ForegroundColor Green
Write-Host "- Location: $installDir"
Write-Host "- Database: $dbPath"
Write-Host "- Shortcut created on Desktop and in Start Menu"
Write-Host "`nYou can now run $appName from the Desktop or Start Menu." -ForegroundColor Cyan

# Offer to launch the application
$launch = Read-Host "Do you want to launch $appName now? (Y/N)"
if ($launch -eq 'Y' -or $launch -eq 'y') {
    Start-Process "$installDir\run-pos.bat"
}

Write-Host "`nInstallation complete!" -ForegroundColor Green
