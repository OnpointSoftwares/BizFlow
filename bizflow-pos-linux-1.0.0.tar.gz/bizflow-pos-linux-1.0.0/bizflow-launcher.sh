#!/bin/bash
# BizFlow POS Launcher

# Set the application directory
APP_DIR="/opt/bizflow-pos"

# Change to the application directory
cd "$APP_DIR" || { echo "Failed to change to $APP_DIR"; exit 1; }

# Set the classpath
CLASSPATH="out:lib/*"

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in PATH"
    echo "Please install Java 11 or later and try again"
    exit 1
fi

# Run the application
echo "Starting BizFlow POS..."
java -cp "$CLASSPATH" pos.Main "$@"

# If the application fails, try compiling the source
if [ $? -ne 0 ]; then
    echo "First attempt failed. Trying to compile the source..."
    
    # Check if source files exist
    if [ -d "src" ]; then
        echo "Compiling source files..."
        mkdir -p out
        javac -d out -cp "lib/*" $(find src -name "*.java")
        
        # Try running again
        echo "Starting BizFlow POS..."
        java -cp "$CLASSPATH" pos.Main "$@"
        
        if [ $? -ne 0 ]; then
            echo "Failed to start BizFlow POS. Please check the error messages above."
            exit 1
        fi
    else
        echo "Source directory not found. Please reinstall the application."
        exit 1
    fi
fi
