#!/bin/bash
set -e

# Clean previous builds
rm -rf target/
mkdir -p target/lib

# Build the project
echo "Building BizFlow POS..."
./build.sh

# Copy dependencies
cp -r lib/* target/lib/

# Create run script for Linux
echo '#!/bin/bash
# Get the directory of this script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Run the application
java -cp "$SCRIPT_DIR/target/classes:$SCRIPT_DIR/lib/*" pos.Main "$@"
' > target/run-pos.sh

chmod +x target/run-pos.sh

# Create a tarball for Linux
echo "Creating Linux package..."
tar -czf bizflow-pos-linux.tar.gz -C target .

echo "\nBuild complete! Linux package: bizflow-pos-linux.tar.gz"
echo "To run the application on Linux: tar -xzf bizflow-pos-linux.tar.gz && cd target && ./run-pos.sh"
