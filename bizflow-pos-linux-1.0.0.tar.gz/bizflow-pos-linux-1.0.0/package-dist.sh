#!/bin/bash
# Package BizFlow POS for distribution

set -e

# Configuration
VERSION="1.0.0"
APP_NAME="bizflow-pos"
DIST_DIR="dist"
PACKAGE_DIR="$DIST_DIR/$APP_NAME-$VERSION"
DEB_DIR="$PACKAGE_DIR/DEBIAN"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Packaging BizFlow POS $VERSION ===${NC}"

# Clean previous builds
rm -rf "$DIST_DIR"
mkdir -p "$PACKAGE_DIR"

# Create directory structure
mkdir -p "$PACKAGE_DIR/opt/$APP_NAME"
mkdir -p "$PACKAGE_DIR/usr/share/applications"
mkdir -p "$PACKAGE_DIR/usr/share/icons/hicolor/256x256/apps"
mkdir -p "$PACKAGE_DIR/usr/local/bin"

# Copy application files
echo "Copying application files..."
cp -r * "$PACKAGE_DIR/opt/$APP_NAME/" 2>/dev/null || true

# Remove unnecessary files
rm -rf "$PACKAGE_DIR/opt/$APP_NAME/dist"
rm -f "$PACKAGE_DIR/opt/$APP_NAME/"*.deb
rm -f "$PACKAGE_DIR/opt/$APP_NAME/"*.tar.gz
rm -f "$PACKAGE_DIR/opt/$APP_NAME/"*.zip

# Create desktop entry
cat > "$PACKAGE_DIR/usr/share/applications/$APP_NAME.desktop" << EOL
[Desktop Entry]
Version=1.0
Type=Application
Name=BizFlow POS
Comment=Point of Sale System
Exec=/opt/$APP_NAME/bizflow-launcher.sh
Icon=/opt/$APP_NAME/assets/icon.png
Terminal=false
Categories=Office;
EOL

# Create launcher symlink
ln -sf "/opt/$APP_NAME/bizflow-launcher.sh" "$PACKAGE_DIR/usr/local/bin/$APP_NAME"

# Create DEBIAN control file
mkdir -p "$DEB_DIR"
cat > "$DEB_DIR/control" << EOL
Package: $APP_NAME
Version: $VERSION
Section: office
Priority: optional
Architecture: all
Maintainer: BizFlow Team <support@bizflow.com>
Description: BizFlow Point of Sale System
 A modern and efficient point of sale system for small businesses.
EOL

# Create postinst script
cat > "$DEB_DIR/postinst" << 'EOL'
#!/bin/sh
set -e

# Update icon cache
if [ -x "$(command -v update-desktop-database)" ]; then
    update-desktop-database
fi

# Set executable permissions
chmod +x /opt/bizflow-pos/bizflow-launcher.sh

# Create database directory if it doesn't exist
mkdir -p /var/lib/bizflow-pos
chmod 775 /var/lib/bizflow-pos
chown -R $SUDO_USER:$(id -gn $SUDO_USER) /var/lib/bizflow-pos 2>/dev/null || true

exit 0
EOL
chmod 755 "$DEB_DIR/postinst"
chmod 755 "$DEB_DIR/prerm"

# Create prerm script
cat > "$DEB_DIR/prerm" << 'EOL'
#!/bin/sh
set -e

# Clean up symlinks
rm -f /usr/local/bin/bizflow-pos

exit 0
EOL
chmod 755 "$DEB_DIR/prerm"

# Set permissions
find "$PACKAGE_DIR" -type d -exec chmod 755 {} \;
find "$PACKAGE_DIR" -type f -exec chmod 644 {} \;
chmod +x "$PACKAGE_DIR/opt/$APP_NAME/bizflow-launcher.sh"
chmod +x "$PACKAGE_DIR/opt/$APP_NAME/linux-installer.sh"

# Create .deb package
echo "Creating .deb package..."
dpkg-deb --build "$PACKAGE_DIR" "$DIST_DIR/${APP_NAME}_${VERSION}_all.deb"

# Create .tar.gz archive
echo "Creating .tar.gz archive..."
tar -czf "$DIST_DIR/${APP_NAME}-${VERSION}.tar.gz" -C "$DIST_DIR" "$APP_NAME-$VERSION"

# Create Windows package
echo -e "\n${YELLOW}Creating Windows package...${NC}"
WIN_PKG_DIR="$DIST_DIR/win"
mkdir -p "$WIN_PKG_DIR"
cp -r * "$WIN_PKG_DIR/" 2>/dev/null || true

# Clean up Windows package
rm -rf "$WIN_PKG_DIR/dist" "$WIN_PKG_DIR/.github" "$WIN_PKG_DIR/.idea" "$WIN_PKG_DIR/.vscode"
rm -f "$WIN_PKG_DIR/"*.deb "$WIN_PKG_DIR/"*.tar.gz "$WIN_PKG_DIR/"*.sh "$WIN_PKG_DIR/"*.ps1

# Create Windows launcher
cat > "$WIN_PKG_DIR/Start-BizFlowPOS.bat" << 'EOL'
@echo off
title BizFlow POS Launcher

echo Starting BizFlow POS...
java -cp ".;lib\*" pos.Main

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Error: Failed to start BizFlow POS
    echo.
    pause
)
EOL

# Create Windows ZIP
cd "$DIST_DIR"
zip -r "${APP_NAME}-${VERSION}-windows.zip" "win"
cd ..

# Clean up
echo -e "\n${GREEN}Packaging complete!${NC}"
echo -e "\nCreated packages:"
echo -e "- ${GREEN}DEB package:${NC} $DIST_DIR/${APP_NAME}_${VERSION}_all.deb"
echo -e "- ${GREEN}Source tarball:${NC} $DIST_DIR/${APP_NAME}-${VERSION}.tar.gz"
echo -e "- ${GREEN}Windows package:${NC} $DIST_DIR/${APP_NAME}-${VERSION}-windows.zip"
echo -e "\nTo install on Debian/Ubuntu: ${YELLOW}sudo dpkg -i $DIST_DIR/${APP_NAME}_${VERSION}_all.deb${NC}"
echo -e "To install from source: ${YELLOW}tar -xzf $DIST_DIR/${APP_NAME}-${VERSION}.tar.gz && cd ${APP_NAME}-${VERSION} && ./linux-installer.sh${NC}"
