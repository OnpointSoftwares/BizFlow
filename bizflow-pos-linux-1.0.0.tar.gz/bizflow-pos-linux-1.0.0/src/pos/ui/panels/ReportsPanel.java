package pos.ui.panels;

import pos.ui.components.ModernCard;
import pos.ui.theme.Theme;
import pos.util.CurrencyUtil;

import java.awt.*;

public class ReportsPanel extends Panel {
    public ReportsPanel(){
        setLayout(new BorderLayout());

        Panel top = new Panel(new FlowLayout(FlowLayout.LEFT, 14, 12));
        top.setBackground(new Color(248, 250, 252));
        Label title = new Label("📈 Reports");
        title.setFont(Theme.H1);
        title.setForeground(Theme.TEXT);
        top.add(title);
        add(top, BorderLayout.NORTH);

        Panel center = new Panel(new FlowLayout(FlowLayout.LEFT, 16, 16));
        center.setBackground(Color.WHITE);
        center.add(new ModernCard("Today Sales", CurrencyUtil.format(1245)));
        center.add(new ModernCard("Top Product", "SKU-1"));
        center.add(new ModernCard("Low Stock", "8"));
        add(center, BorderLayout.CENTER);
    }
}
