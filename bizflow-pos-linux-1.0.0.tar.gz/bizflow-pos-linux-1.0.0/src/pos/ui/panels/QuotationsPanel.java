package pos.ui.panels;

import pos.ui.components.ModernCard;
import pos.ui.theme.Theme;

import java.awt.*;

public class QuotationsPanel extends Panel {
    public QuotationsPanel(){
        setLayout(new BorderLayout());

        Panel top = new Panel(new FlowLayout(FlowLayout.LEFT, 14, 12));
        top.setBackground(new Color(248, 250, 252));
        Label title = new Label("📋 Quotations");
        title.setFont(Theme.H1);
        title.setForeground(Theme.TEXT);
        top.add(title);
        add(top, BorderLayout.NORTH);

        Panel center = new Panel(new FlowLayout(FlowLayout.LEFT, 16, 16));
        center.setBackground(Color.WHITE);
        center.add(new ModernCard("Pending", "12"));
        center.add(new ModernCard("Approved", "7"));
        center.add(new ModernCard("Rejected", "3"));
        add(center, BorderLayout.CENTER);
    }
}
