package pos.ui.panels;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.axis.NumberAxis;
import pos.dao.ProductDAO;
import pos.dao.SaleDAO;
import pos.db.Database;
import pos.models.Sale;
import pos.models.SaleItem;
import pos.ui.components.ModernCard;
import pos.ui.theme.Theme;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class DashboardPanel extends JPanel {
    private ModernCard todaySalesCard = new ModernCard("Today's Sales", "KES 0.00");
    private ModernCard lowStockCard = new ModernCard("Low Stock", "0 items");
    private ModernCard pendingQuotesCard = new ModernCard("Pending Quotes", "0");
    private JTabbedPane tabbedPane;

    public DashboardPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        
        // Create cards panel
        JPanel cards = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 16));
        cards.setBackground(Theme.BACKGROUND);
        cards.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        cards.add(todaySalesCard);
        cards.add(lowStockCard);
        cards.add(pendingQuotesCard);
        
        // Create tabbed pane for charts
        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(Theme.BACKGROUND);
        tabbedPane.setForeground(Theme.TEXT);
        
        // Add components to the panel
        add(cards, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);

        // Initialize charts
        initCharts();
        refreshFromDB();
    }
    
    private void initCharts() {
        try {
            // Sales Trend Chart (Last 7 days)
            JFreeChart salesTrendChart = createSalesTrendChart();
            ChartPanel salesTrendPanel = new ChartPanel(salesTrendChart);
            salesTrendPanel.setPreferredSize(new Dimension(800, 400));
            
            // Category Distribution Chart
            JFreeChart categoryChart = createCategoryChart();
            ChartPanel categoryPanel = new ChartPanel(categoryChart);
            categoryPanel.setPreferredSize(new Dimension(800, 400));
            
            // Monthly Sales Comparison
            JFreeChart monthlySalesChart = createMonthlySalesChart();
            ChartPanel monthlySalesPanel = new ChartPanel(monthlySalesChart);
            monthlySalesPanel.setPreferredSize(new Dimension(800, 400));
            
            // Add charts to tabs
            tabbedPane.addTab("Sales Trend", salesTrendPanel);
            tabbedPane.addTab("Category Distribution", categoryPanel);
            tabbedPane.addTab("Monthly Sales", monthlySalesPanel);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading chart data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String formatKES(double amount) {
        return String.format("KES %,.0f", amount);
    }
    
    private JFreeChart createSalesTrendChart() throws Exception {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        // Get sales data for the last 7 days
        String sql = "SELECT date(created_at) as sale_date, COALESCE(SUM(total), 0) as daily_total " +
                    "FROM sales " +
                    "WHERE date(created_at) >= date('now', '-6 days') " +
                    "GROUP BY date(created_at) " +
                    "ORDER BY sale_date";
        
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            // Initialize all 7 days with zero values
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd");
            Map<LocalDate, Double> salesByDate = new HashMap<>();
            
            for (int i = 6; i >= 0; i--) {
                LocalDate date = today.minusDays(i);
                salesByDate.put(date, 0.0);
            }
            
            // Fill in actual sales data
            while (rs.next()) {
                LocalDate saleDate = LocalDate.parse(rs.getString("sale_date"));
                double total = rs.getDouble("daily_total");
                salesByDate.put(saleDate, total);
            }
            
            // Add data to dataset
            for (Map.Entry<LocalDate, Double> entry : salesByDate.entrySet()) {
                String dateStr = entry.getKey().format(formatter);
                dataset.addValue(entry.getValue(), "Sales", dateStr);
            }
        }
        
        JFreeChart chart = ChartFactory.createLineChart(
            "7-Day Sales Trend (KES)", 
            "Date", 
            "Amount (KES)", 
            dataset,
            PlotOrientation.VERTICAL,
            true, true, false);
        
        // Customize chart appearance
        chart.setBackgroundPaint(Theme.BACKGROUND);
        chart.getTitle().setPaint(Theme.TEXT);
        
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Theme.BACKGROUND);
        plot.setRangeGridlinePaint(Theme.SECONDARY_TEXT);
        plot.getDomainAxis().setTickLabelPaint(Theme.TEXT);
        plot.getRangeAxis().setTickLabelPaint(Theme.TEXT);
        
        LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(66, 165, 245));
        renderer.setSeriesStroke(0, new BasicStroke(2.5f));
        renderer.setSeriesShape(0, new Ellipse2D.Double(-3, -3, 6, 6));
        
        return chart;
    }
    
    private JFreeChart createCategoryChart() throws Exception {
        DefaultPieDataset dataset = new DefaultPieDataset();
        
        // Get sales by category
        String sql = "SELECT p.category, COALESCE(SUM(si.line_total), 0) as category_total " +
                    "FROM sales_items si " +
                    "JOIN products p ON si.product_id = p.id " +
                    "JOIN sales s ON si.sale_id = s.id " +
                    "WHERE date(s.created_at) >= date('now', '-30 days') " +
                    "GROUP BY p.category " +
                    "HAVING p.category IS NOT NULL AND p.category != '' " +
                    "ORDER BY category_total DESC";
        
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                String category = rs.getString("category");
                if (category == null || category.trim().isEmpty()) {
                    category = "Uncategorized";
                }
                double total = rs.getDouble("category_total");
                if (total > 0) {
                    dataset.setValue(category, total);
                }
            }
            
            // If no category data, show a message
            if (dataset.getItemCount() == 0) {
                dataset.setValue("No category data", 1);
            }
        }
        
        JFreeChart chart = ChartFactory.createPieChart(
            "Category Distribution", 
            dataset, 
            true, true, false);
        
        // Customize chart appearance
        chart.setBackgroundPaint(Theme.BACKGROUND);
        chart.getTitle().setPaint(Theme.TEXT);
        
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setBackgroundPaint(Theme.BACKGROUND);
        plot.setLabelBackgroundPaint(Theme.BACKGROUND);
        plot.setLabelPaint(Theme.TEXT);
        plot.setOutlinePaint(null);
        
        // Set custom colors
        plot.setSectionPaint("Electronics", new Color(66, 165, 245));
        plot.setSectionPaint("Clothing", new Color(102, 187, 106));
        plot.setSectionPaint("Groceries", new Color(255, 167, 38));
        plot.setSectionPaint("Furniture", new Color(236, 64, 122));
        
        return chart;
    }
    
    private JFreeChart createMonthlySalesChart() throws Exception {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        // Get monthly sales for the current year
        String sql = "SELECT strftime('%m', created_at) as month, COALESCE(SUM(total), 0) as monthly_total " +
                    "FROM sales " +
                    "WHERE strftime('%Y', created_at) = strftime('%Y', 'now') " +
                    "GROUP BY strftime('%m', created_at) " +
                    "ORDER BY month";
        
        // Initialize all months with zero values
        String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        Map<String, Double> monthlySales = new HashMap<>();
        for (String month : monthNames) {
            monthlySales.put(month, 0.0);
        }
        
        // Get actual sales data
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                int monthNum = Integer.parseInt(rs.getString("month"));
                if (monthNum >= 1 && monthNum <= 12) {
                    String monthName = monthNames[monthNum - 1];
                    monthlySales.put(monthName, rs.getDouble("monthly_total"));
                }
            }
            
            // Add data to dataset
            for (String month : monthNames) {
                dataset.addValue(monthlySales.get(month), "Sales", month);
            }
        }
        
        JFreeChart chart = ChartFactory.createBarChart(
            "Monthly Sales Comparison (KES)", 
            "Month", 
            "Amount (KES)", 
            dataset,
            PlotOrientation.VERTICAL,
            true, true, false);
        
        // Customize chart appearance
        chart.setBackgroundPaint(Theme.BACKGROUND);
        chart.getTitle().setPaint(Theme.TEXT);
        
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Theme.BACKGROUND);
        plot.setRangeGridlinePaint(Theme.SECONDARY_TEXT);
        plot.getDomainAxis().setTickLabelPaint(Theme.TEXT);
        plot.getRangeAxis().setTickLabelPaint(Theme.TEXT);
        CategoryAxis domainAxis = plot.getDomainAxis();
        domainAxis.setCategoryLabelPositions(
            CategoryLabelPositions.createUpRotationLabelPositions(Math.PI / 6.0)
        );
        
        return chart;
    }

    public void refreshFromDB() {
        try {
            // Update today's sales total
            double todaySales = SaleDAO.getTodaySalesTotal();
            todaySalesCard.setValue(String.format("KES %,.2f", todaySales));
            
            // Update low stock count (items with 10 or less in stock)
            int lowStockCount = ProductDAO.lowStockCount(10);
            lowStockCard.setValue(lowStockCount + (lowStockCount == 1 ? " item" : " items"));
            
            // Pending quotes would come from a QuoteDAO if implemented
            pendingQuotesCard.setValue("0");
            
            // Refresh charts
            initCharts();
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error refreshing data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
