package pos.ui.panels;

import pos.dao.SaleDAO;
import pos.models.Sale;
import pos.ui.components.*;
import pos.ui.theme.Theme;
import pos.util.Formatter;
import pos.util.PdfUtil;
import pos.util.Alerts;
import pos.ui.dialogs.NewInvoiceDialog;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingUtilities;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.List;

public class InvoicesPanel extends JPanel {
    private List<Sale> sales = new ArrayList<>();
    private JPanel listPanel;
    private JTextField searchField;
    private JComboBox<String> statusFilter;
    private JButton btnNewInvoice, btnRefresh, btnExport, btnPrint;
    private JLabel summaryLabel;
    private JPanel filterPanel;
    // Date picker placeholders - will be implemented later
    private JTextField startDateField, endDateField;
    private int selectedIndex = -1;
    private JScrollPane scrollPane;

    public InvoicesPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        
        // Create toolbar
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(Theme.BACKGROUND);
        toolBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.DIVIDER));
        
        // Title
        JLabel title = new JLabel("📄 Invoices");
        title.setFont(Theme.H1);
        title.setForeground(Theme.TEXT);
        title.setBorder(new EmptyBorder(0, 10, 0, 20));
        toolBar.add(title);
        
        // New Invoice Button
        btnNewInvoice = createToolbarButton("New Invoice", "🆕");
        btnNewInvoice.addActionListener(e -> createNewInvoice());
        toolBar.add(btnNewInvoice);
        
        toolBar.add(Box.createHorizontalGlue());
        
        // Refresh Button
        btnRefresh = createToolbarButton("", "🔄");
        btnRefresh.setToolTipText("Refresh");
        btnRefresh.addActionListener(e -> doRefresh());
        toolBar.add(btnRefresh);
        
        // Export Button
        btnExport = createToolbarButton("", "📤");
        btnExport.setToolTipText("Export PDF");
        btnExport.addActionListener(e -> doExport());
        toolBar.add(btnExport);
        
        // Print Button
        btnPrint = createToolbarButton("", "🖨️");
        btnPrint.setToolTipText("Print");
        btnPrint.addActionListener(e -> {
            if (selectedIndex >= 0 && selectedIndex < sales.size()) {
                printInvoice(sales.get(selectedIndex));
            } else {
                JOptionPane.showMessageDialog(this, "Please select an invoice first.", 
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });
        toolBar.add(btnPrint);
        
        add(toolBar, BorderLayout.NORTH);
        
        // Create filter panel
        createFilterPanel();
        add(filterPanel, BorderLayout.CENTER);
        
        // Create list panel
        createListPanel();
        
        // Add summary label at bottom
        summaryLabel = new JLabel("Loading invoices...");
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        summaryLabel.setForeground(Theme.MUTED_TEXT);
        add(summaryLabel, BorderLayout.SOUTH);
        
        // Load initial data
        doRefresh();
    }
    
    private JButton createToolbarButton(String text, String icon) {
        JButton button = new JButton(icon + (text.isEmpty() ? "" : " " + text));
        button.setFont(Theme.BODY);
        button.setBackground(Theme.BACKGROUND);
        button.setForeground(Theme.TEXT);
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void createFilterPanel() {
        filterPanel = new JPanel(new BorderLayout());
        filterPanel.setBackground(Theme.BACKGROUND);
        filterPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        filterRow.setBackground(Theme.BACKGROUND);
        
        // Search field
        searchField = new JTextField(25);
        searchField.setFont(Theme.BODY);
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.DIVIDER),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        searchField.addActionListener(e -> filterInvoices());
        
        JButton searchButton = new JButton("🔍 Search");
        searchButton.addActionListener(e -> filterInvoices());
        
        // Status filter
        statusFilter = new JComboBox<>(new String[]{"All Status", "Paid", "Unpaid", "Partially Paid"});
        statusFilter.addActionListener(e -> filterInvoices());
        
        // Date range
        JLabel fromLabel = new JLabel("From:");
        JLabel toLabel = new JLabel("To:");
        
        // Using JXDatePicker or similar for better date selection
        // For now, using JTextField as placeholder
        JTextField startDateField = new JTextField(10);
        JTextField endDateField = new JTextField(10);
        
        JButton applyFilter = new JButton("Apply Filters");
        applyFilter.addActionListener(e -> filterInvoices());
        
        filterRow.add(new JLabel("🔍"));
        filterRow.add(searchField);
        filterRow.add(searchButton);
        filterRow.add(Box.createHorizontalStrut(20));
        filterRow.add(new JLabel("Status:"));
        filterRow.add(statusFilter);
        filterRow.add(Box.createHorizontalStrut(20));
        filterRow.add(fromLabel);
        filterRow.add(startDateField);
        filterRow.add(toLabel);
        filterRow.add(endDateField);
        filterRow.add(applyFilter);
        
        filterPanel.add(filterRow, BorderLayout.NORTH);
    }
    
    private void createListPanel() {
        listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(Theme.BACKGROUND);
        listPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Create header
        JPanel header = new JPanel(new GridLayout(1, 6, 10, 0));
        header.setBackground(Theme.BACKGROUND);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.DIVIDER));
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        
        addHeaderCell(header, "INVOICE #");
        addHeaderCell(header, "DATE");
        addHeaderCell(header, "CUSTOMER");
        addHeaderCell(header, "STATUS");
        addHeaderCell(header, "AMOUNT (KES)");
        addHeaderCell(header, "ACTIONS");
        
        listPanel.add(header);
        
        // Create scroll pane
        scrollPane = new JScrollPane(listPanel);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBorder(null);
        
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Theme.BACKGROUND);
        wrapper.add(scrollPane, BorderLayout.CENTER);
        
        add(wrapper, BorderLayout.CENTER);
    }
    
    private void addHeaderCell(JPanel panel, String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        label.setForeground(Theme.MUTED_TEXT);
        label.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        panel.add(label);
    }
    
    private void doRefresh() {
        try { 
            sales = SaleDAO.listRecent(200);
            updateInvoiceList();
            updateSummary();
        } catch (Exception ex) { 
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading invoices: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateSummary() {
        double totalAmount = sales.stream().mapToDouble(s -> s.total).sum();
        summaryLabel.setText(String.format("Showing %d invoices | Total: KES %,.2f", 
            sales.size(), totalAmount));
    }
    
    private void filterInvoices() {
        String searchText = searchField.getText().toLowerCase();
        String statusFilterText = statusFilter.getSelectedItem().toString();
        
        // This is a simple filter - you can enhance it with more complex logic
        List<Sale> filtered = new ArrayList<>();
        for (Sale sale : sales) {
            boolean matches = true;
            
            // Filter by search text
            if (!searchText.isEmpty()) {
                String invoiceText = (sale.invoiceNo != null ? sale.invoiceNo : "").toLowerCase();
                String customerName = (sale.customerName != null ? sale.customerName : "").toLowerCase();
                if (!invoiceText.contains(searchText) && !customerName.contains(searchText)) {
                    matches = false;
                }
            }
            
            // Filter by status
            if (!statusFilterText.equals("All Status")) {
                // This is a simplified status check - adjust based on your status logic
                // Assuming there's a 'status' field in the Sale model
                String status = "Paid"; // Default to Paid, update based on your Sale model
                if (!status.equals(statusFilterText)) {
                    matches = false;
                }
            }
            
            if (matches) {
                filtered.add(sale);
            }
        }
        
        // Update the list with filtered results
        updateInvoiceList(filtered);
    }
    
    private void updateInvoiceList() {
        updateInvoiceList(sales);
    }
    
    private void updateInvoiceList(List<Sale> invoices) {
        listPanel.removeAll();
        
        // Re-add header
        JPanel header = new JPanel(new GridLayout(1, 6, 10, 0));
        header.setBackground(Theme.BACKGROUND);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.DIVIDER));
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        
        addHeaderCell(header, "INVOICE #");
        addHeaderCell(header, "DATE");
        addHeaderCell(header, "CUSTOMER");
        addHeaderCell(header, "STATUS");
        addHeaderCell(header, "AMOUNT (KES)");
        addHeaderCell(header, "ACTIONS");
        
        listPanel.add(header);
        
        // Add invoice rows
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        
        for (int i = 0; i < invoices.size(); i++) {
            Sale sale = invoices.get(i);
            boolean isSelected = (i == selectedIndex);
            
            JPanel row = new JPanel(new GridLayout(1, 6, 10, 0));
            row.setBackground(isSelected ? new Color(235, 245, 255) : (i % 2 == 0 ? new Color(250, 252, 255) : Color.WHITE));
            row.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            
            // Make row selectable
            final int index = i;
            row.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    selectedIndex = index;
                    updateInvoiceList(invoices);
                }
            });
            
            // Invoice Number
            JLabel invoiceLabel = new JLabel(sale.invoiceNo != null ? sale.invoiceNo : "INV" + sale.id);
            invoiceLabel.setFont(invoiceLabel.getFont().deriveFont(Font.BOLD));
            row.add(invoiceLabel);
            
            // Date
            // Using current date as fallback since sale date field is not available
            JLabel dateLabel = new JLabel(dateFormat.format(new java.util.Date()));
            row.add(dateLabel);
            
            // Customer
            JLabel customerLabel = new JLabel(sale.customerName != null ? sale.customerName : "Walk-in Customer");
            row.add(customerLabel);
            
            // Status
            // Assuming a status field or method exists
            boolean isPaid = true; // Default to paid, update based on your Sale model
            JLabel statusLabel = new JLabel(isPaid ? "Paid" : "Unpaid");
            statusLabel.setForeground(isPaid ? new Color(0, 128, 0) : new Color(204, 0, 0));
            statusLabel.setFont(statusLabel.getFont().deriveFont(Font.BOLD));
            row.add(statusLabel);
            
            // Amount
            JLabel amountLabel = new JLabel(String.format("KES %,.2f", sale.total));
            amountLabel.setFont(amountLabel.getFont().deriveFont(Font.BOLD));
            row.add(amountLabel);
            
            // Actions
            JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
            actionsPanel.setOpaque(false);
            
            JButton viewButton = new JButton("👁️");
            viewButton.setToolTipText("View Invoice");
            viewButton.setBorderPainted(false);
            viewButton.setContentAreaFilled(false);
            viewButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            viewButton.addActionListener(e -> viewInvoice(sale));
            
            JButton printButton = new JButton("🖨️");
            printButton.setToolTipText("Print Invoice");
            printButton.setBorderPainted(false);
            printButton.setContentAreaFilled(false);
            printButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            printButton.addActionListener(e -> printInvoice(sale));
            
            JButton exportButton = new JButton("💾");
            exportButton.setToolTipText("Export as PDF");
            exportButton.setBorderPainted(false);
            exportButton.setContentAreaFilled(false);
            exportButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            exportButton.addActionListener(e -> exportInvoice(sale));
            
            actionsPanel.add(viewButton);
            actionsPanel.add(printButton);
            actionsPanel.add(exportButton);
            
            row.add(actionsPanel);
            
            listPanel.add(row);
            listPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        }
        
        if (invoices.isEmpty()) {
            JLabel emptyLabel = new JLabel("No invoices found");
            emptyLabel.setForeground(Theme.MUTED_TEXT);
            emptyLabel.setHorizontalAlignment(JLabel.CENTER);
            emptyLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
            listPanel.add(emptyLabel);
        }
        
        listPanel.revalidate();
        listPanel.repaint();
    }
    
    private void viewInvoice(Sale sale) {
        // TODO: Implement invoice detail view
        JOptionPane.showMessageDialog(this, "Viewing invoice: " + (sale.invoiceNo != null ? sale.invoiceNo : "INV" + sale.id), 
            "View Invoice", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void printInvoice(Sale sale) {
        // TODO: Implement print functionality
        JOptionPane.showMessageDialog(this, "Printing invoice: " + (sale.invoiceNo != null ? sale.invoiceNo : "INV" + sale.id), 
            "Print Invoice", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void exportInvoice(Sale sale) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Invoice PDF");
        fileChooser.setSelectedFile(new File((sale.invoiceNo != null ? sale.invoiceNo : ("INV" + sale.id)) + ".pdf"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File out = fileChooser.getSelectedFile();
            try { 
                PdfUtil.exportSale(sale, out); 
                JOptionPane.showMessageDialog(this, "Invoice exported to:\n" + out.getAbsolutePath(), 
                    "Export Successful", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) { 
                ex.printStackTrace(); 
                JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage(), 
                    "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void createNewInvoice() {
        NewInvoiceDialog dialog = new NewInvoiceDialog((Frame)SwingUtilities.getWindowAncestor(this));
        dialog.setVisible(true);
        
        if (dialog.isSaved()) {
            try {
                // Save the new invoice
                Sale newSale = dialog.getNewSale();
                // TODO: Save the sale to the database using SaleDAO
                // int saleId = SaleDAO.saveSale(newSale);
                // newSale.id = saleId;
                
                // Refresh the invoice list
                doRefresh();
                
                // Show success message
                JOptionPane.showMessageDialog(this, 
                    String.format("Invoice #%s created successfully!", newSale.invoiceNo != null ? newSale.invoiceNo : ("INV" + newSale.id)),
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                    
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Error creating invoice: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Action methods for buttons
    private void doExport() {
        if (selectedIndex < 0 || selectedIndex >= sales.size()) { 
            JOptionPane.showMessageDialog(this, "Please select an invoice first.", 
                "No Selection", JOptionPane.WARNING_MESSAGE);
            return; 
        }
        exportInvoice(sales.get(selectedIndex));
    }
    
}
