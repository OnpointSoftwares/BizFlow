package pos.ui.panels;

import pos.dao.ProductDAO;
import pos.models.Product;
import pos.ui.components.*;
import pos.ui.theme.Theme;

import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.util.*;
import pos.util.CurrencyUtil;
import java.util.List;
import java.util.stream.Collectors;

public class InventoryPanel extends Panel {
    private List<Product> products;
    private ListPanel listPanel = new ListPanel();
    private ModernSearchField searchField;
    private ComboBox<String> categoryFilter = new ComboBox<>();
    private ComboBox<String> sortBy = new ComboBox<>();
    private boolean sortAscending = true;
    private int currentPage = 1;
    private final int PAGE_SIZE = 20;
    private Label pageInfo = new Label();
    private RoundedButton prevPage, nextPage;
    private StatusIndicator stockStatus = new StatusIndicator(StatusIndicator.Status.DISCONNECTED);
    
    public InventoryPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        
        // Initialize UI components
        initHeader();
        initListPanel();
        initPagination();
        
        // Load initial data
        refreshList();
    }
    
    private void initListPanel() {
        listPanel = new ListPanel();
        listPanel.setBackground(Theme.BACKGROUND);
        
        // Add mouse listener for row selection and hover effects
        listPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == listPanel) {
                    Point p = e.getPoint();
                    int row = listPanel.getRowAtPoint(p);
                    if (row >= 0 && row < products.size()) {
                        Product selectedProduct = products.get(row);
                        openEditor(selectedProduct);
                    }
                }
            }    
        });
        
        // Add mouse motion listener for hover effects
        listPanel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                listPanel.setHoveredRow(listPanel.getRowAtPoint(e.getPoint()));
            }
        });
        
        // Add the list panel to a scroll pane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.add(listPanel);
        scrollPane.setBackground(Theme.BACKGROUND);
        add(scrollPane, BorderLayout.CENTER);
    }
    
    private void initHeader() {
        // Main header panel
        Panel header = new Panel(new BorderLayout());
        header.setBackground(Theme.SURFACE);
        header.setPreferredSize(new Dimension(getWidth(), 80));
        
        // Top row with title and actions
        Panel topRow = new Panel(new BorderLayout());
        topRow.setBackground(Theme.SURFACE);
        
        // Title with icon
        Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 16, 14));
        titlePanel.setBackground(Theme.SURFACE);
        Label title = new Label("📦 Inventory Management");
        title.setFont(Theme.H1);
        title.setForeground(Theme.TEXT_PRIMARY);
        titlePanel.add(title);
        
        // Quick actions
        Panel actions = new Panel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actions.setBackground(Theme.SURFACE);
        
        // Add stock button
        RoundedButton btnAddStock = new RoundedButton("📥 Add Stock");
        btnAddStock.setBackground(Theme.PRIMARY);
        btnAddStock.setForeground(Color.WHITE);
        btnAddStock.addActionListener(e -> showAddStockDialog());
        
        // Export button
        RoundedButton btnExport = new RoundedButton("📤 Export");
        btnExport.setBackground(Theme.ACCENT_500);
        btnExport.setForeground(Color.WHITE);
        btnExport.addActionListener(e -> exportInventory());
        
        // Add product button
        RoundedButton btnAdd = new RoundedButton("➕ New Product");
        btnAdd.setBackground(Theme.ACCENT);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.addActionListener(e -> openEditor(null));
        
        actions.add(btnAddStock);
        actions.add(btnExport);
        actions.add(btnAdd);
        
        topRow.add(titlePanel, BorderLayout.WEST);
        topRow.add(actions, BorderLayout.EAST);
        
        // Filter and search panel
        Panel filterPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        filterPanel.setBackground(Theme.SURFACE);
        
        // Search field
        searchField = new ModernSearchField("Search products...");
        searchField.setPreferredSize(new Dimension(250, 36));
        searchField.addActionListener(e -> refreshList());
        
        // Category filter
        categoryFilter.setPreferredSize(new Dimension(150, 36));
        categoryFilter.addItem("All Categories");
        loadCategories();
        categoryFilter.addItemListener(e -> refreshList());
        
        // Sort dropdown
        sortBy.setPreferredSize(new Dimension(150, 36));
        sortBy.addItem("Name (A-Z)");
        sortBy.addItem("Name (Z-A)");
        sortBy.addItem("Price (Low-High)");
        sortBy.addItem("Price (High-Low)");
        sortBy.addItem("Stock (Low-High)");
        sortBy.addItem("Stock (High-Low)");
        sortBy.addItemListener(e -> {
            String selected = (String) sortBy.getSelectedItem();
            sortAscending = !selected.endsWith("(Z-A)") && !selected.endsWith("(High-Low)");
            refreshList();
        });
        
        // Stock status indicator
        Panel statusPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        statusPanel.setBackground(Theme.SURFACE);
        statusPanel.add(new Label("Status:"));
        statusPanel.add(stockStatus);
        
        filterPanel.add(new Label("Search:"));
        filterPanel.add(searchField);
        filterPanel.add(new Label("Category:"));
        filterPanel.add(categoryFilter);
        filterPanel.add(new Label("Sort by:"));
        filterPanel.add(sortBy);
        filterPanel.add(statusPanel);
        
        header.add(topRow, BorderLayout.NORTH);
        header.add(filterPanel, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);
    }

    private void loadCategories() {
        try {
            List<String> categories = ProductDAO.listAll().stream()
                .map(p -> p.category)
                .filter(Objects::nonNull)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
                
            categoryFilter.removeAllItems();
            categoryFilter.addItem("All Categories");
            for (String cat : categories) {
                if (cat != null && !cat.trim().isEmpty()) {
                    categoryFilter.addItem(cat);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void refreshList() {
        if (listPanel != null) {
            listPanel.setProducts(products);
            listPanel.repaint();
        }
        try {
            String query = searchField.getText();
            String category = (String) categoryFilter.getSelectedItem();
            
            // Get all products and filter them
            List<Product> allProducts = (query == null || query.isEmpty()) ? 
                ProductDAO.listAll() : ProductDAO.search(query);
                
            // Apply category filter
            if (category != null && !category.equals("All Categories")) {
                allProducts = allProducts.stream()
                    .filter(p -> category.equals(p.category))
                    .collect(Collectors.toList());
            }
            
            // Apply sorting
            String sortOption = (String) sortBy.getSelectedItem();
            if (sortOption != null) {
                allProducts.sort((p1, p2) -> {
                    switch (sortOption) {
                        case "Name (A-Z)":
                            return p1.name.compareToIgnoreCase(p2.name);
                        case "Name (Z-A)":
                            return p2.name.compareToIgnoreCase(p1.name);
                        case "Price (Low-High)":
                            return Double.compare(p1.sellingPrice, p2.sellingPrice);
                        case "Price (High-Low)":
                            return Double.compare(p2.sellingPrice, p1.sellingPrice);
                        case "Stock (Low-High)":
                            return Integer.compare(p1.stockQty, p2.stockQty);
                        case "Stock (High-Low)":
                            return Integer.compare(p2.stockQty, p1.stockQty);
                        default:
                            return 0;
                    }
                });
            }
            
            // Update pagination
            int totalPages = (int) Math.ceil((double) allProducts.size() / PAGE_SIZE);
            currentPage = Math.min(Math.max(1, currentPage), Math.max(1, totalPages));
            
            // Get current page items
            int fromIndex = (currentPage - 1) * PAGE_SIZE;
            int toIndex = Math.min(fromIndex + PAGE_SIZE, allProducts.size());
            products = allProducts.subList(fromIndex, toIndex);
            
            // Update UI
            listPanel.setProducts(products);
            updatePagination(allProducts.size(), totalPages);
            updateStockStatus(allProducts);
            
        } catch (Exception ex) { 
            ex.printStackTrace();
            // Show error notification
        }
    }

    private void openEditor(Product p) {
        ProductEditorDialog dlg = new ProductEditorDialog((Frame) getParent().getParent(), p, saved -> {
            refreshList();
            loadCategories(); // Reload categories in case a new one was added
        });
        dlg.setVisible(true);
    }
    
    private void showAddStockDialog() {
        // Implementation for adding stock
        // This would show a dialog to add stock to multiple products at once
    }
    
    private void exportInventory() {
        // Implementation for exporting inventory to CSV/Excel
    }
    
    private void updateStockStatus(List<Product> products) {
        if (products == null || products.isEmpty()) {
            stockStatus.setStatus(StatusIndicator.Status.DISCONNECTED);
            return;
        }
        
        long lowStock = products.stream()
            .filter(p -> p.stockQty <= 5)
            .count();
            
        if (lowStock > products.size() * 0.2) {
            stockStatus.setStatus(StatusIndicator.Status.ERROR);
        } else if (lowStock > 0) {
            stockStatus.setStatus(StatusIndicator.Status.SYNCING);
        } else {
            stockStatus.setStatus(StatusIndicator.Status.CONNECTED);
        }
    }
    
    private void initPagination() {
        Panel pagination = new Panel(new FlowLayout(FlowLayout.CENTER, 5, 10));
        pagination.setBackground(Theme.BACKGROUND);
        
        prevPage = new RoundedButton("⬅");
        prevPage.setPreferredSize(new Dimension(40, 32));
        prevPage.addActionListener(e -> {
            if (currentPage > 1) {
                currentPage--;
                refreshList();
            }
        });
        
        nextPage = new RoundedButton("➡");
        nextPage.setPreferredSize(new Dimension(40, 32));
        nextPage.addActionListener(e -> {
            currentPage++;
            refreshList();
        });
        
        pagination.add(prevPage);
        pagination.add(pageInfo);
        pagination.add(nextPage);
        
        add(pagination, BorderLayout.SOUTH);
    }
    
    private void updatePagination(int totalItems, int totalPages) {
        pageInfo.setText(String.format("Page %d of %d (%d items)", currentPage, totalPages, totalItems));
        prevPage.setEnabled(currentPage > 1);
        nextPage.setEnabled(currentPage < totalPages);
    }

    // Modern list panel with better styling and interactivity
    private class ListPanel extends Panel implements MouseListener {
        private int hoveredRow = -1;
        private int selectedRow = -1;
        private List<Product> products = new ArrayList<>();
        private final int ROW_HEIGHT = 48;
        private final int[] colWidths = {40, 300, 120, 120, 100, 100, 80};
        private final String[] headers = {"", "Product", "SKU", "Category", "Price", "Stock", ""};
        
        public ListPanel() {
            setBackground(Theme.BACKGROUND);
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getSource() == listPanel) {
                        Point p = e.getPoint();
                        int row = getRowAtPoint(p);
                        if (row >= 0 && row < products.size()) {
                            Product selectedProduct = products.get(row);
                            openEditor(selectedProduct);
                        }
                    }
                }    
            });
            
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    int row = getRowAtPoint(e.getPoint());
                    if (row != hoveredRow) {
                        hoveredRow = row;
                        repaint();
                    }
                }
            });
        }
        
        public int getRowAtPoint(Point p) {
            if (p == null) return -1;
            int headerHeight = 30; // Height of the header row
            if (p.y < headerHeight) return -1; // Clicked on header
            return (p.y - headerHeight) / ROW_HEIGHT;
        }
        
        public void setHoveredRow(int row) {
            if (hoveredRow != row) {
                hoveredRow = row;
                repaint();
            }
        }
        
        public void setProducts(List<Product> p) { 
            this.products = p != null ? p : new ArrayList<>();
            // Adjust preferred size based on content
            int totalHeight = (products.size() + 1) * ROW_HEIGHT + 10; // +1 for header
            setPreferredSize(new Dimension(getWidth(), totalHeight));
            revalidate();
            repaint();
        }
        
        @Override 
        public void paint(Graphics g) {
            super.paint(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            
            int width = getWidth();
            int y = 0;
            
            // Draw header
            drawHeader(g2, width, y);
            y += ROW_HEIGHT;
            
            if (products == null || products.isEmpty()) {
                drawEmptyState(g2, width, y);
                return;
            }
            
            // Draw rows
            for (int i = 0; i < products.size(); i++) {
                Product p = products.get(i);
                boolean isHovered = (i == hoveredRow);
                boolean isSelected = (i == selectedRow);
                
                drawProductRow(g2, p, y, width, i, isHovered, isSelected);
                y += ROW_HEIGHT;
            }
        }
        
        private void drawHeader(Graphics2D g2, int width, int y) {
            // Header background
            g2.setColor(Theme.SURFACE);
            g2.fillRect(0, y, width, ROW_HEIGHT);
            
            // Header text
            g2.setFont(Theme.BODY.deriveFont(Font.BOLD));
            g2.setColor(Theme.TEXT_SECONDARY);
            
            int x = 16;
            for (int i = 0; i < headers.length; i++) {
                if (i > 0) {
                    g2.drawString(headers[i], x, y + ROW_HEIGHT / 2 + 5);
                }
                x += colWidths[i];
            }
            
            // Header bottom border
            g2.setColor(Theme.DIVIDER);
            g2.fillRect(0, y + ROW_HEIGHT - 1, width, 1);
        }
        
        private void drawEmptyState(Graphics2D g2, int width, int y) {
            g2.setFont(Theme.HEADING_3);
            g2.setColor(Theme.TEXT_SECONDARY);
            String msg = "No products found";
            int msgWidth = g2.getFontMetrics().stringWidth(msg);
            g2.drawString(msg, (width - msgWidth) / 2, y + 50);
        }
        
        private void drawProductRow(Graphics2D g2, Product p, int y, int width, int rowIndex, 
                                  boolean isHovered, boolean isSelected) {
            // Row background
            if (isSelected) {
                g2.setColor(Theme.withAlpha(Theme.PRIMARY, 10));
                g2.fillRect(0, y, width, ROW_HEIGHT);
            } else if (isHovered) {
                g2.setColor(Theme.SURFACE_HOVER);
                g2.fillRect(0, y, width, ROW_HEIGHT);
            } else if (rowIndex % 2 == 0) {
                g2.setColor(Theme.SURFACE);
                g2.fillRect(0, y, width, ROW_HEIGHT);
            }
            
            // Row content
            g2.setFont(Theme.BODY);
            g2.setColor(Theme.TEXT_PRIMARY);
            
            int x = 16;
            
            // Checkbox (empty for now)
            x += colWidths[0];
            
            // Product name with ellipsis
            String name = p.name;
            if (name.length() > 30) {
                name = truncateWithEllipsis(g2, name, colWidths[1] - 16);
            }
            g2.drawString(name, x, y + ROW_HEIGHT / 2 + 5);
            x += colWidths[1];
            
            // SKU
            g2.drawString(p.sku, x, y + ROW_HEIGHT / 2 + 5);
            x += colWidths[2];
            
            // Category
            g2.drawString(p.category, x, y + ROW_HEIGHT / 2 + 5);
            x += colWidths[3];
            
            // Price
            g2.drawString(CurrencyUtil.format(p.sellingPrice), x, y + ROW_HEIGHT / 2 + 5);
            x += colWidths[4];
            
            // Stock with color coding
            int stock = p.stockQty;
            if (stock < 5) {
                g2.setColor(Theme.ERROR);
            } else if (stock < 10) {
                g2.setColor(Theme.WARNING);
            }
            g2.drawString(String.valueOf(stock), x, y + ROW_HEIGHT / 2 + 5);
            g2.setColor(Theme.TEXT_PRIMARY);
            x += colWidths[5];
            
            // Action buttons
            if (isHovered || isSelected) {
                g2.setColor(Theme.PRIMARY);
                g2.fillRoundRect(x + 5, y + 8, 60, 24, 12, 12);
                g2.setColor(Color.WHITE);
                g2.drawString("Edit", x + 22, y + 24);
            }
            
            // Bottom border
            g2.setColor(Theme.BORDER);
            g2.fillRect(0, y + ROW_HEIGHT - 1, width, 1);
        }
        
        private String truncateWithEllipsis(Graphics2D g2, String text, int maxWidth) {
            if (text == null || text.isEmpty()) {
                return "";
            }
            
            FontMetrics fm = g2.getFontMetrics();
            
            if (fm.stringWidth(text) <= maxWidth) {
                return text;
            }
            
            // Simple truncation for now - could be enhanced with binary search if needed
            String ellipsis = "...";
            int ellipsisWidth = fm.stringWidth(ellipsis);
            
            for (int i = text.length() - 1; i >= 0; i--) {
                String candidate = text.substring(0, i) + ellipsis;
                if (fm.stringWidth(candidate) <= maxWidth) {
                    return candidate;
                }
            }
            
            return ellipsis;
        }
        
        @Override
        public void mouseClicked(MouseEvent e) {
            int row = e.getY() / ROW_HEIGHT - 1; // -1 for header
            if (row >= 0 && row < products.size()) {
                selectedRow = row;
                
                // Check if edit button was clicked
                int x = e.getX();
                int buttonX = getWidth() - 40;
                if (x >= buttonX && x <= buttonX + 24) {
                    openEditor(products.get(row));
                } else if (e.getClickCount() == 2) {
                    openEditor(products.get(row));
                }
                repaint();
            }
        }
        
        @Override public void mouseEntered(MouseEvent e) {}
        @Override
        public void mouseExited(MouseEvent e) {
            if (e.getSource() == listPanel) {
                listPanel.setHoveredRow(-1);
                listPanel.repaint();
            }
        }
        @Override public void mousePressed(MouseEvent e) {}
        @Override public void mouseReleased(MouseEvent e) {}
        
        private String truncate(String s, int n) {
            return s == null ? "" : (s.length() <= n ? s : s.substring(0, n-3) + "..."); 
        }
    }
}
