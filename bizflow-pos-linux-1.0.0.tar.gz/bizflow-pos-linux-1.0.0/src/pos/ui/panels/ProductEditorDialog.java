package pos.ui.panels;

import pos.dao.ProductDAO;
import pos.models.Product;

import java.awt.*;
import java.util.function.Consumer;

public class ProductEditorDialog extends Dialog {
    private TextField tfName = new TextField(20);
    private TextField tfSku = new TextField(20);
    private TextField tfCategory = new TextField(20);
    private TextField tfSupplierId = new TextField(20);
    private TextField tfPurchase = new TextField(20);
    private TextField tfSelling = new TextField(20);
    private TextField tfStock = new TextField(20);
    private TextField tfExpiry = new TextField(20);

    private Product product;
    private Consumer<Boolean> onSaved;

    public ProductEditorDialog(Frame owner, Product p, Consumer<Boolean> onSaved) {
        super(owner, p==null?"Add Product":"Edit Product", true);
        this.product = p;
        this.onSaved = onSaved;
        setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6,6,6,6);
        gc.fill = GridBagConstraints.HORIZONTAL;

        int r=0;
        addRow(gc, r++, "Name", tfName);
        addRow(gc, r++, "SKU", tfSku);
        addRow(gc, r++, "Category", tfCategory);
        addRow(gc, r++, "Supplier ID", tfSupplierId);
        addRow(gc, r++, "Purchase Price", tfPurchase);
        addRow(gc, r++, "Selling Price", tfSelling);
        addRow(gc, r++, "Stock Qty", tfStock);
        addRow(gc, r++, "Expiry (yyyy-MM-dd)", tfExpiry);

        Panel buttons = new Panel();
        Button save = new Button("Save");
        Button delete = new Button("Delete");
        Button cancel = new Button("Cancel");
        buttons.add(save); buttons.add(delete); buttons.add(cancel);
        gc.gridx=0; gc.gridy=r; gc.gridwidth=2; add(buttons, gc);

        if (product != null) populate(); else delete.setEnabled(false);

        save.addActionListener(e -> onSave());
        delete.addActionListener(e -> onDelete());
        cancel.addActionListener(e -> dispose());

        setSize(480, 420);
        setLocationRelativeTo(owner);
    }

    private void addRow(GridBagConstraints gc, int r, String label, Component c) {
        gc.gridx=0; gc.gridy=r; gc.gridwidth=1; add(new Label(label), gc);
        gc.gridx=1; add(c, gc);
    }

    private void populate() {
        tfName.setText(product.name);
        tfSku.setText(product.sku);
        tfCategory.setText(product.category);
        tfSupplierId.setText(product.supplierId==null?"":String.valueOf(product.supplierId));
        tfPurchase.setText(String.valueOf(product.purchasePrice));
        tfSelling.setText(String.valueOf(product.sellingPrice));
        tfStock.setText(String.valueOf(product.stockQty));
        tfExpiry.setText(product.expiryDate==null?"":product.expiryDate);
    }

    private void onSave() {
        try {
            if (product == null) product = new Product();
            product.name = tfName.getText().trim();
            product.sku = tfSku.getText().trim();
            product.category = tfCategory.getText().trim();
            product.supplierId = tfSupplierId.getText().trim().isEmpty()?null:Integer.parseInt(tfSupplierId.getText().trim());
            product.purchasePrice = Double.parseDouble(tfPurchase.getText().trim());
            product.sellingPrice = Double.parseDouble(tfSelling.getText().trim());
            product.stockQty = Integer.parseInt(tfStock.getText().trim());
            product.expiryDate = tfExpiry.getText().trim().isEmpty()?null:tfExpiry.getText().trim();

            // Validation
            if (product.name.isEmpty() || product.sku.isEmpty()) { showError("Name and SKU are required"); return; }
            if (product.purchasePrice < 0 || product.sellingPrice < 0) { showError("Prices cannot be negative"); return; }
            if (product.stockQty < 0) { showError("Stock cannot be negative"); return; }

            if (product.id == 0) ProductDAO.insert(product); else ProductDAO.update(product);
            if (onSaved != null) onSaved.accept(true);
            dispose();
        } catch (NumberFormatException nfe) {
            showError("Invalid number in one of the fields");
        } catch (Exception ex) { ex.printStackTrace(); showError("Failed to save: " + ex.getMessage()); }
    }

    private void onDelete() {
        if (product == null) return;
        try {
            ProductDAO.delete(product.id);
            if (onSaved != null) onSaved.accept(true);
            dispose();
        } catch (Exception ex) { ex.printStackTrace(); showError("Failed to delete: " + ex.getMessage()); }
    }

    private void showError(String msg) {
        Dialog d = new Dialog(this, "Error", true);
        d.setLayout(new BorderLayout());
        d.add(new Label(msg, Label.CENTER), BorderLayout.CENTER);
        Button ok = new Button("OK"); ok.addActionListener(e -> d.dispose());
        d.add(ok, BorderLayout.SOUTH);
        d.setSize(320,130); d.setLocationRelativeTo(this); d.setVisible(true);
    }
}
