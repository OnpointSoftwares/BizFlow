package pos.ui.theme;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Theme {
    // ===== MODERN COLOR PALETTE =====
    
    // Base Colors - Modern neutral grays with subtle warmth
    public static final Color BACKGROUND = new Color(248, 250, 252);      // Cool gray background
    public static final Color SURFACE = new Color(255, 255, 255);         // Pure white surfaces
    public static final Color CARD_BG = new Color(253, 254, 255);         // Slightly cool white for cards
    public static final Color OVERLAY = new Color(248, 250, 252, 240);    // Semi-transparent overlay
    
    // Primary Brand Colors - Professional blue gradient system
    public static final Color PRIMARY_50 = new Color(239, 246, 255);      // Lightest blue tint
    public static final Color PRIMARY_100 = new Color(219, 234, 254);     // Light blue
    public static final Color PRIMARY_200 = new Color(191, 219, 254);     // Medium light
    public static final Color PRIMARY_300 = new Color(147, 197, 253);     // Medium
    public static final Color PRIMARY_400 = new Color(96, 165, 250);      // Medium dark
    public static final Color PRIMARY_500 = new Color(59, 130, 246);      // Main primary
    public static final Color PRIMARY_600 = new Color(37, 99, 235);       // Dark primary
    public static final Color PRIMARY_700 = new Color(29, 78, 216);       // Darker
    public static final Color PRIMARY_800 = new Color(30, 64, 175);       // Very dark
    public static final Color PRIMARY_900 = new Color(30, 58, 138);       // Darkest
    
    // Secondary/Accent Colors - Modern teal/green system
    public static final Color ACCENT_50 = new Color(236, 253, 245);       // Lightest green
    public static final Color ACCENT_100 = new Color(209, 250, 229);      // Light green
    public static final Color ACCENT_200 = new Color(167, 243, 208);      // Medium light
    public static final Color ACCENT_300 = new Color(110, 231, 183);      // Medium
    public static final Color ACCENT_400 = new Color(52, 211, 153);       // Medium dark
    public static final Color ACCENT_500 = new Color(16, 185, 129);       // Main accent
    public static final Color ACCENT_600 = new Color(5, 150, 105);        // Dark accent
    public static final Color ACCENT_700 = new Color(4, 120, 87);         // Darker
    public static final Color ACCENT_800 = new Color(6, 95, 70);          // Very dark
    public static final Color ACCENT_900 = new Color(6, 78, 59);          // Darkest
    
    // Semantic Colors - Status and feedback colors
    public static final Color SUCCESS_50 = new Color(240, 253, 244);      // Success background
    public static final Color SUCCESS_100 = new Color(220, 252, 231);     // Light success
    public static final Color SUCCESS_500 = new Color(34, 197, 94);       // Main success
    public static final Color SUCCESS_600 = new Color(22, 163, 74);       // Dark success
    public static final Color SUCCESS_700 = new Color(21, 128, 61);       // Darker success
    
    public static final Color WARNING_50 = new Color(255, 251, 235);      // Warning background
    public static final Color WARNING_100 = new Color(254, 243, 199);     // Light warning
    public static final Color WARNING_500 = new Color(245, 158, 11);      // Main warning
    public static final Color WARNING_600 = new Color(217, 119, 6);       // Dark warning
    public static final Color WARNING_700 = new Color(180, 83, 9);        // Darker warning
    
    public static final Color ERROR_50 = new Color(254, 242, 242);        // Error background
    public static final Color ERROR_100 = new Color(254, 226, 226);       // Light error
    public static final Color ERROR_500 = new Color(239, 68, 68);         // Main error
    public static final Color ERROR_600 = new Color(220, 38, 38);         // Dark error
    public static final Color ERROR_700 = new Color(185, 28, 28);         // Darker error
    
    public static final Color INFO_50 = new Color(240, 249, 255);         // Info background
    public static final Color INFO_100 = new Color(224, 242, 254);        // Light info
    public static final Color INFO_500 = new Color(59, 130, 246);         // Main info
    public static final Color INFO_600 = new Color(37, 99, 235);          // Dark info
    public static final Color INFO_700 = new Color(29, 78, 216);          // Darker info
    
    // Text Colors - Optimized for readability
    public static final Color TEXT_PRIMARY = new Color(15, 23, 42);       // Almost black
    public static final Color TEXT_SECONDARY = new Color(51, 65, 85);     // Dark gray
    public static final Color SECONDARY_TEXT = TEXT_SECONDARY;            // Alias for backward compatibility
    public static final Color TEXT_TERTIARY = new Color(100, 116, 139);   // Lighter gray for tertiary text
    public static final Color TEXT_QUATERNARY = new Color(148, 163, 184); // Light gray
    public static final Color TEXT_PLACEHOLDER = new Color(156, 163, 175);// Placeholder text
    public static final Color TEXT_DISABLED = new Color(148, 163, 184);   // Light gray for disabled text
    public static final Color TEXT_INVERSE = new Color(255, 255, 255);    // White for text on dark backgrounds
    
    // Border Colors - Subtle border system
    public static final Color BORDER_LIGHT = new Color(241, 245, 249);    // Lightest border
    public static final Color BORDER_DEFAULT = new Color(226, 232, 240);  // Default border
    public static final Color BORDER_MEDIUM = new Color(203, 213, 225);   // Medium border
    public static final Color BORDER_DARK = new Color(203, 213, 225);     // Dark border
    public static final Color BORDER_FOCUS = PRIMARY_500;                 // Focus border (blue)
    public static final Color BORDER_SUCCESS = ACCENT_500;                // Success border (green)
    public static final Color BORDER_ERROR = ERROR_500;                   // Error border (red)
    public static final Color BORDER_ACCENT = PRIMARY_300;                // Accent border
    
    // Shadow Colors - Modern shadow system
    public static final Color SHADOW_LIGHT = new Color(0, 0, 0, 8);       // Very subtle shadow
    public static final Color SHADOW_DEFAULT = new Color(0, 0, 0, 12);    // Default shadow
    public static final Color SHADOW_MEDIUM = new Color(0, 0, 0, 20);     // Medium shadow
    public static final Color SHADOW_DARK = new Color(0, 0, 0, 30);       // Dark shadow
    public static final Color SHADOW_COLORED = new Color(59, 130, 246, 20); // Colored shadow
    
    // Font aliases for backward compatibility - moved to bottom of file
    
    // ===== BACKWARD COMPATIBILITY =====
    public static final Color PRIMARY = PRIMARY_500;
    public static final Color PRIMARY_HOVER = PRIMARY_600;
    public static final Color ACCENT = ACCENT_500;
    public static final Color TEXT = TEXT_PRIMARY;
    public static final Color MUTED_TEXT = TEXT_TERTIARY;
    public static final Color BORDER = BORDER_DEFAULT;
    public static final Color SHADOW = SHADOW_DEFAULT;
    
    // ===== ADDITIONAL UTILITY COLORS =====
    public static final Color SUCCESS = SUCCESS_500;
    public static final Color WARNING = WARNING_500;
    public static final Color ERROR = ERROR_500;
    public static final Color INFO = INFO_500;
    public static final Color DIVIDER = new Color(226, 232, 240);
    public static final Color SURFACE_HOVER = new Color(241, 245, 249);
    
    // ===== UTILITY METHODS =====
    
    /**
     * Creates a new color with the specified alpha value.
     * @param color The base color
     * @param alpha Alpha value (0-255)
     * @return A new color with the specified alpha
     */
    public static Color withAlpha(Color color, int alpha) {
        return ColorUtils.withAlpha(color, alpha);
    }
    
    /**
     * Creates a new color with the specified alpha value (0.0-1.0).
     * @param color The base color
     * @param alpha Alpha value (0.0-1.0)
     * @return A new color with the specified alpha
     */
    public static Color withAlphaFloat(Color color, float alpha) {
        return ColorUtils.withAlphaFloat(color, alpha);
    }
    
    // ===== MODERN TYPOGRAPHY SYSTEM =====
    
    // Display Fonts - For large headings and branding
    public static final Font DISPLAY_LARGE = new Font("Inter", Font.BOLD, 48);
    public static final Font DISPLAY_MEDIUM = new Font("Inter", Font.BOLD, 36);
    public static final Font DISPLAY_SMALL = new Font("Inter", Font.BOLD, 30);
    
    // Heading Fonts - For section headers
    public static final Font HEADING_1 = new Font("Inter", Font.BOLD, 24);
    public static final Font HEADING_2 = new Font("Inter", Font.BOLD, 20);
    public static final Font HEADING_3 = new Font("Inter", Font.BOLD, 18);
    public static final Font HEADING_4 = new Font("Inter", Font.BOLD, 16);
    public static final Font HEADING_5 = new Font("Inter", Font.BOLD, 14);
    public static final Font HEADING_6 = new Font("Inter", Font.BOLD, 12);
    
    // Body Fonts - For regular content
    public static final Font BODY_LARGE = new Font("Inter", Font.PLAIN, 16);
    public static final Font BODY_MEDIUM = new Font("Inter", Font.PLAIN, 14);
    public static final Font BODY_SMALL = new Font("Inter", Font.PLAIN, 12);
    public static final Font BODY_TINY = new Font("Inter", Font.PLAIN, 11);
    
    // Label Fonts - For form labels and UI elements
    public static final Font LABEL_LARGE = new Font("Inter", Font.PLAIN, 14);
    public static final Font LABEL_MEDIUM = new Font("Inter", Font.PLAIN, 12);
    public static final Font LABEL_SMALL = new Font("Inter", Font.PLAIN, 11);
    
    // Button Fonts - For interactive elements
    public static final Font BUTTON_LARGE = new Font("Inter", Font.BOLD, 16);
    public static final Font BUTTON_MEDIUM = new Font("Inter", Font.BOLD, 14);
    public static final Font BUTTON_SMALL = new Font("Inter", Font.BOLD, 12);
    
    // Code/Monospace Fonts - For technical content
    public static final Font CODE_LARGE = new Font("JetBrains Mono", Font.PLAIN, 14);
    public static final Font CODE_MEDIUM = new Font("JetBrains Mono", Font.PLAIN, 13);
    public static final Font CODE_SMALL = new Font("JetBrains Mono", Font.PLAIN, 12);
    
    // ===== BACKWARD COMPATIBILITY FONTS =====
    public static final Font H1 = HEADING_1;
    public static final Font H2 = HEADING_2;
    public static final Font BODY = BODY_MEDIUM;
    
    // ===== MODERN SPACING SYSTEM =====
    public static final int SPACE_1 = 4;    // 0.25rem
    public static final int SPACE_2 = 8;    // 0.5rem
    public static final int SPACE_3 = 12;   // 0.75rem
    public static final int SPACE_4 = 16;   // 1rem
    public static final int SPACE_5 = 20;   // 1.25rem
    public static final int SPACE_6 = 24;   // 1.5rem
    public static final int SPACE_8 = 32;   // 2rem
    public static final int SPACE_10 = 40;  // 2.5rem
    public static final int SPACE_12 = 48;  // 3rem
    public static final int SPACE_16 = 64;  // 4rem
    public static final int SPACE_20 = 80;  // 5rem
    public static final int SPACE_24 = 96;  // 6rem
    
    // ===== BORDER RADIUS SYSTEM =====
    public static final int RADIUS_NONE = 0;
    public static final int RADIUS_SM = 4;
    public static final int RADIUS_DEFAULT = 8;
    public static final int RADIUS_MD = 12;
    public static final int RADIUS_LG = 16;
    public static final int RADIUS_XL = 20;
    public static final int RADIUS_2XL = 24;
    public static final int RADIUS_FULL = 9999;
    
    // ===== ANIMATION DURATIONS =====
    public static final int DURATION_FAST = 150;     // Fast transitions
    public static final int DURATION_DEFAULT = 250;  // Default transitions  
    public static final int DURATION_SLOW = 400;     // Slow transitions
    public static final int DURATION_SLOWER = 600;   // Very slow transitions
    
    // ===== UTILITY METHODS =====
    
    /**
     * Apply modern defaults to a container
     */
    public static void applyDefaults(Container root) {
        if (root == null) return;
        root.setBackground(BACKGROUND);
        root.setForeground(TEXT_PRIMARY);
        if (root instanceof Component) {
            ((Component) root).setFont(BODY_MEDIUM);
        }
    }
    
    /**
     * Apply modern card styling to a container
     */
    public static void applyCardStyle(Container container) {
        if (container == null) return;
        container.setBackground(CARD_BG);
        container.setForeground(TEXT_PRIMARY);
    }
    
    /**
     * Create a modern gradient paint
     */
    public static GradientPaint createGradient(Color startColor, Color endColor, boolean vertical) {
        if (vertical) {
            return new GradientPaint(0, 0, startColor, 0, 100, endColor);
        } else {
            return new GradientPaint(0, 0, startColor, 100, 0, endColor);
        }
    }
    
    /**
     * Create a primary gradient
     */
    public static GradientPaint createPrimaryGradient(boolean vertical) {
        return createGradient(PRIMARY_400, PRIMARY_600, vertical);
    }
    
    /**
     * Create an accent gradient  
     */
    public static GradientPaint createAccentGradient(boolean vertical) {
        return createGradient(ACCENT_400, ACCENT_600, vertical);
    }
    
    /**
     * Create a success gradient
     */
    public static GradientPaint createSuccessGradient(boolean vertical) {
        return createGradient(SUCCESS_500, SUCCESS_600, vertical);
    }
    
    /**
     * Create a modern drop shadow
     */
    public static void drawShadow(Graphics2D g2, int x, int y, int width, int height, int radius) {
        g2.setColor(SHADOW_DEFAULT);
        g2.fillRoundRect(x + 2, y + 2, width, height, radius, radius);
        g2.setColor(SHADOW_LIGHT);
        g2.fillRoundRect(x + 1, y + 1, width, height, radius, radius);
    }
    
    /**
     * Create a modern border
     */
    public static void drawBorder(Graphics2D g2, int x, int y, int width, int height, int radius, Color borderColor) {
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(1.0f));
        g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
    }
    
    /**
     * Draw a modern focus ring
     */
    public static void drawFocusRing(Graphics2D g2, int x, int y, int width, int height, int radius) {
        g2.setColor(new Color(PRIMARY_500.getRed(), PRIMARY_500.getGreen(), PRIMARY_500.getBlue(), 80));
        g2.setStroke(new BasicStroke(3.0f));
        g2.drawRoundRect(x - 2, y - 2, width + 3, height + 3, radius + 2, radius + 2);
    }
    
    /**
     * Create a lighter version of a color
     */
    public static Color lighten(Color color, float factor) {
        int r = Math.min(255, (int)(color.getRed() * (1 + factor)));
        int g = Math.min(255, (int)(color.getGreen() * (1 + factor)));
        int b = Math.min(255, (int)(color.getBlue() * (1 + factor)));
        return new Color(r, g, b, color.getAlpha());
    }
    
    /**
     * Create a darker version of a color
     */
    public static Color darken(Color color, float factor) {
        int r = Math.max(0, (int)(color.getRed() * (1 - factor)));
        int g = Math.max(0, (int)(color.getGreen() * (1 - factor)));
        int b = Math.max(0, (int)(color.getBlue() * (1 - factor)));
        return new Color(r, g, b, color.getAlpha());
    }
    
    /**
     * Create a color with specified opacity
     */
    public static Color withOpacity(Color color, float opacity) {
        int alpha = Math.round(255 * Math.max(0, Math.min(1, opacity)));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }
    
    /**
     * Check if a color is considered "dark" (for contrast calculations)
     */
    public static boolean isDark(Color color) {
        double luminance = 0.299 * color.getRed() + 0.587 * color.getGreen() + 0.114 * color.getBlue();
        return luminance < 128;
    }
    
    /**
     * Get contrasting text color for a background
     */
    public static Color getContrastingTextColor(Color backgroundColor) {
        return isDark(backgroundColor) ? TEXT_INVERSE : TEXT_PRIMARY;
    }
    
    /**
     * Apply modern styling to graphics context
     */
    public static void setupModernRendering(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    }
    
    // ===== COMPONENT-SPECIFIC DEFAULTS =====
    
    /**
     * Default button colors and styling
     */
    public static class Button {
        public static final Color BACKGROUND = PRIMARY_500;
        public static final Color BACKGROUND_HOVER = PRIMARY_600;
        public static final Color BACKGROUND_ACTIVE = PRIMARY_700;
        public static final Color BACKGROUND_DISABLED = new Color(203, 213, 225); 
        public static final Color TEXT = TEXT_INVERSE;
        public static final Color TEXT_DISABLED = TEXT_QUATERNARY;
        public static final Font FONT = BUTTON_MEDIUM;
        public static final int PADDING_X = SPACE_4;
        public static final int PADDING_Y = SPACE_2;
        public static final int RADIUS = RADIUS_DEFAULT;
    }
    
    /**
     * Default input field colors and styling  
     */
    public static class Input {
        public static final Color BACKGROUND = SURFACE;
        public static final Color BACKGROUND_FOCUS = SURFACE;
        public static final Color BORDER = BORDER_DEFAULT;
        public static final Color BORDER_FOCUS = PRIMARY_500; 
        public static final Color BORDER_ERROR = ERROR_500;   
        public static final Color TEXT = TEXT_PRIMARY;
        public static final Color PLACEHOLDER = TEXT_PLACEHOLDER;
        public static final Font FONT = BODY_MEDIUM;
        public static final int PADDING_X = SPACE_3;
        public static final int PADDING_Y = SPACE_2;
        public static final int RADIUS = RADIUS_DEFAULT;
    }
    
    /**
     * Default card colors and styling
     */
    public static class Card {
        public static final Color BACKGROUND = CARD_BG;
        public static final Color BORDER = BORDER_LIGHT;
        public static final Color SHADOW = SHADOW_DEFAULT;
        public static final int PADDING = SPACE_6;
        public static final int RADIUS = RADIUS_LG;
    }
}