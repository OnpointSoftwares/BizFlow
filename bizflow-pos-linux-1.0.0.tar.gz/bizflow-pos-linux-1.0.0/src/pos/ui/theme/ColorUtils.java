package pos.ui.theme;

import java.awt.Color;

/**
 * Utility class for color manipulation.
 */
public class ColorUtils {
    
    /**
     * Creates a new color with the specified alpha value.
     * 
     * @param color The base color
     * @param alpha Alpha value (0-255)
     * @return A new color with the specified alpha
     */
    public static Color withAlpha(Color color, int alpha) {
        if (alpha < 0) alpha = 0;
        if (alpha > 255) alpha = 255;
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }
    
    /**
     * Creates a new color with the specified alpha value (0.0-1.0).
     * 
     * @param color The base color
     * @param alpha Alpha value (0.0-1.0)
     * @return A new color with the specified alpha
     */
    public static Color withAlphaFloat(Color color, float alpha) {
        return withAlpha(color, (int)(alpha * 255));
    }
    
    /**
     * Darkens a color by a given factor.
     * 
     * @param color The color to darken
     * @param factor The darkening factor (0.0-1.0)
     * @return The darkened color
     */
    public static Color darken(Color color, double factor) {
        return new Color(
            Math.max((int)(color.getRed() * (1 - factor)), 0),
            Math.max((int)(color.getGreen() * (1 - factor)), 0),
            Math.max((int)(color.getBlue() * (1 - factor)), 0),
            color.getAlpha()
        );
    }
    
    /**
     * Lightens a color by a given factor.
     * 
     * @param color The color to lighten
     * @param factor The lightening factor (0.0-1.0)
     * @return The lightened color
     */
    public static Color lighten(Color color, double factor) {
        return new Color(
            Math.min((int)(color.getRed() + (255 - color.getRed()) * factor), 255),
            Math.min((int)(color.getGreen() + (255 - color.getGreen()) * factor), 255),
            Math.min((int)(color.getBlue() + (255 - color.getBlue()) * factor), 255),
            color.getAlpha()
        );
    }
    
    /**
     * Checks if a color is considered dark.
     * 
     * @param color The color to check
     * @return true if the color is dark, false otherwise
     */
    public static boolean isDark(Color color) {
        // Calculate relative luminance (perceived brightness)
        double luminance = (0.299 * color.getRed() + 0.587 * color.getGreen() + 0.114 * color.getBlue()) / 255;
        return luminance < 0.5;
    }
    
    /**
     * Gets an appropriate text color (black or white) for a given background color.
     * 
     * @param backgroundColor The background color
     * @return Color.WHITE for dark backgrounds, Color.BLACK for light backgrounds
     */
    public static Color getContrastTextColor(Color backgroundColor) {
        return isDark(backgroundColor) ? Color.WHITE : Color.BLACK;
    }
}
