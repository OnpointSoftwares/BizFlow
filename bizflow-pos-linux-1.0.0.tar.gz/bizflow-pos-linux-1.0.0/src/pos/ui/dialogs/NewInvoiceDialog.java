package pos.ui.dialogs;

import pos.dao.ProductDAO;
import pos.models.Product;
import pos.models.Sale;
import pos.models.SaleItem;
import pos.ui.components.ModernButton;
import pos.ui.components.NumberField;
import pos.ui.theme.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.util.*;
import java.util.List;
import java.util.Currency;
import java.util.Locale;

public class NewInvoiceDialog extends JDialog {
    private final JTable itemsTable;
    private final JLabel totalLabel;
    private final JComboBox<Product> productCombo;
    private final NumberField quantityField;
    private final JButton addButton;
    private final JButton saveButton;
    private final JButton cancelButton;
    private final JTextField customerField;
    private final JComboBox<String> paymentMethodCombo;
    private final NumberField discountField;
    
    private final ItemsTableModel tableModel;
    private final NumberFormat currencyFormat;
    private double subtotal = 0.0;
    private double discount = 0.0;
    private double total = 0.0;
    
    private boolean saved = false;
    private Sale newSale;
    
    public NewInvoiceDialog(Frame owner) {
        super(owner, "New Invoice", true);
        setSize(900, 600);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));
        
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("sw", "KE"));
        currencyFormat.setCurrency(Currency.getInstance("KES"));
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        formPanel.setBackground(Theme.BACKGROUND);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Customer field
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Customer:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        customerField = new JTextField(20);
        formPanel.add(customerField, gbc);
        
        // Payment method
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Payment Method:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1;
        paymentMethodCombo = new JComboBox<>(new String[]{"Cash", "Card", "Mobile Money", "Bank Transfer"});
        formPanel.add(paymentMethodCombo, gbc);
        
        // Discount
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Discount (%):"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 2;
        discountField = new NumberField();
        discountField.setIntValue(0);
        discountField.addActionListener(e -> updateTotals());
        discountField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                updateTotals();
            }
        });
        formPanel.add(discountField, gbc);
        
        // Add to north
        JPanel northPanel = new JPanel(new BorderLayout());
        northPanel.add(formPanel, BorderLayout.NORTH);
        
        // Create items table
        tableModel = new ItemsTableModel();
        itemsTable = new JTable(tableModel);
        itemsTable.setRowHeight(30);
        itemsTable.setFillsViewportHeight(true);
        
        // Center align numeric columns
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        itemsTable.getColumnModel().getColumn(2).setCellRenderer(rightRenderer); // Price
        itemsTable.getColumnModel().getColumn(3).setCellRenderer(rightRenderer); // Total
        
        JScrollPane scrollPane = new JScrollPane(itemsTable);
        
        // Create product selection panel
        JPanel productPanel = new JPanel(new BorderLayout(5, 5));
        productPanel.setBorder(BorderFactory.createTitledBorder("Add Item"));
        productPanel.setBackground(Theme.BACKGROUND);
        
        try {
            List<Product> products = ProductDAO.listAll();
            productCombo = new JComboBox<>(products.toArray(new Product[0]));
            productCombo.setRenderer(new DefaultListCellRenderer() {
                @Override
                public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
                                                             boolean isSelected, boolean cellHasFocus) {
                    super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    if (value instanceof Product) {
                        Product p = (Product) value;
                        setText(String.format("%s - %s (KES %,.2f)", p.sku, p.name, p.sellingPrice));
                    }
                    return this;
                }
            });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading products: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
            throw new RuntimeException("Failed to initialize products", e);
        }
        
        quantityField = new NumberField();
        quantityField.setIntValue(1);
        
        addButton = new ModernButton("Add Item");
        addButton.addActionListener(e -> addItem());
        
        // Add enter key listener to quantity field
        quantityField.addActionListener(e -> addItem());
        
        JPanel productInputPanel = new JPanel(new GridBagLayout());
        productInputPanel.setBackground(Theme.BACKGROUND);
        
        GridBagConstraints pgc = new GridBagConstraints();
        pgc.fill = GridBagConstraints.HORIZONTAL;
        pgc.insets = new Insets(2, 2, 2, 2);
        
        pgc.gridx = 0; pgc.gridy = 0; pgc.weightx = 1.0;
        productInputPanel.add(productCombo, pgc);
        
        pgc.gridx = 1; pgc.gridy = 0; pgc.weightx = 0.1;
        productInputPanel.add(Box.createHorizontalStrut(10), pgc);
        
        pgc.gridx = 2; pgc.gridy = 0; pgc.weightx = 0.2;
        JPanel qtyPanel = new JPanel(new BorderLayout());
        qtyPanel.add(new JLabel("Qty:"), BorderLayout.WEST);
        qtyPanel.add(quantityField, BorderLayout.CENTER);
        productInputPanel.add(qtyPanel, pgc);
        
        pgc.gridx = 3; pgc.gridy = 0; pgc.weightx = 0.2;
        productInputPanel.add(addButton, pgc);
        
        productPanel.add(productInputPanel, BorderLayout.CENTER);
        
        // Create bottom panel with totals and buttons
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.setBackground(Theme.BACKGROUND);
        
        // Totals panel
        JPanel totalsPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        totalsPanel.setBorder(BorderFactory.createTitledBorder("Invoice Summary"));
        totalsPanel.setBackground(Theme.BACKGROUND);
        
        totalsPanel.add(new JLabel("Subtotal:"));
        JLabel subtotalLabel = new JLabel(currencyFormat.format(subtotal));
        subtotalLabel.setHorizontalAlignment(JLabel.RIGHT);
        totalsPanel.add(subtotalLabel);
        
        totalsPanel.add(new JLabel("Discount (" + discount + "%):"));
        JLabel discountLabel = new JLabel(currencyFormat.format(discount));
        discountLabel.setHorizontalAlignment(JLabel.RIGHT);
        totalsPanel.add(discountLabel);
        
        totalsPanel.add(new JLabel("Total:"));
        totalLabel = new JLabel(currencyFormat.format(total));
        totalLabel.setFont(totalLabel.getFont().deriveFont(Font.BOLD, 14f));
        totalLabel.setHorizontalAlignment(JLabel.RIGHT);
        totalsPanel.add(totalLabel);
        
        // Buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setBackground(Theme.BACKGROUND);
        
        cancelButton = new ModernButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        
        saveButton = new ModernButton("Save Invoice");
        saveButton.setBackground(Theme.ACCENT_500);
        saveButton.setForeground(Color.WHITE);
        saveButton.addActionListener(e -> saveInvoice());
        
        buttonsPanel.add(cancelButton);
        buttonsPanel.add(saveButton);
        
        bottomPanel.add(totalsPanel, BorderLayout.CENTER);
        bottomPanel.add(buttonsPanel, BorderLayout.SOUTH);
        
        // Add components to dialog
        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(productPanel, BorderLayout.SOUTH);
        add(bottomPanel, BorderLayout.EAST);
        
        // Set minimum sizes
        Dimension minSize = new Dimension(150, 30);
        productCombo.setMinimumSize(minSize);
        quantityField.setMinimumSize(new Dimension(60, 30));
        
        // Set preferred sizes for better layout
        scrollPane.setPreferredSize(new Dimension(600, 300));
        bottomPanel.setPreferredSize(new Dimension(250, 0));
        
        // Handle window closing
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        // Add keyboard shortcuts
        setupKeyboardShortcuts();
    }
    
    private void setupKeyboardShortcuts() {
        // Add item on Ctrl+Enter
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, KeyEvent.CTRL_DOWN_MASK), "addItem");
        getRootPane().getActionMap().put("addItem", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addItem();
            }
        });
        
        // Save on Ctrl+S
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.CTRL_DOWN_MASK), "saveInvoice");
        getRootPane().getActionMap().put("saveInvoice", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveInvoice();
            }
        });
        
        // Delete selected item on Delete key
        itemsTable.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), "deleteRow");
        itemsTable.getActionMap().put("deleteRow", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = itemsTable.getSelectedRow();
                if (row >= 0) {
                    tableModel.removeRow(row);
                    updateTotals();
                }
            }
        });
    }
    
    private void addItem() {
        Product product = (Product) productCombo.getSelectedItem();
        if (product == null) {
            JOptionPane.showMessageDialog(this, "Please select a product", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int quantity = quantityField.getValue();
        if (quantity <= 0) {
            JOptionPane.showMessageDialog(this, "Quantity must be greater than 0", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Check if product already exists in the table
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            SaleItem existingItem = tableModel.getItemAt(i);
            if (existingItem.productId == product.id) {
                // Update quantity if product already exists
                existingItem.qty += quantity;
                existingItem.lineTotal = existingItem.qty * existingItem.price;
                tableModel.fireTableRowsUpdated(i, i);
                updateTotals();
                quantityField.requestFocus();
                quantityField.selectAll();
                return;
            }
        }
        
        // Add new item
        SaleItem item = new SaleItem();
        item.productId = product.id;
        item.sku = product.sku;
        item.name = product.name;
        item.price = product.sellingPrice;
        item.qty = quantity;
        item.lineTotal = item.price * item.qty;
        
        tableModel.addItem(item);
        updateTotals();
        
        // Reset fields
        quantityField.setValue(1);
        quantityField.requestFocus();
        productCombo.requestFocus();
    }
    
    private void updateTotals() {
        subtotal = 0.0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            subtotal += tableModel.getItemAt(i).lineTotal;
        }
        
        discount = discountField.getIntValue();
        double discountAmount = subtotal * (discount / 100.0);
        total = subtotal - discountAmount;
        
        // Update labels
        ((JLabel)((JPanel)getContentPane().getComponent(3)).getComponent(0).getComponentAt(1, 0)).setText(currencyFormat.format(subtotal));
        ((JLabel)((JPanel)getContentPane().getComponent(3)).getComponent(0).getComponentAt(1, 1)).setText(currencyFormat.format(discountAmount));
        totalLabel.setText(currencyFormat.format(total));
    }
    
    private void saveInvoice() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please add at least one item to the invoice", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String customer = customerField.getText().trim();
        if (customer.isEmpty()) {
            customer = "Walk-in Customer";
        }
        
        String paymentMethod = (String) paymentMethodCombo.getSelectedItem();
        
        // Create new sale
        newSale = new Sale();
        newSale.customerName = customer;
        newSale.paymentMethod = paymentMethod;
        newSale.subtotal = subtotal;
        newSale.discount = subtotal * (discount / 100.0);
        newSale.total = total;
        
        // Add items
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            newSale.items.add(tableModel.getItemAt(i));
        }
        
        saved = true;
        dispose();
    }
    
    public boolean isSaved() {
        return saved;
    }
    
    public Sale getNewSale() {
        return newSale;
    }
    
    private class ItemsTableModel extends AbstractTableModel {
        private final String[] columnNames = {"Product", "Qty", "Price", "Total", ""};
        private final List<SaleItem> items = new ArrayList<>();
        
        @Override
        public int getRowCount() {
            return items.size();
        }
        
        @Override
        public int getColumnCount() {
            return columnNames.length;
        }
        
        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }
        
        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            SaleItem item = items.get(rowIndex);
            switch (columnIndex) {
                case 0: return item.name + " (" + item.sku + ")";
                case 1: return item.qty;
                case 2: return currencyFormat.format(item.price);
                case 3: return currencyFormat.format(item.lineTotal);
                case 4: return "Remove";
                default: return null;
            }
        }
        
        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return columnIndex == 4; // Only the remove button is editable
        }
        
        @Override
        public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
            if (columnIndex == 4) { // Remove button clicked
                items.remove(rowIndex);
                fireTableRowsDeleted(rowIndex, rowIndex);
            }
        }
        
        public void addItem(SaleItem item) {
            items.add(item);
            fireTableRowsInserted(items.size() - 1, items.size() - 1);
        }
        
        public void removeRow(int row) {
            if (row >= 0 && row < items.size()) {
                items.remove(row);
                fireTableRowsDeleted(row, row);
            }
        }
        
        public SaleItem getItemAt(int row) {
            return items.get(row);
        }
    }
}
