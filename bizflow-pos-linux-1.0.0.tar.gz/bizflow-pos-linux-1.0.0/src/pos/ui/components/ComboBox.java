package pos.ui.components;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.Vector;

/**
 * A custom ComboBox implementation for AWT that provides a modern look and feel.
 */
public class ComboBox<T> extends Component implements ItemSelectable {
    private Vector<T> items = new Vector<>();
    private int selectedIndex = -1;
    private boolean isOpen = false;
    private int hoveredIndex = -1;
    private ItemListener itemListener;
    private static final int DROPDOWN_HEIGHT = 200;
    private static final int ITEM_HEIGHT = 30;
    
    // Colors
    private static final Color BORDER_COLOR = new Color(203, 213, 225);
    private static final Color HOVER_COLOR = new Color(241, 245, 249);
    private static final Color SELECTED_COLOR = new Color(59, 130, 246);
    private static final Color TEXT_COLOR = new Color(30, 41, 59);
    private static final Color DROPDOWN_BG = Color.WHITE;
    private static final Color DROPDOWN_BORDER = new Color(226, 232, 240);
    
    public ComboBox() {
        enableEvents(AWTEvent.MOUSE_EVENT_MASK | AWTEvent.FOCUS_EVENT_MASK);
        setFocusable(true);
    }
    
    @Override
    public Object[] getSelectedObjects() {
        if (selectedIndex >= 0 && selectedIndex < items.size()) {
            return new Object[]{items.get(selectedIndex)};
        }
        return null;
    }
    
    public void addItem(T item) {
        items.add(item);
        if (selectedIndex == -1 && !items.isEmpty()) {
            setSelectedIndex(0);
        }
        repaint();
    }
    
    public void addItemListener(ItemListener listener) {
        itemListener = AWTEventMulticaster.add(itemListener, listener);
    }
    
    public void removeItemListener(ItemListener listener) {
        itemListener = AWTEventMulticaster.remove(itemListener, listener);
    }
    
    public void removeAllItems() {
        items.clear();
        selectedIndex = -1;
        repaint();
    }
    
    public T getSelectedItem() {
        return (selectedIndex >= 0 && selectedIndex < items.size()) ? items.get(selectedIndex) : null;
    }
    
    public void setSelectedItem(T item) {
        int index = items.indexOf(item);
        if (index != -1 && index != selectedIndex) {
            selectedIndex = index;
            ItemEvent event = createItemEvent(item, ItemEvent.SELECTED);
            fireItemStateChanged(event);
            repaint();
        }
    }
    
    public int getSelectedIndex() {
        return selectedIndex;
    }
    
    public void setSelectedIndex(int index) {
        if (index >= -1 && index < items.size() && index != selectedIndex) {
            if (selectedIndex != -1) {
                ItemEvent event = createItemEvent(items.get(selectedIndex), ItemEvent.DESELECTED);
                fireItemStateChanged(event);
            }
            selectedIndex = index;
            if (index != -1) {
                ItemEvent event = createItemEvent(items.get(selectedIndex), ItemEvent.SELECTED);
                fireItemStateChanged(event);
            }
            repaint();
        }
    }
    
    private void fireItemStateChanged(ItemEvent event) {
        if (itemListener != null) {
            itemListener.itemStateChanged(event);
        }
    }
    
    // Helper method to create ItemEvent with proper source
    private ItemEvent createItemEvent(T item, int stateChange) {
        return new ItemEvent(new ItemEventSource(), 
                           ItemEvent.ITEM_STATE_CHANGED,
                           item,
                           stateChange);
    }
    
    // Wrapper class to provide proper source for ItemEvent
    private class ItemEventSource implements ItemSelectable {
        @Override
        public Object[] getSelectedObjects() {
            return ComboBox.this.getSelectedObjects();
        }
        
        @Override
        public void addItemListener(ItemListener l) {
            ComboBox.this.addItemListener(l);
        }
        
        @Override
        public void removeItemListener(ItemListener l) {
            ComboBox.this.removeItemListener(l);
        }
    }
    
    @Override
    public Dimension getPreferredSize() {
        FontMetrics fm = getFontMetrics(getFont());
        int maxWidth = 0;
        for (T item : items) {
            int width = fm.stringWidth(item.toString());
            if (width > maxWidth) {
                maxWidth = width;
            }
        }
        // Add padding and arrow space
        return new Dimension(Math.max(100, maxWidth + 40), 36);
    }
    
    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Draw background and border
        g2.setColor(DROPDOWN_BG);
        g2.fillRoundRect(0, 0, width, height, 8, 8);
        
        // Draw border
        g2.setColor(hasFocus() ? SELECTED_COLOR : BORDER_COLOR);
        g2.setStroke(new BasicStroke(hasFocus() ? 2f : 1f));
        g2.drawRoundRect(0, 0, width - 1, height - 1, 8, 8);
        
        // Draw selected item text
        g2.setColor(TEXT_COLOR);
        g2.setFont(getFont());
        String text = selectedIndex != -1 ? items.get(selectedIndex).toString() : "";
        FontMetrics fm = g2.getFontMetrics();
        int textY = (height - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(text, 12, textY);
        
        // Draw arrow
        int arrowX = width - 24;
        int arrowY = height / 2 - 3;
        g2.setColor(TEXT_COLOR);
        g2.fillPolygon(
            new int[] {arrowX, arrowX + 8, arrowX + 16},
            new int[] {arrowY, arrowY + 6, arrowY},
            3
        );
        
        // Draw dropdown if open
        if (isOpen) {
            drawDropdown(g2);
        }
        
        g2.dispose();
    }
    
    private void drawDropdown(Graphics2D g2) {
        int width = getWidth();
        int y = getHeight();
        int itemCount = Math.min(items.size(), 10); // Show max 10 items at a time
        int dropdownHeight = itemCount * ITEM_HEIGHT + 2; // +2 for border
        
        // Draw dropdown background and border
        g2.setColor(DROPDOWN_BG);
        g2.fillRect(0, y, width - 1, dropdownHeight);
        g2.setColor(DROPDOWN_BORDER);
        g2.drawRect(0, y, width - 1, dropdownHeight);
        
        // Draw items
        g2.setFont(getFont());
        FontMetrics fm = g2.getFontMetrics();
        int textY = y + (ITEM_HEIGHT - fm.getHeight()) / 2 + fm.getAscent();
        
        for (int i = 0; i < itemCount; i++) {
            int itemY = y + i * ITEM_HEIGHT;
            
            // Highlight hovered item
            if (i == hoveredIndex) {
                g2.setColor(HOVER_COLOR);
                g2.fillRect(1, itemY + 1, width - 2, ITEM_HEIGHT - 1);
            }
            
            // Highlight selected item
            if (i == selectedIndex) {
                g2.setColor(SELECTED_COLOR);
                g2.fillRect(1, itemY + 1, 4, ITEM_HEIGHT - 1);
            }
            
            // Draw item text
            g2.setColor(i == selectedIndex ? SELECTED_COLOR : TEXT_COLOR);
            String text = items.get(i).toString();
            g2.drawString(text, 12, textY + i * ITEM_HEIGHT);
        }
    }
    
    @Override
    protected void processMouseEvent(MouseEvent e) {
        if (!isEnabled()) {
            return;
        }
        
        int width = getWidth();
        int height = getHeight();
        
        switch (e.getID()) {
            case MouseEvent.MOUSE_PRESSED:
                if (e.getButton() == MouseEvent.BUTTON1) {
                    if (isOpen) {
                        // Check if an item was clicked
                        int itemIndex = (e.getY() - height) / ITEM_HEIGHT;
                        if (itemIndex >= 0 && itemIndex < items.size()) {
                            setSelectedIndex(itemIndex);
                        }
                        isOpen = false;
                    } else {
                        isOpen = true;
                        hoveredIndex = -1;
                    }
                    repaint();
                    e.consume();
                }
                break;
                
            case MouseEvent.MOUSE_MOVED:
                if (isOpen) {
                    int newHovered = (e.getY() - height) / ITEM_HEIGHT;
                    if (newHovered >= 0 && newHovered < items.size() && newHovered != hoveredIndex) {
                        hoveredIndex = newHovered;
                        repaint();
                    }
                }
                break;
                
            case MouseEvent.MOUSE_EXITED:
                if (!isOpen) {
                    hoveredIndex = -1;
                    repaint();
                }
                break;
        }
        
        super.processMouseEvent(e);
    }
    
    @Override
    protected void processFocusEvent(FocusEvent e) {
        if (e.getID() == FocusEvent.FOCUS_LOST) {
            isOpen = false;
            repaint();
        }
        super.processFocusEvent(e);
    }
    
    @Override
    public boolean contains(int x, int y) {
        if (isOpen) {
            int dropdownHeight = Math.min(items.size(), 10) * ITEM_HEIGHT + 2;
            return x >= 0 && x < getWidth() && y >= 0 && y < getHeight() + dropdownHeight;
        }
        return super.contains(x, y);
    }
    
    @Override
    public Dimension getMinimumSize() {
        return new Dimension(100, 36);
    }
    
    @Override
    public Dimension getMaximumSize() {
        return new Dimension(Integer.MAX_VALUE, 36);
    }
}
