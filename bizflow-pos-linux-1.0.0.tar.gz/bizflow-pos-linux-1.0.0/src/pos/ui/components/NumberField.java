package pos.ui.components;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import java.util.Locale;

public class NumberField extends JTextField {
    private int value = 0;
    private final NumberFormat numberFormat;
    
    // Store the last valid text to handle invalid input
    private String lastValidText = "0";

    public NumberField() {
        super();
        numberFormat = NumberFormat.getIntegerInstance(Locale.getDefault());
        numberFormat.setGroupingUsed(false);
        
        setIntValue(0);
        setColumns(5);
        setHorizontalAlignment(RIGHT);
        
        // Only allow numbers
        ((PlainDocument) getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) 
                throws BadLocationException {
                
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + string;
                if (newText.matches("\\d*")) {
                    super.insertString(fb, offset, string, attr);
                    updateValue();
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) 
                throws BadLocationException {
                
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                String newText = currentText.substring(0, offset) + text + 
                               currentText.substring(offset + length);
                               
                if (newText.matches("\\d*")) {
                    super.replace(fb, offset, length, text, attrs);
                    updateValue();
                }
            }

            @Override
            public void remove(FilterBypass fb, int offset, int length) 
                throws BadLocationException {
                super.remove(fb, offset, length);
                updateValue();
            }
        });
        
        // Handle focus lost to ensure valid value
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                try {
                    String text = getText().trim();
                    if (text.isEmpty()) {
                        setIntValue(0);
                    } else {
                        setIntValue(Integer.parseInt(text));
                    }
                } catch (NumberFormatException e) {
                    setText(lastValidText);
                }
            }
        });
    }

    public int getIntValue() {
        return value;
    }

    public void setIntValue(int value) {
        int oldValue = this.value;
        this.value = Math.max(0, value); // Ensure value is not negative
        setText(numberFormat.format(this.value));
        firePropertyChange("value", oldValue, this.value);
    }

    private void updateValue() {
        try {
            String text = getText().trim();
            if (text.isEmpty()) {
                setIntValue(0);
            } else {
                int newValue = Integer.parseInt(text);
                if (newValue != value) {
                    setIntValue(newValue);
                }
            }
            lastValidText = getText();
        } catch (NumberFormatException e) {
            // If parsing fails, revert to the last valid value
            setText(lastValidText);
        }
    }

    // For backward compatibility with existing code
    public int getValue() {
        return getIntValue();
    }
    
    public void setValue(int value) {
        setIntValue(value);
    }

    @Override
    protected void processKeyEvent(KeyEvent e) {
        // Allow only digits and control keys
        if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' || 
            e.getKeyCode() == KeyEvent.VK_BACK_SPACE || 
            e.getKeyCode() == KeyEvent.VK_DELETE ||
            e.getKeyCode() == KeyEvent.VK_LEFT ||
            e.getKeyCode() == KeyEvent.VK_RIGHT ||
            e.getKeyCode() == KeyEvent.VK_HOME ||
            e.getKeyCode() == KeyEvent.VK_END ||
            e.isControlDown()) {
            
            super.processComponentKeyEvent(e);
        } else {
            e.consume();
        }
    }
}
