package pos.ui.components;

import pos.ui.theme.Theme;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class StyledTextField extends TextField {
    private String placeholder = "";
    private boolean focused = false;
    public StyledTextField() { this(20); }
    public StyledTextField(int cols) {
        super(cols);
        setBackground(new Color(245, 248, 252));
        setForeground(new Color(30, 30, 30));
        setFont(Theme.BODY);
        setForeground(Color.DARK_GRAY);
        setPreferredSize(new Dimension(200, 28));
        setEchoChar('\0');
        addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { focused = true; setBackground(new Color(235, 240, 250)); repaint(); }
            @Override public void focusLost(FocusEvent e) { focused = false; setBackground(new Color(245, 248, 252)); repaint(); }
        });
    }

    @Override
    public void paint(Graphics g){
        super.paint(g);
        if ((getText() == null || getText().isEmpty()) && placeholder != null && !placeholder.isEmpty() && !focused){
            Graphics2D g2=(Graphics2D)g;
            g2.setFont(Theme.BODY);
            g2.setColor(new Color(140,150,160));
            g2.drawString(placeholder, 6, getHeight()/2 + 5);
        }
        if (focused){
            Graphics2D g2=(Graphics2D)g;
            g2.setColor(new Color(0,120,215,120));
            g2.drawRect(0,0,getWidth()-1,getHeight()-1);
        }
    }

    public void setPlaceholder(String text){ this.placeholder = text; repaint(); }
}
