package pos;

import pos.db.Database;
import pos.ui.PosFrame;

public class Main {
    public static void main(String[] args) {
        try {
            Database.init();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to initialize database: " + e.getMessage());
            return;
        }
        new PosFrame();
    }
}
