package pos.db;

import java.io.File;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.*;
import pos.util.Security;

public class Database {
    private static final String DB_FILE = "pos.db";
    private static final String JDBC_URL = "jdbc:sqlite:" + DB_FILE;

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL);
    }

    public static void init() throws Exception {
        // Ensure JDBC driver is available
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("SQLite JDBC driver not found. Place sqlite-jdbc-<version>.jar into lib/ and run via build.sh");
            throw e;
        }
        boolean isNew = !new File(DB_FILE).exists();
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            try (Statement st = conn.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
                // products
                st.execute("CREATE TABLE IF NOT EXISTS products (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "sku TEXT UNIQUE NOT NULL, " +
                        "category TEXT, " +
                        "supplier_id INTEGER, " +
                        "purchase_price REAL NOT NULL, " +
                        "selling_price REAL NOT NULL, " +
                        "stock_qty INTEGER NOT NULL DEFAULT 0, " +
                        "expiry_date TEXT, " +
                        "created_at TEXT DEFAULT CURRENT_TIMESTAMP, " +
                        "updated_at TEXT DEFAULT CURRENT_TIMESTAMP, " +
                        "FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL" +
                        ")");
                // suppliers
                st.execute("CREATE TABLE IF NOT EXISTS suppliers (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "phone TEXT, " +
                        "email TEXT, " +
                        "address TEXT" +
                        ")");
                // sales
                st.execute("CREATE TABLE IF NOT EXISTS sales (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "invoice_no TEXT UNIQUE NOT NULL, " +
                        "user_id INTEGER, " +
                        "customer_name TEXT, " +
                        "payment_method TEXT, " +
                        "subtotal REAL NOT NULL, " +
                        "discount REAL NOT NULL DEFAULT 0, " +
                        "total REAL NOT NULL, " +
                        "created_at TEXT DEFAULT CURRENT_TIMESTAMP, " +
                        "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL" +
                        ")");
                // sales_items
                st.execute("CREATE TABLE IF NOT EXISTS sales_items (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "sale_id INTEGER NOT NULL, " +
                        "product_id INTEGER NOT NULL, " +
                        "sku TEXT NOT NULL, " +
                        "name TEXT NOT NULL, " +
                        "qty INTEGER NOT NULL, " +
                        "price REAL NOT NULL, " +
                        "line_total REAL NOT NULL, " +
                        "FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE, " +
                        "FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL" +
                        ")");
                // quotations
                st.execute("CREATE TABLE IF NOT EXISTS quotations (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "quote_no TEXT UNIQUE NOT NULL, " +
                        "customer_name TEXT, " +
                        "status TEXT NOT NULL DEFAULT 'pending', " +
                        "subtotal REAL NOT NULL, " +
                        "discount REAL NOT NULL DEFAULT 0, " +
                        "total REAL NOT NULL, " +
                        "created_at TEXT DEFAULT CURRENT_TIMESTAMP" +
                        ")");
                // quotation_items
                st.execute("CREATE TABLE IF NOT EXISTS quotation_items (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "quotation_id INTEGER NOT NULL, " +
                        "product_id INTEGER, " +
                        "sku TEXT NOT NULL, " +
                        "name TEXT NOT NULL, " +
                        "qty INTEGER NOT NULL, " +
                        "price REAL NOT NULL, " +
                        "line_total REAL NOT NULL, " +
                        "FOREIGN KEY(quotation_id) REFERENCES quotations(id) ON DELETE CASCADE, " +
                        "FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL" +
                        ")");
                // users
                st.execute("CREATE TABLE IF NOT EXISTS users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE NOT NULL, " +
                        "role TEXT NOT NULL, " +
                        "password_hash TEXT NOT NULL, " +
                        "salt TEXT NOT NULL" +
                        ")");

                // indexes
                st.execute("CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_sales_items_sale ON sales_items(sale_id)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)");
            }
            if (isNew) {
                seedDefaults(conn);
            }
            conn.commit();
        }
    }

    private static void seedDefaults(Connection conn) throws Exception {
        // Create default users: admin/admin, cashier/cashier (BCrypt)
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO users(username, role, password_hash, salt) VALUES (?,?,?,?)")) {
            insertUser(ps, "admin", "Admin", "admin");
            insertUser(ps, "cashier", "Cashier", "cashier");
        }
        // Sample supplier & product
        try (PreparedStatement sup = conn.prepareStatement("INSERT INTO suppliers(name, phone) VALUES(?,?)");
             PreparedStatement prod = conn.prepareStatement("INSERT INTO products(name, sku, category, supplier_id, purchase_price, selling_price, stock_qty) VALUES (?,?,?,?,?,?,?)")) {
            sup.setString(1, "Default Supplier");
            sup.setString(2, "");
            sup.executeUpdate();
            int supplierId;
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT id FROM suppliers LIMIT 1")) {
                supplierId = rs.next() ? rs.getInt(1) : 1;
            }
            prod.setString(1, "Sample Item");
            prod.setString(2, "SKU-001");
            prod.setString(3, "General");
            prod.setInt(4, supplierId);
            prod.setDouble(5, 50.0);
            prod.setDouble(6, 100.0);
            prod.setInt(7, 20);
            prod.executeUpdate();
        }
    }

    private static void insertUser(PreparedStatement ps, String username, String role, String password) throws Exception {
        String hash = Security.hashPassword(password);
        ps.setString(1, username);
        ps.setString(2, role);
        ps.setString(3, hash);
        ps.setString(4, ""); // salt unused (kept for backward compatibility)
        ps.executeUpdate();
    }

    public static boolean verifyPassword(String password, String saltHex, String expectedHash) throws Exception {
        // saltHex ignored; BCrypt stores salt inside the hash
        return Security.checkPassword(password, expectedHash);
    }

    private static String sha256Hex(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] dig = md.digest(s.getBytes("UTF-8"));
        return toHex(dig);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
