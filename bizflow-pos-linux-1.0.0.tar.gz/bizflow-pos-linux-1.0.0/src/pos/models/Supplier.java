package pos.models;

public class Supplier {
    public int id;
    public String name;
    public String phone;
    public String email;
    public String address;
}
