package pos.models;

public class User {
    public int id;
    public String username;
    public String role; // Admin or Cashier
    public String passwordHash;
    public String salt;
}
