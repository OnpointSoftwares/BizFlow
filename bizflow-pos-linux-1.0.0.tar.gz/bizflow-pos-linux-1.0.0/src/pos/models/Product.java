package pos.models;

public class Product {
    public int id;
    public String name;
    public String sku;
    public String category;
    public Integer supplierId;
    public double purchasePrice;
    public double sellingPrice;
    public int stockQty;
    public String expiryDate; // ISO yyyy-MM-dd or null

    public Product() {}

    public Product(int id, String name, String sku, String category, Integer supplierId, double purchasePrice, double sellingPrice, int stockQty, String expiryDate) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.category = category;
        this.supplierId = supplierId;
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.stockQty = stockQty;
        this.expiryDate = expiryDate;
    }
}
