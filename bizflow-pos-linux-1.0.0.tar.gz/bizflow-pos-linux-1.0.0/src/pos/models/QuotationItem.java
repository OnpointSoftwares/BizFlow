package pos.models;

public class QuotationItem {
    public int id;
    public int quotationId;
    public Integer productId;
    public String sku;
    public String name;
    public int qty;
    public double price;
    public double lineTotal;
}
