package pos.models;

import java.util.ArrayList;
import java.util.List;

public class Sale {
    public int id;
    public String invoiceNo;
    public Integer userId;
    public String customerName;
    public String paymentMethod; // cash, card, mobile
    public double subtotal;
    public double discount;
    public double total;
    public List<SaleItem> items = new ArrayList<>();
}
