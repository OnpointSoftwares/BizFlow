package pos.dao;

import pos.db.Database;
import pos.models.User;

import java.sql.*;

public class UserDAO {
    public static User findByUsername(String username) throws Exception {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement("SELECT id,username,role,password_hash,salt FROM users WHERE username=?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                User u = new User();
                u.id = rs.getInt("id");
                u.username = rs.getString("username");
                u.role = rs.getString("role");
                u.passwordHash = rs.getString("password_hash");
                u.salt = rs.getString("salt");
                return u;
            }
        }
    }
}
