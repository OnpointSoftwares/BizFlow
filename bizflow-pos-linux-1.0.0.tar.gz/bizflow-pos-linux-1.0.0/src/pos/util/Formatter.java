package pos.util;

import java.text.DecimalFormat;

public class Formatter {
    private static final DecimalFormat MONEY = new DecimalFormat("#,##0.00");
    public static String money(double v) { return MONEY.format(v); }
}
