package pos.util;

import java.text.NumberFormat;
import java.util.Locale;

public class CurrencyUtil {
    private static final NumberFormat CURRENCY_FORMAT;
    
    static {
        CURRENCY_FORMAT = NumberFormat.getCurrencyInstance(new Locale("sw", "KE"));
        CURRENCY_FORMAT.setCurrency(java.util.Currency.getInstance("KES"));
    }
    
    public static String format(double amount) {
        return CURRENCY_FORMAT.format(amount);
    }
    
    public static String format(long amount) {
        return CURRENCY_FORMAT.format(amount);
    }
    
    public static String formatCurrencyOnly(double amount) {
        return String.format("KES %,.2f", amount);
    }
}
