package pos.util;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import pos.models.Sale;
import pos.models.SaleItem;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PdfUtil {
    public static void exportSale(Sale sale, File outFile) throws IOException {
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.LETTER);
            doc.addPage(page);
            PDRectangle rect = page.getMediaBox();
            float margin = 40;
            float y = rect.getUpperRightY() - margin;
            try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
                // Header
                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_BOLD, 16);
                cs.newLineAtOffset(margin, y);
                cs.showText("Invoice " + (sale.invoiceNo != null ? sale.invoiceNo : ("INV" + sale.id)));
                cs.endText();

                y -= 22;
                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA, 10);
                cs.newLineAtOffset(margin, y);
                String created = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                cs.showText("Date: " + created + "   Customer: " + (sale.customerName != null ? sale.customerName : "Walk-in"));
                cs.endText();

                // Table header
                y -= 28;
                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_BOLD, 11);
                cs.newLineAtOffset(margin, y);
                cs.showText(pad("Item", 32) + pad("Qty", 6) + pad("Price", 12) + pad("Total", 12));
                cs.endText();
                y -= 16;

                // Items
                cs.setFont(PDType1Font.HELVETICA, 10);
                for (SaleItem it : sale.items) {
                    String name = it.name != null ? it.name : (it.sku != null ? it.sku : "Item");
                    String line = pad(trim(name, 30), 32) + pad(String.valueOf(it.qty), 6) + pad(Formatter.money(it.price), 12) + pad(Formatter.money(it.lineTotal), 12);
                    cs.beginText();
                    cs.newLineAtOffset(margin, y);
                    cs.showText(line);
                    cs.endText();
                    y -= 14;
                    if (y < margin + 120) {
                        cs.close();
                        page = new PDPage(PDRectangle.LETTER);
                        doc.addPage(page);
                        y = page.getMediaBox().getUpperRightY() - margin;
                        // new content stream for new page
                        try (PDPageContentStream cs2 = new PDPageContentStream(doc, page)) {
                            y -= 16;
                        }
                        // reopen stream append mode for following operations
                        // but for simplicity we create a new stream per line below
                    }
                }

                // Totals
                y -= 10;
                drawRightAligned(cs, "Subtotal: " + Formatter.money(sale.subtotal), rect, margin, y);
                y -= 14;
                drawRightAligned(cs, "Discount: " + Formatter.money(sale.discount), rect, margin, y);
                y -= 14;
                drawRightAligned(cs, "Total: " + Formatter.money(sale.total), rect, margin, y);
                y -= 20;
                drawRightAligned(cs, "Payment: " + (sale.paymentMethod != null ? sale.paymentMethod : "cash"), rect, margin, y);

                // Footer
                y = margin;
                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_OBLIQUE, 9);
                cs.newLineAtOffset(margin, y);
                cs.showText("Thank you for your purchase.");
                cs.endText();
            }
            doc.save(outFile);
        }
    }

    private static void drawRightAligned(PDPageContentStream cs, String text, PDRectangle rect, float margin, float y) throws IOException {
        cs.beginText();
        cs.setFont(PDType1Font.HELVETICA_BOLD, 11);
        float textWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(text) / 1000f * 11f;
        cs.newLineAtOffset(rect.getUpperRightX() - margin - textWidth, y);
        cs.showText(text);
        cs.endText();
    }

    private static String pad(String s, int n){
        if (s == null) s = "";
        if (s.length() >= n) return s;
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < n) sb.append(' ');
        return sb.toString();
    }

    private static String trim(String s, int n){
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n-1) + "…" : s;
    }
}
