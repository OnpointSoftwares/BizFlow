# BizFlow POS Deployment Guide

This guide explains how to deploy the BizFlow POS application on both Windows and Linux systems.

## Prerequisites

- Java 11 or later (JRE or JDK)
- SQLite (included in the application)
- For Windows: Windows 10/11
- For Linux: Any modern distribution with Java 11+

## Windows Deployment

### Option 1: Using Pre-built Package

1. Download the latest `bizflow-pos-windows.zip` from the releases page
2. Extract the ZIP file to your desired location
3. Double-click `run-pos.bat` to start the application

### Option 2: Building from Source

1. Install Java Development Kit (JDK) 11 or later
2. Clone the repository or download the source code
3. Open Command Prompt in the project directory
4. Run the following commands:
   ```
   build.bat
   package.bat
   ```
5. The built package will be available as `bizflow-pos-windows.zip`

## Linux Deployment

### Option 1: Using Pre-built Package

1. Download the latest `bizflow-pos-linux.tar.gz` from the releases page
2. Extract the archive:
   ```bash
   tar -xzf bizflow-pos-linux.tar.gz
   cd target
   ```
3. Make the script executable:
   ```bash
   chmod +x run-pos.sh
   ```
4. Run the application:
   ```bash
   ./run-pos.sh
   ```

### Option 2: Building from Source

1. Install OpenJDK 11 or later:
   ```bash
   # For Debian/Ubuntu
   sudo apt update
   sudo apt install openjdk-11-jdk
   
   # For RHEL/CentOS
   sudo yum install java-11-openjdk-devel
   ```

2. Clone the repository or download the source code
3. Navigate to the project directory and run:
   ```bash
   chmod +x build.sh package.sh
   ./build.sh
   ./package.sh
   ```
4. The built package will be available as `bizflow-pos-linux.tar.gz`

## Database Configuration

The application uses SQLite for data storage. The database file (`bizflow_pos.db`) will be automatically created in the user's home directory in a `.bizflow-pos` folder.

### Custom Database Location

To use a custom database location, set the `BIZFLOW_DB_PATH` environment variable before starting the application:

```bash
# Linux/macOS
export BIZFLOW_DB_PATH=/path/to/your/database.db

# Windows
set BIZFLOW_DB_PATH=C:\path\to\your\database.db
```

## Troubleshooting

### Java Version Issues

If you encounter Java version errors, verify your Java version:

```bash
java -version
```

Ensure it shows version 11 or later. If not, install the correct version and update your `JAVA_HOME` environment variable.

### Missing Dependencies

If you see `ClassNotFoundException` or similar errors, ensure all required JAR files are in the `lib/` directory:

- sqlite-jdbc-*.jar (required)
- Any other dependencies your application needs

## Creating a Desktop Shortcut (Optional)

### Windows

1. Right-click on your desktop
2. Select New > Shortcut
3. Enter the path to `java -jar "path\to\bizflow-pos.jar"`
4. Name the shortcut "BizFlow POS"
5. Right-click the shortcut, select Properties, and set the icon

### Linux (GNOME)

1. Create a `.desktop` file in `~/.local/share/applications/`:
   ```
   [Desktop Entry]
   Name=BizFlow POS
   Comment=BizFlow Point of Sale System
   Exec=/path/to/run-pos.sh
   Icon=/path/to/icon.png
   Terminal=false
   Type=Application
   Categories=Office;
   ```
2. Make it executable:
   ```bash
   chmod +x ~/.local/share/applications/bizflow-pos.desktop
   ```

## Updating the Application

To update the application:

1. Stop the running application
2. Backup your database (found in `~/.bizflow-pos/bizflow_pos.db`)
3. Replace the application files with the new version
4. Start the application again
