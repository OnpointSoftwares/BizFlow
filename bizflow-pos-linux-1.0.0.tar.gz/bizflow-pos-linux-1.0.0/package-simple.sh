#!/bin/bash
# Simple packaging script for BizFlow POS

set -e

# Configuration
VERSION="1.0.0"
APP_NAME="bizflow-pos"
DIST_DIR="dist"
LINUX_PKG_DIR="$DIST_DIR/$APP_NAME-linux-$VERSION"
WIN_PKG_DIR="$DIST_DIR/$APP_NAME-windows-$VERSION"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Packaging BizFlow POS $VERSION ===${NC}"

# Clean previous builds
rm -rf "$DIST_DIR"
mkdir -p "$DIST_DIR"

# Create Linux package
echo "Creating Linux package..."
mkdir -p "$LINUX_PKG_DIR"

# Copy application files
cp -r * "$LINUX_PKG_DIR/" 2>/dev/null || true

# Remove unnecessary files
rm -f "$LINUX_PKG_DIR/"*.deb "$LINUX_PKG_DIR/"*.tar.gz "$LINUX_PKG_DIR/"*.zip
rm -rf "$LINUX_PKG_DIR/dist" "$LINUX_PKG_DIR/.git" "$LINUX_PKG_DIR/.idea" "$LINUX_PKG_DIR/.vscode"

# Make scripts executable
chmod +x "$LINUX_PKG_DIR/linux-installer.sh"
chmod +x "$LINUX_PKG_DIR/bizflow-launcher.sh"

# Create Linux tarball
echo "Creating Linux tarball..."
tar -czf "$DIST_DIR/${APP_NAME}-linux-${VERSION}.tar.gz" -C "$DIST_DIR" "$(basename "$LINUX_PKG_DIR")"

# Create Windows package
echo -e "\n${YELLOW}Creating Windows package...${NC}"
mkdir -p "$WIN_PKG_DIR"

# Copy application files
cp -r * "$WIN_PKG_DIR/" 2>/dev/null || true

# Clean up Windows package
rm -f "$WIN_PKG_DIR/"*.deb "$WIN_PKG_DIR/"*.tar.gz "$WIN_PKG_DIR/"*.sh "$WIN_PKG_DIR/"*.ps1
rm -rf "$WIN_PKG_DIR/dist" "$WIN_PKG_DIR/.git" "$WIN_PKG_DIR/.idea" "$WIN_PKG_DIR/.vscode"

# Create Windows launcher
cat > "$WIN_PKG_DIR/Start-BizFlowPOS.bat" << 'EOL'
@echo off
title BizFlow POS Launcher

echo Starting BizFlow POS...
java -cp ".;lib\*" pos.Main

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Error: Failed to start BizFlow POS
    echo Please make sure Java is installed and try again
    echo.
    pause
)
EOL

# Create Windows ZIP
echo "Creating Windows ZIP archive..."
cd "$DIST_DIR"
zip -r "${APP_NAME}-windows-${VERSION}.zip" "$(basename "$WIN_PKG_DIR")"
cd ..

# Clean up
rm -rf "$LINUX_PKG_DIR" "$WIN_PKG_DIR"

# Create installation instructions
cat > "$DIST_DIR/INSTALL.txt" << 'EOL'
=== BizFlow POS Installation Instructions ===

Linux Installation:
------------------
1. Extract the Linux package:
   tar -xzf bizflow-pos-linux-1.0.0.tar.gz
   cd bizflow-pos-linux-1.0.0

2. Run the installer (requires root/sudo):
   sudo ./linux-installer.sh

3. After installation, you can run the application by:
   - Using the application menu (search for "BizFlow POS")
   - Or by typing 'bizflow-pos' in the terminal

Windows Installation:
--------------------
1. Extract the Windows package (bizflow-pos-windows-1.0.0.zip)
2. Double-click 'Start-BizFlowPOS.bat' to run the application
3. If you get Java errors, make sure you have Java 11 or later installed

System Requirements:
------------------
- Java 11 or later
- At least 2GB RAM
- At least 200MB free disk space

Troubleshooting:
---------------
- If you get 'Java not found' errors, install Java from https://adoptium.net/
- On Linux, if you get permission errors, try: chmod +x *.sh
- For other issues, please contact support@bizflow.com
EOL

# Final output
echo -e "\n${GREEN}Packaging complete!${NC}"
echo -e "\nCreated packages in the 'dist' directory:"
echo -e "- ${GREEN}Linux:${NC}   $PWD/$DIST_DIR/${APP_NAME}-linux-${VERSION}.tar.gz"
echo -e "- ${GREEN}Windows:${NC} $PWD/$DIST_DIR/${APP_NAME}-windows-${VERSION}.zip"
echo -e "\nInstallation instructions are available in $PWD/$DIST_DIR/INSTALL.txt"
