#!/bin/bash
# Linux installer for BizFlow POS
# Run with: sudo ./linux-installer.sh

set -e  # Exit on error

# Configuration
APP_NAME="bizflow-pos"
INSTALL_DIR="/opt/$APP_NAME"
DESKTOP_DIR="/usr/share/applications"
ICON_DIR="/usr/share/icons/hicolor/256x256/apps"
BIN_DIR="/usr/local/bin"
JAVA_URL="https://download.java.com/java/GA/jdk11/9/GPL/openjdk-11.0.2_linux-x64_bin.tar.gz"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${YELLOW}This script requires root privileges. Restarting with sudo...${NC}"
    exec sudo "$0" "$@"
    exit $?
fi

echo -e "\n${GREEN}=== BizFlow POS Installer ===${NC}\n"

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check and install Java 11+
check_java() {
    echo -n "Checking Java installation... "
    
    if command_exists java; then
        JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
        if [[ $JAVA_VERSION =~ ^11\. ]]; then
            echo -e "${GREEN}Java $JAVA_VERSION is already installed${NC}"
            return 0
        else
            echo -e "${YELLOW}Found Java $JAVA_VERSION, but version 11+ is required${NC}"
        fi
    else
        echo -e "${YELLOW}Java not found${NC}"
    fi
    
    # Install OpenJDK 11
    echo -e "Installing OpenJDK 11..."
    
    if command_exists apt-get; then
        # Debian/Ubuntu
        apt-get update
        apt-get install -y openjdk-11-jdk
    elif command_exists yum; then
        # RHEL/CentOS
        yum install -y java-11-openjdk-devel
    elif command_exists dnf; then
        # Fedora
        dnf install -y java-11-openjdk-devel
    elif command_exists pacman; then
        # Arch Linux
        pacman -S --noconfirm jdk11-openjdk
    else
        echo -e "${YELLOW}Package manager not supported. Please install Java 11+ manually.${NC}"
        return 1
    fi
    
    # Verify installation
    if ! command_exists java; then
        echo -e "${RED}Failed to install Java. Please install Java 11+ manually.${NC}"
        return 1
    fi
    
    echo -e "${GREEN}Java installed successfully${NC}"
}

# Create application directory
echo -e "Installing $APP_NAME to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"

# Copy application files
echo "Copying application files..."
cp -r ./* "$INSTALL_DIR/"

# Create desktop entry
echo "Creating desktop entry..."
cat > "$DESKTOP_DIR/$APP_NAME.desktop" <<EOL
[Desktop Entry]
Version=1.0
Type=Application
Name=BizFlow POS
Comment=BizFlow Point of Sale System
Exec=$INSTALL_DIR/run-pos.sh
Icon=$INSTALL_DIR/assets/icon.png
Terminal=false
Categories=Office;
EOL

# Create application launcher
echo "Creating application launcher..."
cat > "$INSTALL_DIR/run-pos.sh" << 'EOL'
#!/bin/bash
# Run BizFlow POS

# Get the directory of this script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Set working directory
cd "$SCRIPT_DIR"

# Check if Java is installed
if ! command -v java >/dev/null 2>&1; then
    echo "Error: Java is not installed or not in PATH"
    echo "Please install Java 11 or later and try again"
    exit 1
fi

# Run the application with full path to ensure it works
java -cp "$SCRIPT_DIR/out:$SCRIPT_DIR/lib/*" pos.Main "$@"
EOL

# Make launcher executable
chmod +x "$INSTALL_DIR/run-pos.sh"

# Install the launcher script
cp bizflow-launcher.sh "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/bizflow-launcher.sh"

# Create a symlink in /usr/local/bin
ln -sf "$INSTALL_DIR/bizflow-launcher.sh" "$BIN_DIR/$APP_NAME"

# Set permissions
chown -R root:root "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"

# Create application data directory
APP_DATA_DIR="/var/lib/$APP_NAME"
mkdir -p "$APP_DATA_DIR"
chmod 775 "$APP_DATA_DIR"
chown -R $SUDO_USER:$(id -gn $SUDO_USER) "$APP_DATA_DIR"

# Set database path
export BIZFLOW_DB_PATH="$APP_DATA_DIR/bizflow_pos.db"
echo "BIZFLOW_DB_PATH=$BIZFLOW_DB_PATH" | tee /etc/default/$APP_NAME

# Create uninstaller
cat > "$INSTALL_DIR/uninstall.sh" << 'EOL'
#!/bin/bash
# Uninstall BizFlow POS

# Configuration
APP_NAME="bizflow-pos"
INSTALL_DIR="/opt/$APP_NAME"
DESKTOP_DIR="/usr/share/applications"
BIN_DIR="/usr/local/bin"
APP_DATA_DIR="/var/lib/$APP_NAME"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "This script requires root privileges. Please run with sudo."
    exit 1
fi

# Remove application files
echo "Removing application files..."
rm -rf "$INSTALL_DIR"

# Remove desktop entry
echo "Removing desktop entry..."
rm -f "$DESKTOP_DIR/$APP_NAME.desktop"

# Remove binary symlink
rm -f "$BIN_DIR/$APP_NAME"

# Remove application data (ask for confirmation)
read -p "Do you want to remove all application data in $APP_DATA_DIR? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "$APP_DATA_DIR"
    echo "Application data removed."
else
    echo "Application data preserved at $APP_DATA_DIR"
fi

echo "$APP_NAME has been uninstalled."
EOL

chmod +x "$INSTALL_DIR/uninstall.sh"

# Update icon cache (if applicable)
if command_exists gtk-update-icon-cache; then
    gtk-update-icon-cache -f -t /usr/share/icons/hicolor
fi

# Verify installation
echo -e "\n${GREEN}Verifying installation...${NC}"

# Check if the application runs
echo -n "Testing application launch... "
if output=$("$BIN_DIR/$APP_NAME" --version 2>&1); then
    echo -e "${GREEN}OK${NC}"
    echo -e "\n${GREEN}Installation verified successfully!${NC}"
else
    echo -e "${RED}FAILED${NC}"
    echo -e "${YELLOW}Installation verification failed. Output:${NC}"
    echo "$output"
    echo -e "\n${YELLOW}Attempting to fix installation...${NC}"
    
    # Try to fix classpath issues
    echo "Fixing classpath..."
    cd "$INSTALL_DIR"
    if [ ! -d "out" ]; then
        echo "Compiling source files..."
        mkdir -p out
        javac -d out -cp "lib/*" $(find src -name "*.java")
    fi
    
    # Test again
    echo -n "Retesting application launch... "
    if output=$("$BIN_DIR/$APP_NAME" --version 2>&1); then
        echo -e "${GREEN}FIXED${NC}"
        echo -e "\n${GREEN}Installation completed successfully after fixes!${NC}"
    else
        echo -e "${RED}FAILED TO FIX${NC}"
        echo -e "\n${RED}Installation completed with errors. Please check the output above.${NC}"
        echo "You can try running the application manually with:"
        echo "  cd $INSTALL_DIR && java -cp \"out:lib/*\" pos.Main"
        exit 1
    fi
fi
echo -e "\n${GREEN}BizFlow POS has been installed successfully!${NC}"
echo -e "\nYou can now run it by:"
echo -e "- Searching for 'BizFlow POS' in your applications menu"
echo -e "- Or by running '${YELLOW}$APP_NAME${NC}' in the terminal"
echo -e "\nThe database is stored at: ${YELLOW}$APP_DATA_DIR/bizflow_pos.db${NC}"
echo -e "\nTo uninstall, run: ${YELLOW}sudo $INSTALL_DIR/uninstall.sh${NC}\n"
