#!/usr/bin/env bash
set -euo pipefail
mkdir -p out
if [ ! -d lib ]; then
  echo "lib/ not found. Create it and place sqlite-jdbc-<version>.jar (and optional jars) inside." >&2
  exit 1
fi
# Compile targeting Java 11 for compatibility with JRE 11 (classfile version 55)
javac --release 11 -encoding UTF-8 -cp "lib/*" -d out $(find src -name "*.java")
echo "Build successful."
