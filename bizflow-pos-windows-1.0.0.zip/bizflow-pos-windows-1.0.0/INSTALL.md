# BizFlow POS Installation Guide

## Windows Installation

1. **Download the Installer**
   - Download the latest `BizFlow-POS-Installer.exe` from the releases page

2. **Run the Installer**
   - Double-click the downloaded file
   - If prompted by Windows SmartScreen, click "More info" and then "Run anyway"
   - Click "Yes" when prompted by User Account Control (UAC)
   - Follow the on-screen instructions

3. **Launch the Application**
   - A shortcut will be created on your desktop
   - Double-click the "BizFlow POS" icon to start the application

## Linux Installation

### Option 1: Using the Installer (Recommended)

1. **Download the Installer**
   ```bash
   wget https://github.com/yourusername/bizflow-pos/releases/latest/download/linux-installer.sh
   chmod +x linux-installer.sh
   ```

2. **Run the Installer**
   ```bash
   sudo ./linux-installer.sh
   ```

3. **Launch the Application**
   - Search for "BizFlow POS" in your applications menu
   - Or run `bizflow-pos` in the terminal

### Option 2: Using Package Manager (For Advanced Users)

#### Debian/Ubuntu
```bash
# Add repository (if available)
# wget -qO - https://your-repo.com/KEY.gpg | sudo apt-key add -
# echo "deb https://your-repo.com/ stable main" | sudo tee /etc/apt/sources.list.d/bizflow-pos.list

# Install
sudo apt update
sudo apt install bizflow-pos
```

#### RHEL/CentOS
```bash
# Add repository (if available)
# sudo rpm --import https://your-repo.com/KEY.gpg
# sudo yum-config-manager --add-repo https://your-repo.com/repo/bizflow-pos.repo

# Install
sudo yum install bizflow-pos
```

## System Requirements

### Windows
- Windows 10/11 (64-bit)
- 4GB RAM minimum (8GB recommended)
- 500MB free disk space
- Internet connection (for initial setup)

### Linux
- Any modern Linux distribution (64-bit)
- 4GB RAM minimum (8GB recommended)
- 500MB free disk space
- Java 11 or later (will be installed automatically if needed)

## Troubleshooting

### Common Issues

#### Windows
- **Java not found**: The installer will attempt to install Java automatically. If it fails, please install Java 11+ manually.
- **Missing DLL errors**: Install the latest Windows updates and Visual C++ Redistributable.

#### Linux
- **Permission denied**: Make sure to run the installer with `sudo`.
- **Java issues**: Run `sudo apt install openjdk-11-jdk` (or equivalent for your distribution).

### Getting Help
If you encounter any issues, please:
1. Check the log file at `~/.bizflow-pos/error.log`
2. Visit our [support page](https://github.com/yourusername/bizflow-pos/issues)
3. Contact support@bizflow.com

## Uninstallation

### Windows
1. Go to Settings > Apps > Apps & features
2. Find "BizFlow POS" in the list
3. Click Uninstall

### Linux
```bash
sudo /opt/bizflow-pos/uninstall.sh
```

## Data Backup
Your data is stored in:
- Windows: `%APPDATA%\BizFlow POS\bizflow_pos.db`
- Linux: `/var/lib/bizflow-pos/bizflow_pos.db`

Make sure to back up this file before uninstalling or reinstalling the application.
