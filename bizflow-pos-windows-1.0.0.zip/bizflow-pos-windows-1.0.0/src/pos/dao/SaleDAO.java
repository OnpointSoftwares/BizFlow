package pos.dao;

import pos.db.Database;
import pos.models.Sale;
import pos.models.SaleItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaleDAO {
    public static int createSale(Sale sale) throws Exception {
        try (Connection c = Database.getConnection()) {
            c.setAutoCommit(false);
            try {
                String inv = sale.invoiceNo;
                if (inv == null || inv.isEmpty()) inv = generateInvoiceNo(c);
                sale.invoiceNo = inv;
                try (PreparedStatement ps = c.prepareStatement("INSERT INTO sales(invoice_no,user_id,customer_name,payment_method,subtotal,discount,total) VALUES(?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, sale.invoiceNo);
                    if (sale.userId == null) ps.setNull(2, Types.INTEGER); else ps.setInt(2, sale.userId);
                    ps.setString(3, sale.customerName);
                    ps.setString(4, sale.paymentMethod);
                    ps.setDouble(5, sale.subtotal);
                    ps.setDouble(6, sale.discount);
                    ps.setDouble(7, sale.total);
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) sale.id = rs.getInt(1);
                    }
                }
                try (PreparedStatement psi = c.prepareStatement("INSERT INTO sales_items(sale_id,product_id,sku,name,qty,price,line_total) VALUES(?,?,?,?,?,?,?)")) {
                    for (SaleItem it : sale.items) {
                        psi.setInt(1, sale.id);
                        psi.setInt(2, it.productId);
                        psi.setString(3, it.sku);
                        psi.setString(4, it.name);
                        psi.setInt(5, it.qty);
                        psi.setDouble(6, it.price);
                        psi.setDouble(7, it.lineTotal);
                        psi.addBatch();

                        // Atomic stock reduce with availability check
                        try (PreparedStatement upd = c.prepareStatement("UPDATE products SET stock_qty = stock_qty - ?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND stock_qty >= ?")) {
                            upd.setInt(1, it.qty);
                            upd.setInt(2, it.productId);
                            upd.setInt(3, it.qty);
                            int affected = upd.executeUpdate();
                            if (affected == 0) {
                                throw new SQLException("Insufficient stock for product ID " + it.productId + " (SKU: " + it.sku + ")");
                            }
                        }
                    }
                    psi.executeBatch();
                }
                c.commit();
                return sale.id;
            } catch (Exception e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    public static double getTodaySalesTotal() throws Exception {
        String sql = "SELECT COALESCE(SUM(total),0) FROM sales WHERE date(created_at) = date('now')";
        try (Connection c = Database.getConnection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getDouble(1) : 0.0;
        }
    }

    public static int getTodaySalesCount() throws Exception {
        String sql = "SELECT COUNT(*) FROM sales WHERE date(created_at) = date('now')";
        try (Connection c = Database.getConnection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public static List<Sale> listRecent(int limit) throws Exception {
        List<Sale> list = new ArrayList<>();
        String sql = "SELECT id, invoice_no, customer_name, payment_method, total, created_at FROM sales ORDER BY id DESC LIMIT ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Sale s = new Sale();
                    s.id = rs.getInt("id");
                    s.invoiceNo = rs.getString("invoice_no");
                    s.customerName = rs.getString("customer_name");
                    s.paymentMethod = rs.getString("payment_method");
                    s.total = rs.getDouble("total");
                    list.add(s);
                }
            }
        }
        return list;
    }

    public static List<Sale> listAll() throws Exception {
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM sales ORDER BY id DESC");
             ResultSet rs = ps.executeQuery()) {
            List<Sale> sales = new ArrayList<>();
            while (rs.next()) {
                Sale s = new Sale();
                s.id = rs.getInt("id");
                s.invoiceNo = rs.getString("invoice_no");
                s.userId = rs.getInt("user_id");
                if (rs.wasNull()) s.userId = null;
                s.customerName = rs.getString("customer_name");
                s.paymentMethod = rs.getString("payment_method");
                s.subtotal = rs.getDouble("subtotal");
                s.discount = rs.getDouble("discount");
                s.total = rs.getDouble("total");
                s.items = getSaleItems(s.id);
                sales.add(s);
            }
            return sales;
        }
    }

    public static List<Sale> getSalesByDateRange(java.util.Date startDate, java.util.Date endDate) throws Exception {
        String sql = "SELECT * FROM sales WHERE created_at >= ? AND created_at <= ? ORDER BY created_at ASC";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setTimestamp(1, new java.sql.Timestamp(startDate.getTime()));
            ps.setTimestamp(2, new java.sql.Timestamp(endDate.getTime()));

            try (ResultSet rs = ps.executeQuery()) {
                List<Sale> sales = new ArrayList<>();
                while (rs.next()) {
                    Sale s = new Sale();
                    s.id = rs.getInt("id");
                    s.invoiceNo = rs.getString("invoice_no");
                    s.userId = rs.getInt("user_id");
                    if (rs.wasNull()) s.userId = null;
                    s.customerName = rs.getString("customer_name");
                    s.paymentMethod = rs.getString("payment_method");
                    s.subtotal = rs.getDouble("subtotal");
                    s.discount = rs.getDouble("discount");
                    s.total = rs.getDouble("total");
                    s.items = getSaleItems(s.id);
                    sales.add(s);
                }
                return sales;
            }
        }
    }

    private static List<SaleItem> getSaleItems(int saleId) throws Exception {
        String sql = "SELECT * FROM sales_items WHERE sale_id = ?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, saleId);
            try (ResultSet rs = ps.executeQuery()) {
                List<SaleItem> items = new ArrayList<>();
                while (rs.next()) {
                    SaleItem item = new SaleItem();
                    item.id = rs.getInt("id");
                    item.saleId = rs.getInt("sale_id");
                    item.productId = rs.getInt("product_id");
                    item.sku = rs.getString("sku");
                    item.name = rs.getString("name");
                    item.qty = rs.getInt("qty");
                    item.price = rs.getDouble("price");
                    item.lineTotal = rs.getDouble("line_total");
                    items.add(item);
                }
                return items;
            }
        }
    }
    
    private static String generateInvoiceNo(Connection c) throws Exception {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COALESCE(MAX(id),0)+1 FROM sales")) {
            int next = rs.next() ? rs.getInt(1) : 1;
            return String.format("INV-%06d", next);
        }
    }
}
