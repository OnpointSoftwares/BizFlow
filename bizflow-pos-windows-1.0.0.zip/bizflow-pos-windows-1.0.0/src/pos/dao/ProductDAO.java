package pos.dao;

import pos.db.Database;
import pos.models.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    public static List<Product> search(String query) throws Exception {
        String q = "%" + query.toLowerCase() + "%";
        String sql = "SELECT id,name,sku,category,supplier_id,purchase_price,selling_price,stock_qty,expiry_date FROM products " +
                "WHERE lower(name) LIKE ? OR lower(sku) LIKE ? ORDER BY name LIMIT 200";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, q); ps.setString(2, q);
            try (ResultSet rs = ps.executeQuery()) { return mapProducts(rs); }
        }
    }

    public static List<Product> listAll() throws Exception {
        try (Connection c = Database.getConnection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(
                "SELECT id,name,sku,category,supplier_id,purchase_price,selling_price,stock_qty,expiry_date FROM products ORDER BY name")) {
            return mapProducts(rs);
        }
    }

    public static Product findBySKU(String sku) throws Exception {
        String sql = "SELECT id,name,sku,category,supplier_id,purchase_price,selling_price,stock_qty,expiry_date FROM products WHERE sku=?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, sku);
            try (ResultSet rs = ps.executeQuery()) {
                List<Product> list = mapProducts(rs);
                return list.isEmpty() ? null : list.get(0);
            }
        }
    }

    public static void insert(Product p) throws Exception {
        String sql = "INSERT INTO products(name,sku,category,supplier_id,purchase_price,selling_price,stock_qty,expiry_date,created_at,updated_at) " +
                "VALUES(?,?,?,?,?,?,?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.name);
            ps.setString(2, p.sku);
            ps.setString(3, p.category);
            if (p.supplierId == null) ps.setNull(4, Types.INTEGER); else ps.setInt(4, p.supplierId);
            ps.setDouble(5, p.purchasePrice);
            ps.setDouble(6, p.sellingPrice);
            ps.setInt(7, p.stockQty);
            ps.setString(8, p.expiryDate);
            ps.executeUpdate();
        }
    }

    public static void update(Product p) throws Exception {
        String sql = "UPDATE products SET name=?, sku=?, category=?, supplier_id=?, purchase_price=?, selling_price=?, stock_qty=?, expiry_date=?, updated_at=CURRENT_TIMESTAMP WHERE id=?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.name);
            ps.setString(2, p.sku);
            ps.setString(3, p.category);
            if (p.supplierId == null) ps.setNull(4, Types.INTEGER); else ps.setInt(4, p.supplierId);
            ps.setDouble(5, p.purchasePrice);
            ps.setDouble(6, p.sellingPrice);
            ps.setInt(7, p.stockQty);
            ps.setString(8, p.expiryDate);
            ps.setInt(9, p.id);
            ps.executeUpdate();
        }
    }

    public static void delete(int id) throws Exception {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM products WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public static void adjustStock(int productId, int delta) throws Exception {
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE products SET stock_qty = stock_qty + ?, updated_at=CURRENT_TIMESTAMP WHERE id=?")) {
            ps.setInt(1, delta);
            ps.setInt(2, productId);
            ps.executeUpdate();
        }
    }

    public static int lowStockCount(int threshold) throws Exception {
        String sql = "SELECT COUNT(*) FROM products WHERE stock_qty <= ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, threshold);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    private static List<Product> mapProducts(ResultSet rs) throws Exception {
        List<Product> list = new ArrayList<>();
        while (rs.next()) {
            Product p = new Product(
                    rs.getInt("id"), rs.getString("name"), rs.getString("sku"), rs.getString("category"),
                    (Integer) rs.getObject("supplier_id"), rs.getDouble("purchase_price"), rs.getDouble("selling_price"),
                    rs.getInt("stock_qty"), rs.getString("expiry_date")
            );
            list.add(p);
        }
        return list;
    }
}
