package pos.util;

import org.mindrot.jbcrypt.BCrypt;

public class Security {
    public static String hashPassword(String plain) {
        return BCrypt.hashpw(plain, BCrypt.gensalt(12));
    }
    public static boolean checkPassword(String plain, String hashed) {
        try { return BCrypt.checkpw(plain, hashed); } catch (Exception e) { return false; }
    }
}
