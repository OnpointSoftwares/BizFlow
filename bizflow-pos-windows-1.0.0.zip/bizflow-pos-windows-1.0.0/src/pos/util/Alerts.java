package pos.util;

import java.awt.*;

public class Alerts {
    public static void info(Component parent, String title, String message) {
        Dialog d = new Dialog((Frame) null, title, true);
        d.setLayout(new BorderLayout());
        Label lbl = new Label(message);
        lbl.setAlignment(Label.CENTER);
        d.add(lbl, BorderLayout.CENTER);
        Panel p = new Panel();
        Button ok = new Button("OK");
        ok.addActionListener(e -> d.dispose());
        p.add(ok);
        d.add(p, BorderLayout.SOUTH);
        d.setSize(360, 140);
        d.setLocationRelativeTo(parent);
        d.setVisible(true);
    }

    public static boolean confirm(Component parent, String title, String message) {
        final boolean[] res = {false};
        Dialog d = new Dialog((Frame) null, title, true);
        d.setLayout(new BorderLayout());
        Label lbl = new Label(message);
        lbl.setAlignment(Label.CENTER);
        d.add(lbl, BorderLayout.CENTER);
        Panel p = new Panel();
        Button yes = new Button("Yes");
        Button no = new Button("No");
        yes.addActionListener(e -> { res[0] = true; d.dispose(); });
        no.addActionListener(e -> { res[0] = false; d.dispose(); });
        p.add(yes); p.add(no);
        d.add(p, BorderLayout.SOUTH);
        d.setSize(360, 140);
        d.setLocationRelativeTo(parent);
        d.setVisible(true);
        return res[0];
    }
}
