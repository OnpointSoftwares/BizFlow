package pos.ui;

import pos.dao.UserDAO;
import pos.db.Database;
import pos.models.User;

import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;

public class LoginDialog extends Dialog {
    private EnhancedTextField tfUser;
    private EnhancedTextField tfPass;
    private User user;
    private ModernButton loginButton;
    private Timer fadeTimer;
    private float opacity = 0.0f;
    private boolean fadeIn = true;
    private Panel contentPanel;

    public LoginDialog(Frame owner) {
        super(owner, "BizFlow POS - Login", true);
        setLayout(new BorderLayout());
        setSize(480, 360);
        setLocationRelativeTo(owner);
        setBackground(new Color(248, 250, 252));
        
        createComponents();
        setupLayout();
        setupAnimations();
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                tfUser.requestFocus();
            }
        });
    }

    private void createComponents() {
        tfUser = new EnhancedTextField("Enter username", 20);
        tfPass = new EnhancedTextField("Enter password", 20);
        tfPass.setEchoChar('*');
        tfPass.setPasswordField(true);
        
        loginButton = new ModernButton("🔑 Sign In");
        loginButton.addActionListener(e -> doLogin());
        
        // Add Enter key support
        tfUser.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    tfPass.requestFocus();
                }
            }
        });
        
        tfPass.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    doLogin();
                }
            }
        });
    }

    private void setupLayout() {
        // Main content panel with custom painting
        contentPanel = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                // Background gradient
                GradientPaint bgGradient = new GradientPaint(
                    0, 0, new Color(255, 255, 255, (int)(255 * opacity)),
                    0, h, new Color(248, 250, 252, (int)(255 * opacity))
                );
                g2.setPaint(bgGradient);
                g2.fillRoundRect(0, 0, w, h, 24, 24);
                
                // Subtle border
                g2.setColor(new Color(226, 232, 240, (int)(150 * opacity)));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w-2, h-2, 24, 24);
                
                // Inner glow
                g2.setColor(new Color(59, 130, 246, (int)(30 * opacity)));
                g2.setStroke(new BasicStroke(4f));
                g2.drawRoundRect(2, 2, w-4, h-4, 22, 22);
            }
        };
        
        contentPanel.setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        
        // Header section
        Panel headerPanel = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                // Logo background circle
                int centerX = getWidth() / 2;
                GradientPaint logoGradient = new GradientPaint(
                    centerX - 30, 10, new Color(59, 130, 246, (int)(200 * opacity)),
                    centerX + 30, 70, new Color(139, 92, 246, (int)(200 * opacity))
                );
                g2.setPaint(logoGradient);
                g2.fillOval(centerX - 30, 10, 60, 60);
                
                // Logo icon
                g2.setColor(new Color(255, 255, 255, (int)(255 * opacity)));
                g2.setFont(new Font("SansSerif", Font.BOLD, 24));
                FontMetrics fm = g2.getFontMetrics();
                String logo = "🏪";
                int logoX = centerX - fm.stringWidth(logo) / 2;
                g2.drawString(logo, logoX, 45);
            }
        };
        headerPanel.setPreferredSize(new Dimension(0, 80));
        headerPanel.setBackground(new Color(0, 0, 0, 0));
        
        gc.gridx = 0; gc.gridy = 0; gc.gridwidth = 2;
        gc.insets = new Insets(20, 20, 10, 20);
        gc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(headerPanel, gc);
        
        // Title
        Label titleLabel = new Label("Welcome Back") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = fm.getAscent();
                
                // Text shadow
                g2.setColor(new Color(0, 0, 0, (int)(50 * opacity)));
                g2.drawString(getText(), x + 1, y + 1);
                
                // Main text
                g2.setColor(new Color(30, 41, 59, (int)(255 * opacity)));
                g2.drawString(getText(), x, y);
            }
        };
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        titleLabel.setAlignment(Label.CENTER);
        
        gc.gridy = 1; gc.insets = new Insets(0, 20, 20, 20);
        contentPanel.add(titleLabel, gc);
        
        // Username field
        Label userLabel = new Label("Username") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(new Color(71, 85, 105, (int)(255 * opacity)));
                g2.drawString(getText(), 0, g2.getFontMetrics().getAscent());
            }
        };
        userLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        
        gc.gridx = 0; gc.gridy = 2; gc.gridwidth = 1;
        gc.insets = new Insets(10, 30, 5, 30);
        gc.anchor = GridBagConstraints.WEST;
        contentPanel.add(userLabel, gc);
        
        gc.gridy = 3; gc.insets = new Insets(0, 30, 15, 30);
        gc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(tfUser, gc);
        
        // Password field
        Label passLabel = new Label("Password") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(new Color(71, 85, 105, (int)(255 * opacity)));
                g2.drawString(getText(), 0, g2.getFontMetrics().getAscent());
            }
        };
        passLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        
        gc.gridy = 4; gc.insets = new Insets(0, 30, 5, 30);
        gc.anchor = GridBagConstraints.WEST;
        contentPanel.add(passLabel, gc);
        
        gc.gridy = 5; gc.insets = new Insets(0, 30, 25, 30);
        gc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(tfPass, gc);
        
        // Login button
        gc.gridy = 6; gc.insets = new Insets(0, 30, 30, 30);
        gc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(loginButton, gc);
        
        add(contentPanel, BorderLayout.CENTER);
    }

    private void setupAnimations() {
        fadeTimer = new Timer(20, e -> {
            if (fadeIn) {
                opacity += 0.05f;
                if (opacity >= 1.0f) {
                    opacity = 1.0f;
                    fadeTimer.stop();
                }
            }
            repaint();
        });
        fadeTimer.start();
    }

    // Enhanced TextField with modern styling
    private class EnhancedTextField extends TextField {
        private String placeholder;
        private boolean isFocused = false;
        private boolean isPasswordField = false;
        
        public EnhancedTextField(String placeholder, int columns) {
            super(columns);
            this.placeholder = placeholder;
            setFont(new Font("SansSerif", Font.PLAIN, 16));
            
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    isFocused = true;
                    repaint();
                }
                
                @Override
                public void focusLost(FocusEvent e) {
                    isFocused = false;
                    repaint();
                }
            });
        }
        
        public void setPasswordField(boolean isPassword) {
            this.isPasswordField = isPassword;
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            
            // Background
            if (isFocused) {
                GradientPaint focusGradient = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 255),
                    0, h, new Color(248, 250, 252, 255)
                );
                g2.setPaint(focusGradient);
            } else {
                g2.setColor(new Color(255, 255, 255, 240));
            }
            g2.fillRoundRect(0, 0, w, h, 12, 12);
            
            // Border
            if (isFocused) {
                g2.setColor(new Color(59, 130, 246, 200));
                g2.setStroke(new BasicStroke(2f));
            } else {
                g2.setColor(new Color(203, 213, 225, 150));
                g2.setStroke(new BasicStroke(1f));
            }
            g2.drawRoundRect(0, 0, w-1, h-1, 12, 12);
            
            // Inner shadow
            if (!isFocused) {
                g2.setColor(new Color(0, 0, 0, 20));
                g2.drawRoundRect(1, 1, w-3, h-3, 10, 10);
            }
            
            // Text
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            String displayText = getText();
            
            if (displayText.isEmpty() && !isFocused) {
                g2.setColor(new Color(156, 163, 175));
                displayText = placeholder;
            } else {
                g2.setColor(new Color(30, 41, 59));
            }
            
            int textX = 12;
            int textY = (h + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(displayText, textX, textY);
        }
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(300, 45);
        }
    }

    // Modern styled button
    private class ModernButton extends Button {
        private boolean isHovered = false;
        private boolean isPressed = false;
        
        public ModernButton(String text) {
            super(text);
            setFont(new Font("SansSerif", Font.BOLD, 16));
            
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHovered = true;
                    repaint();
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    isPressed = false;
                    repaint();
                }
                
                @Override
                public void mousePressed(MouseEvent e) {
                    isPressed = true;
                    repaint();
                }
                
                @Override
                public void mouseReleased(MouseEvent e) {
                    isPressed = false;
                    repaint();
                }
            });
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            
            // Button background gradient
            Color color1, color2;
            if (isPressed) {
                color1 = new Color(29, 78, 216);
                color2 = new Color(30, 64, 175);
            } else if (isHovered) {
                color1 = new Color(37, 99, 235);
                color2 = new Color(29, 78, 216);
            } else {
                color1 = new Color(59, 130, 246);
                color2 = new Color(37, 99, 235);
            }
            
            GradientPaint buttonGradient = new GradientPaint(0, 0, color1, 0, h, color2);
            g2.setPaint(buttonGradient);
            g2.fillRoundRect(0, 0, w, h, 12, 12);
            
            // Button highlight
            if (!isPressed) {
                GradientPaint highlight = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 40),
                    0, h/2, new Color(255, 255, 255, 0)
                );
                g2.setPaint(highlight);
                g2.fillRoundRect(0, 0, w, h/2, 12, 12);
            }
            
            // Button shadow
            if (isPressed) {
                g2.setColor(new Color(0, 0, 0, 60));
                g2.fillRoundRect(2, 2, w-4, h-4, 10, 10);
            }
            
            // Text with shadow
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int textX = (w - fm.stringWidth(getLabel())) / 2;
            int textY = (h + fm.getAscent() - fm.getDescent()) / 2;
            
            // Text shadow
            g2.setColor(new Color(0, 0, 0, 100));
            g2.drawString(getLabel(), textX + 1, textY + 1);
            
            // Main text
            g2.setColor(Color.WHITE);
            g2.drawString(getLabel(), textX, textY);
        }
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(300, 50);
        }
    }

    private void doLogin() {
        loginButton.setEnabled(false);
        loginButton.setLabel("🔄 Signing in...");
        
        try {
            String u = tfUser.getText().trim();
            String p = tfPass.getText();
            
            if (u.isEmpty() || p.isEmpty()) {
                showErrorDialog("Please enter both username and password");
                return;
            }
            
            User found = UserDAO.findByUsername(u);
            if (found != null && Database.verifyPassword(p, found.salt, found.passwordHash)) {
                user = found;
                // Fade out animation
                fadeIn = false;
                Timer closeTimer = new Timer(20, e -> {
                    opacity -= 0.1f;
                    if (opacity <= 0) {
                        ((Timer)e.getSource()).stop();
                        dispose();
                    }
                    repaint();
                });
                closeTimer.start();
            } else {
                showErrorDialog("Invalid username or password");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showErrorDialog("Login failed: " + ex.getMessage());
        } finally {
            loginButton.setEnabled(true);
            loginButton.setLabel("🔑 Sign In");
        }
    }

    private void showErrorDialog(String message) {
        Dialog errorDialog = new Dialog(this, "Authentication Error", true) {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Background gradient
                GradientPaint bg = new GradientPaint(
                    0, 0, new Color(254, 242, 242),
                    0, h, new Color(255, 255, 255)
                );
                g2.setPaint(bg);
                g2.fillRoundRect(0, 0, w, h, 16, 16);
                
                // Border
                g2.setColor(new Color(248, 113, 113));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w-2, h-2, 16, 16);
            }
        };
        
        errorDialog.setLayout(new BorderLayout());
        errorDialog.setSize(350, 150);
        errorDialog.setLocationRelativeTo(this);
        
        Panel messagePanel = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                // Error icon
                g2.setColor(new Color(239, 68, 68));
                g2.setFont(new Font("SansSerif", Font.BOLD, 24));
                g2.drawString("⚠️", 20, 35);
                
                // Message text
                g2.setColor(new Color(127, 29, 29));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
                g2.drawString(message, 55, 35);
            }
        };
        messagePanel.setPreferredSize(new Dimension(0, 60));
        
        ModernButton okButton = new ModernButton("✓ OK");
        okButton.addActionListener(e -> errorDialog.dispose());
        
        Panel buttonPanel = new Panel(new FlowLayout());
        buttonPanel.add(okButton);
        
        errorDialog.add(messagePanel, BorderLayout.CENTER);
        errorDialog.add(buttonPanel, BorderLayout.SOUTH);
        errorDialog.setVisible(true);
    }

    public User getUser() { 
        return user; 
    }
    
    @Override
    public void dispose() {
        if (fadeTimer != null) {
            fadeTimer.stop();
        }
        super.dispose();
    }
}