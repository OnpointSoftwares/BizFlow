package pos.ui;

import pos.dao.UserDAO;
import pos.models.User;
import pos.ui.components.RoundedButton;
import pos.ui.components.ModernSearchField;
import pos.ui.components.NotificationManager;
import pos.ui.components.StatusIndicator;
import pos.ui.theme.Theme;
import pos.util.BackupUtil;
import pos.ui.panels.*;
import pos.ui.panels.AnalyticsPanel;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.Timer;
import javax.swing.*;
import javax.swing.border.*;
import java.util.function.Consumer;

// UI Components
import pos.ui.components.RoundedButton;
import pos.ui.components.ModernSearchField;
import pos.ui.components.NotificationManager;
import pos.ui.components.StatusIndicator;

// DAO
import pos.dao.ProductDAO;
import pos.dao.UserDAO;

// Models
import pos.models.User;
import pos.models.Product;

// Theme
import pos.ui.theme.Theme;

// Utils
import pos.util.BackupUtil;

public class PosFrame extends Frame {
    private CardLayout cards = new CardLayout();
    private Panel content = new Panel(cards);
    private String role = "Guest";
    private User currentUser;
    private RoundedButton activeButton;
    private RoundedButton[] tabButtons;
    private javax.swing.Timer animationTimer;
    private javax.swing.Timer clockTimer;
    private float headerGlow = 0f;
    private boolean glowIncreasing = true;
    private Label timeLabel;
    private StatusIndicator connectionStatus;
    private NotificationManager notificationManager;
    private Panel quickActionsPanel;
    private Label userAvatarLabel;
    private boolean isFullscreen = false;
    private Dimension normalSize;
    private Point normalLocation;

    // Modern color scheme
    private static final Color PRIMARY_BLUE = new Color(59, 130, 246);
    private static final Color SECONDARY_BLUE = new Color(147, 197, 253);
    private static final Color DARK_BLUE = new Color(30, 58, 138);
    private static final Color SUCCESS_GREEN = new Color(34, 197, 94);
    private static final Color WARNING_ORANGE = new Color(251, 146, 60);
    private static final Color ERROR_RED = new Color(239, 68, 68);
    private static final Color NEUTRAL_GRAY = new Color(107, 114, 128);
    private static final Color LIGHT_GRAY = new Color(243, 244, 246);

    public PosFrame() {
        super("BizFlow POS System");
        setSize(1600, 900); // Larger default size for modern systems
        setLocationRelativeTo(null);
        Theme.applyDefaults(this);
        setLayout(new BorderLayout());
        
        // Set application icon
        try {
            // Try to load the icon from the file system first
            String iconPath = System.getProperty("user.dir") + "/assets/icon.png";
            java.io.File iconFile = new java.io.File(iconPath);
            
            if (!iconFile.exists()) {
                // If not found, try the resources directory
                iconPath = "src/main/resources/assets/icon.png";
                iconFile = new java.io.File(iconPath);
            }
            
            if (iconFile.exists()) {
                System.out.println("Loading icon from: " + iconFile.getAbsolutePath());
                ImageIcon icon = new ImageIcon(iconFile.getAbsolutePath());
                
                // Set the icon for the frame
                setIconImage(icon.getImage());
                
                // For better taskbar/dock integration on some systems
                if (Taskbar.isTaskbarSupported()) {
                    try {
                        Taskbar taskbar = Taskbar.getTaskbar();
                        if (taskbar.isSupported(Taskbar.Feature.ICON_IMAGE)) {
                            taskbar.setIconImage(icon.getImage());
                        }
                    } catch (Exception e) {
                        System.err.println("Warning: Could not set taskbar icon: " + e.getMessage());
                    }
                }
            } else {
                System.err.println("Icon file not found at: " + iconFile.getAbsolutePath());
                // Try one more location in the build directory
                iconPath = "build/classes/java/main/assets/icon.png";
                iconFile = new java.io.File(iconPath);
                if (iconFile.exists()) {
                    System.out.println("Loading icon from build directory: " + iconFile.getAbsolutePath());
                    ImageIcon icon = new ImageIcon(iconFile.getAbsolutePath());
                    setIconImage(icon.getImage());
                } else {
                    System.err.println("Icon file not found in build directory either");
                }
            }
        } catch (Exception e) {
            System.err.println("Could not load application icon: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Enhanced background
        setBackground(LIGHT_GRAY);
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) { 
                cleanup();
                dispose(); 
                System.exit(0); 
            }
        });

        // Initialize components
        notificationManager = new NotificationManager();
        setupAnimationTimer();
        setupClockTimer();
        createModernHeader();
        createEnhancedSidebar();
        createModernContentArea();
        setupModernMenuBar();
        setupKeyboardShortcuts();
        
        setVisible(true);
        openLogin();
    }

    private void setupAnimationTimer() {
        animationTimer = new javax.swing.Timer(16, new ActionListener() { // 60 FPS
            @Override
            public void actionPerformed(ActionEvent e) {
                if (glowIncreasing) {
                    headerGlow += 0.015f;
                    if (headerGlow >= 1f) {
                        headerGlow = 1f;
                        glowIncreasing = false;
                    }
                } else {
                    headerGlow -= 0.015f;
                    if (headerGlow <= 0f) {
                        headerGlow = 0f;
                        glowIncreasing = true;
                    }
                }
                if (header != null) header.repaint();
            }
        });
        animationTimer.start();
    }

    private void setupClockTimer() {
        clockTimer = new javax.swing.Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateClock();
            }
        });
        clockTimer.start();
    }

    private void updateClock() {
        if (timeLabel != null) {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy • HH:mm:ss");
            timeLabel.setText(now.format(formatter));
        }
    }

    private Panel header;
    
    // Theme colors
    public static final Color ACCENT_COLOR = new Color(99, 102, 241);
    public static final Color BG_COLOR = new Color(249, 250, 251);
    public static final Color CARD_BG = Color.WHITE;
    public static final Color TEXT_PRIMARY = new Color(17, 24, 39);
    public static final Color TEXT_SECONDARY = new Color(107, 114, 128);
    public static final Color BORDER_COLOR = new Color(229, 231, 235);
    
    // UI Components
    private Panel mainPanel;
    
    private void setActiveButton(RoundedButton button) {
        if (activeButton != null) {
            activeButton.setActive(false);
        }
        activeButton = button;
        if (activeButton != null) {
            activeButton.setActive(true);
        }
    }

    // setActiveButton method is already defined, removing duplicate
    
    private void createModernHeader() {
        header = new Panel(new BorderLayout()) {
            @Override
            public void update(Graphics g) {
                paint(g);
            }
            
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                
                // Enable anti-aliasing for smooth edges
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                // Paint background with subtle gradient
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 240),
                    0, getHeight(), new Color(240, 242, 245, 240)
                );
                g2.setPaint(gradient);
                g2.fillRect(0, 0, getWidth(), getHeight());
                
                // Add subtle border at bottom
                g2.setColor(new Color(0, 0, 0, 20));
                g2.fillRect(0, getHeight() - 1, getWidth(), 1);
                
                // Add subtle glow effect
                if (headerGlow > 0) {
                    g2.setColor(new Color(59, 130, 246, (int)(30 * headerGlow)));
                    g2.fillRect(0, 0, getWidth(), 4);
                }
                
                g2.dispose();
                super.paint(g);
            }
        };
        
        header.setPreferredSize(new Dimension(getWidth(), 60));
        
        // Left side - Logo and app name
        Panel leftPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        leftPanel.setBackground(new Color(0, 0, 0, 0));
        
        // App logo/icon
        Label logo = new Label("🛒") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PRIMARY_BLUE);
                g2.fillRoundRect(0, 0, 40, 40, 12, 12);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 20));
                g2.drawString("🛒", 8, 28);
                g2.dispose();
            }
        };
        logo.setPreferredSize(new Dimension(40, 40));
        
        // App name
        Label appName = new Label("BizFlow POS") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(TEXT_PRIMARY);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 18));
                g2.drawString("BizFlow POS", 0, 18);
                g2.dispose();
            }
        };
        appName.setPreferredSize(new Dimension(120, 40));
        
        leftPanel.add(logo);
        leftPanel.add(appName);
        
        // Center - Search and quick actions
        Panel centerPanel = new Panel(new BorderLayout());
        centerPanel.setBackground(new Color(0, 0, 0, 0));
        
        // Search bar
        ModernSearchField searchField = new ModernSearchField("Search products, customers...");
        searchField.setPreferredSize(new Dimension(300, 36));
        
        // Quick actions
        quickActionsPanel = createQuickActionsPanel();
        
        centerPanel.add(searchField, BorderLayout.WEST);
        centerPanel.add(quickActionsPanel, BorderLayout.CENTER);
        
        // Right side - User info and controls
        Panel rightPanel = new Panel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setBackground(new Color(0, 0, 0, 0));
        
        // Time label
        timeLabel = new Label() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(TEXT_SECONDARY);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy • HH:mm:ss"));
                g2.drawString(time, 0, 15);
                g2.dispose();
            }
        };
        timeLabel.setPreferredSize(new Dimension(180, 40));
        
        // Connection status
        connectionStatus = new StatusIndicator();
        connectionStatus.setStatus(StatusIndicator.Status.CONNECTED);
        
        // Add user avatar and info
        createUserAvatarPanel(rightPanel);
        
        // Add window controls
        createWindowControls(rightPanel);
        
        rightPanel.add(timeLabel);
        rightPanel.add(connectionStatus);
        
        // Add all sections to header
        header.add(leftPanel, BorderLayout.WEST);
        header.add(centerPanel, BorderLayout.CENTER);
        header.add(rightPanel, BorderLayout.EAST);
        
        add(header, BorderLayout.NORTH);
    }
    
    private Panel createQuickActionsPanel() {
        Panel quickActions = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        quickActions.setBackground(new Color(0, 0, 0, 0));
        
        // Quick sale button
        RoundedButton quickSale = new RoundedButton("⚡ Quick Sale");
        quickSale.setPreferredSize(new Dimension(100, 30));
        quickSale.setBackground(SUCCESS_GREEN);
        quickSale.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Switch to sales tab
                if (tabButtons != null && tabButtons.length > 2) {
                    setActiveButton(tabButtons[2]);
                    showCard("sales");
                    notificationManager.showNotification("Quick Sale mode activated", NotificationManager.Type.SUCCESS);
                }
            }
        });
        
        // New product button
        RoundedButton newProduct = new RoundedButton("📦 Add Product");
        newProduct.setPreferredSize(new Dimension(110, 30));
        newProduct.setBackground(PRIMARY_BLUE);
        newProduct.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Open new product dialog
                if (tabButtons != null && tabButtons.length > 1) {
                    setActiveButton(tabButtons[1]);
                    showCard("inventory");
                }
                ProductEditorDialog dialog = new ProductEditorDialog(PosFrame.this, null, saved -> {
                    if (saved) {
                        notificationManager.showNotification("Product saved successfully", NotificationManager.Type.SUCCESS);
                        // Refresh the inventory list
                        if (content.getComponent(2) instanceof InventoryPanel) {
                            ((InventoryPanel) content.getComponent(2)).refreshList();
                        }
                    }
                });
                dialog.setVisible(true);
            }
        });
        
        quickActions.add(quickSale);
        quickActions.add(newProduct);
        
        return quickActions;
    }
    
    private void createUserAvatarPanel(Panel rightPanel) {
        if (rightPanel == null) return;
        
        Panel userContainer = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        userContainer.setBackground(new Color(0, 0, 0, 0));
        
        // User avatar (placeholder)
        userAvatarLabel = new Label("👤") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int size = Math.min(getWidth(), getHeight());
                
                // Background circle
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PRIMARY_BLUE);
                g2.fillOval(2, 2, size-4, size-4);
                
                // Border
                g2.setColor(new Color(255, 255, 255, 200));
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(2, 2, size-4, size-4);
                
                // Icon
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("SansSerif", Font.PLAIN, 20));
                FontMetrics fm = g2.getFontMetrics();
                int x = (size - fm.stringWidth(getText())) / 2;
                int y = (size + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
            }
        };
        userAvatarLabel.setPreferredSize(new Dimension(35, 35));
        
        // User info panel
        Panel userInfo = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                if (currentUser != null) {
                    // Draw user name
                    g2.setColor(new Color(15, 23, 42));
                    g2.setFont(new Font("SansSerif", Font.BOLD, 13));
                    g2.drawString(currentUser.username, 0, 15);
                        
                    // Draw role
                    g2.setColor(NEUTRAL_GRAY);
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                    g2.drawString(role, 0, 30);
                }
            }
        };
        userInfo.setPreferredSize(new Dimension(80, 35));
        
        // Add mouse listener for user menu
        userContainer.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                showUserMenu(userContainer);
            }
        });
        
        userContainer.add(userAvatarLabel);
        userContainer.add(userInfo);
        rightPanel.add(userContainer);
    }
    
    private void showUserMenu(Component invoker) {
        // Implementation for showing user menu (logout, settings, etc.)
        // This is a placeholder - implement as needed
        PopupMenu menu = new PopupMenu();
        MenuItem profileItem = new MenuItem("Profile");
        MenuItem settingsItem = new MenuItem("Settings");
        MenuItem logoutItem = new MenuItem("Logout");
        
        logoutItem.addActionListener(e -> doLogout());
        
        menu.add(profileItem);
        menu.add(settingsItem);
        menu.addSeparator();
        menu.add(logoutItem);
        
        menu.show(invoker, 0, invoker.getHeight());
    }

    private void createWindowControls(Panel rightPanel) {
        Panel controls = new Panel(new FlowLayout(FlowLayout.CENTER, 4, 15));
        controls.setBackground(new Color(0, 0, 0, 0));
        
        // Fullscreen toggle
        RoundedButton fullscreenBtn = new RoundedButton("⛶");
        fullscreenBtn.setPreferredSize(new Dimension(30, 30));
        fullscreenBtn.setBackground(new Color(0, 0, 0, 0));
        fullscreenBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                toggleFullscreen();
            }
        });
        
        // Settings button
        RoundedButton settingsBtn = new RoundedButton("⚙");
        settingsBtn.setPreferredSize(new Dimension(30, 30));
        settingsBtn.setBackground(new Color(0, 0, 0, 0));
        settingsBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Open settings dialog
                notificationManager.showNotification("Settings panel opened", NotificationManager.Type.INFO);
            }
        });
        
        controls.add(fullscreenBtn);
        controls.add(settingsBtn);
        rightPanel.add(controls);
    }

    private void toggleFullscreen() {
        if (!isFullscreen) {
            // Store current size and position
            normalSize = getSize();
            normalLocation = getLocation();
            
            // Get screen dimensions
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            setSize(screenSize);
            setLocation(0, 0);
            isFullscreen = true;
            notificationManager.showNotification("Fullscreen mode enabled", NotificationManager.Type.INFO);
        } else {
            // Restore normal size and position
            setSize(normalSize);
            setLocation(normalLocation);
            isFullscreen = false;
            notificationManager.showNotification("Fullscreen mode disabled", NotificationManager.Type.INFO);
        }
    }

    private void createEnhancedSidebar() {
        // Enhanced sidebar with modern gradient
        Panel sidebar = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                // Modern gradient background
                GradientPaint sidebarGradient = new GradientPaint(
                    0, 0, new Color(30, 58, 138),
                    w, h, new Color(30, 64, 175)
                );
                g2.setPaint(sidebarGradient);
                g2.fillRect(0, 0, w, h);
                
                // Subtle pattern overlay
                g2.setColor(new Color(255, 255, 255, 8));
                for (int i = 0; i < w; i += 30) {
                    for (int j = 0; j < h; j += 30) {
                        g2.fillOval(i, j, 2, 2);
                    }
                }
                
                // Right edge highlight
                GradientPaint edgeGradient = new GradientPaint(
                    w-3, 0, new Color(255, 255, 255, 50),
                    w, 0, new Color(255, 255, 255, 0)
                );
                g2.setPaint(edgeGradient);
                g2.fillRect(w-3, 0, 3, h);
                
                super.paint(g);
            }
        };
        
        sidebar.setLayout(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(300, 0)); // Wider for modern look
        
        // Enhanced navigation
        Panel navContainer = createEnhancedNavigation();
        sidebar.add(navContainer, BorderLayout.CENTER);
        
        // Enhanced user info panel
        Panel enhancedUserPanel = createEnhancedUserInfoPanel();
        sidebar.add(enhancedUserPanel, BorderLayout.SOUTH);
        
        add(sidebar, BorderLayout.WEST);
    }

    private Panel createEnhancedNavigation() {
        Panel navWrapper = new Panel(new BorderLayout());
        navWrapper.setBackground(new Color(0, 0, 0, 0));
        
        // Navigation title
        Label navTitle = new Label("NAVIGATION") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(new Font("SansSerif", Font.BOLD, 11));
                g2.setColor(new Color(255, 255, 255, 150));
                g2.drawString(getText(), 0, g2.getFontMetrics().getAscent());
            }
        };
        
        Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 24, 20));
        titlePanel.setBackground(new Color(0, 0, 0, 0));
        titlePanel.add(navTitle);
        
        // Navigation buttons container
        Panel navContainer = new Panel();
        navContainer.setLayout(new GridLayout(0, 1, 0, 8)); // Reduced spacing for modern look
        navContainer.setBackground(new Color(0, 0, 0, 0));
        
        // Navigation wrapper with padding
        Panel navPadding = new Panel(new BorderLayout());
        navPadding.setBackground(new Color(0, 0, 0, 0));
        Panel paddingContainer = new Panel(new FlowLayout(FlowLayout.CENTER, 0, 16));
        paddingContainer.setBackground(new Color(0, 0, 0, 0));
        paddingContainer.add(navContainer);
        
        // Enhanced navigation buttons with modern icons and labels
        tabButtons = new RoundedButton[7]; // Added one more for analytics
        String[] buttonLabels = {"Dashboard", "Inventory", "Sales", "Invoices", "Quotations", "Reports", "Analytics"};
        String[] buttonIcons = {"📊", "📦", "💳", "🧾", "📝", "📊", "📈"}; // Updated with better emoji icons
        String[] buttonDescriptions = {
            "Overview & metrics",
            "Product management", 
            "Point of sale",
            "Invoice management",
            "Quote generation",
            "Business reports",
            "Data analytics"
        };
        
        for (int i = 0; i < buttonLabels.length; i++) {
            tabButtons[i] = createModernNavButton(buttonIcons[i], buttonLabels[i], buttonDescriptions[i]);
            navContainer.add(tabButtons[i]);
            
            final int index = i;
            final String cardName = buttonLabels[i].toLowerCase();
            
            tabButtons[i].addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    setActiveButton(tabButtons[index]);
                    showCard(cardName);
                    
                    // Show notification
                    notificationManager.showNotification(
                        "Switched to " + buttonLabels[index], 
                        NotificationManager.Type.INFO
                    );
                }
                
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (tabButtons[index] != activeButton) {
                        tabButtons[index].setHovered(true);
                    }
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    tabButtons[index].setHovered(false);
                }
            });
        }
        
        navPadding.add(titlePanel, BorderLayout.NORTH);
        navPadding.add(paddingContainer, BorderLayout.CENTER);
        navWrapper.add(navPadding, BorderLayout.CENTER);
        
        return navWrapper;
    }

    // Array of emoji fonts to try, in order of preference
    private final String[] EMOJI_FONTS = {
        "Segoe UI Emoji",      // Windows
        "Apple Color Emoji",   // macOS
        "Noto Color Emoji",    // Linux/Android
        "EmojiOne Color",      // Alternative
        "DejaVu Sans",         // Common fallback
        Font.DIALOG            // System default
    };
    
    private RoundedButton createModernNavButton(String icon, String title, String description) {
        // Map of button labels to fallback characters if emoji fails
        Map<String, String> fallbackIcons = new HashMap<String, String>() {{
            put("Dashboard", "D");
            put("Inventory", "I");
            put("Sales", "S");
            put("Invoices", "V");
            put("Quotations", "Q");
            put("Reports", "R");
            put("Analytics", "A");
        }};
        
        final String fallbackIcon = fallbackIcons.getOrDefault(title, "•");
        
        RoundedButton btn = new RoundedButton(title) {
            private boolean isHovered = false;
            private boolean isActive = false;
            private boolean useFallbackIcon = false;
            private final int ICON_SIZE = 24;
            private final int PADDING = 16;
            private final int ICON_TEXT_GAP = 12;
            private Font iconFont;
            
            private Font getBestEmojiFont() {
                // Try to find a font that can display the emoji
                for (String fontName : EMOJI_FONTS) {
                    try {
                        Font font = new Font(fontName, Font.PLAIN, 22);
                        if (font.canDisplayUpTo(icon) == -1) {
                            // Test if the font can actually render the character
                            if (font.canDisplay(icon.charAt(0))) {
                                useFallbackIcon = false;
                                return font;
                            }
                        }
                    } catch (Exception e) {
                        // Continue to next font if this one fails
                        continue;
                    }
                }
                // If we get here, no suitable emoji font was found
                useFallbackIcon = true;
                return new Font("SansSerif", Font.BOLD, 18); // Use a standard font for fallback
            }
            
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
                
                // Modern button background
                if (isActive) {
                    // White background with shadow for active state
                    g2.setColor(new Color(0, 0, 0, 30));
                    g2.fillRoundRect(3, 3, w-6, h-6, 16, 16);
                    
                    g2.setColor(Color.WHITE);
                    g2.fillRoundRect(0, 0, w, h, 16, 16);
                    
                    // Inner glow
                    g2.setColor(new Color(59, 130, 246, 50));
                    g2.fillRoundRect(2, 2, w-4, h-4, 14, 14);
                } else if (isHovered) {
                    g2.setColor(new Color(255, 255, 255, 200));
                    g2.fillRoundRect(0, 0, w, h, 16, 16);
                } else {
                    g2.setColor(new Color(255, 255, 255, 50));
                    g2.fillRoundRect(0, 0, w, h, 16, 16);
                }
                
                // Border
                if (isActive) {
                    g2.setColor(new Color(59, 130, 246, 100));
                    g2.setStroke(new BasicStroke(2f));
                } else if (isHovered) {
                    g2.setColor(new Color(255, 255, 255, 200));
                    g2.setStroke(new BasicStroke(1.5f));
                } else {
                    g2.setColor(new Color(255, 255, 255, 80));
                    g2.setStroke(new BasicStroke(1f));
                }
                g2.drawRoundRect(0, 0, w-1, h-1, 16, 16);
                
                // Icon container with background
                int iconContainerSize = 40;
                int iconContainerX = PADDING;
                int iconContainerY = (h - iconContainerSize) / 2;
                
                // Icon background
                if (isActive) {
                    g2.setColor(new Color(59, 130, 246, 15));
                } else {
                    g2.setColor(new Color(255, 255, 255, 20));
                }
                g2.fillRoundRect(iconContainerX, iconContainerY, iconContainerSize, iconContainerSize, 12, 12);
                
                // Icon border
                g2.setColor(new Color(255, 255, 255, isActive ? 80 : 40));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(iconContainerX, iconContainerY, iconContainerSize, iconContainerSize, 12, 12);
                
                // Initialize the font if not already done
                if (iconFont == null) {
                    iconFont = getBestEmojiFont();
                }
                
                // Set the font and get metrics
                g2.setFont(iconFont);
                FontMetrics iconFm = g2.getFontMetrics(iconFont);
                
                // Get the actual icon to display (emoji or fallback)
                String displayIcon = useFallbackIcon ? fallbackIcon : icon;
                
                // Calculate icon position - center it in the container
                int iconWidth = iconFm.stringWidth(displayIcon);
                int iconHeight = iconFm.getAscent();
                int iconX = iconContainerX + (iconContainerSize - iconWidth) / 2;
                int iconY = iconContainerY + (iconContainerSize - iconHeight) / 2 + iconFm.getAscent();
                
                // For fallback icons, draw a circle background
                if (useFallbackIcon) {
                    int circleSize = Math.min(iconContainerSize - 8, 28);
                    int circleX = iconContainerX + (iconContainerSize - circleSize) / 2;
                    int circleY = iconContainerY + (iconContainerSize - circleSize) / 2;
                    
                    // Draw circle background
                    g2.setColor(isActive ? new Color(255, 255, 255, 200) : new Color(255, 255, 255, 100));
                    g2.fillOval(circleX, circleY, circleSize, circleSize);
                    
                    // Draw circle border
                    g2.setColor(isActive ? PRIMARY_BLUE : new Color(255, 255, 255, 150));
                    g2.setStroke(new BasicStroke(1.5f));
                    g2.drawOval(circleX, circleY, circleSize, circleSize);
                    
                    // Center the text in the circle
                    iconX = iconContainerX + (iconContainerSize - iconWidth) / 2;
                    iconY = iconContainerY + (iconContainerSize + iconFm.getAscent() - iconFm.getDescent()) / 2;
                    
                    // Draw the fallback character
                    g2.setColor(isActive ? PRIMARY_BLUE : Color.WHITE);
                } else {
                    // For emoji icons, draw with a subtle shadow
                    g2.setColor(new Color(0, 0, 0, 40));
                    g2.drawString(displayIcon, iconX + 1, iconY + 1);
                    g2.setColor(isActive ? PRIMARY_BLUE : Color.WHITE);
                }
                
                // Draw the main icon/character
                g2.drawString(displayIcon, iconX, iconY);
                
                // For debugging: Draw a border around the icon area
                // g2.setColor(Color.RED);
                // g2.drawRect(iconContainerX, iconContainerY, iconContainerSize, iconContainerSize);
                
                // Text container
                int textX = iconContainerX + iconContainerSize + ICON_TEXT_GAP;
                int textWidth = w - textX - PADDING;
                
                // Title text
                g2.setFont(new Font("SansSerif", Font.BOLD, 14));
                FontMetrics titleFm = g2.getFontMetrics();
                int titleY = (h / 2) - 8; // Slightly above center
                
                // Truncate title if too long
                String displayTitle = title;
                if (titleFm.stringWidth(displayTitle) > textWidth) {
                    while (titleFm.stringWidth(displayTitle + "...") > textWidth && displayTitle.length() > 0) {
                        displayTitle = displayTitle.substring(0, displayTitle.length() - 1);
                    }
                    displayTitle += "...";
                }
                
                if (isActive) {
                    g2.setColor(new Color(15, 23, 42));
                } else {
                    g2.setColor(Color.WHITE);
                }
                g2.drawString(displayTitle, textX, titleY);
                
                // Description text
                g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
                FontMetrics descFm = g2.getFontMetrics();
                int descY = titleY + descFm.getHeight() + 2;
                
                // Truncate description if too long
                String displayDesc = description;
                if (descFm.stringWidth(displayDesc) > textWidth) {
                    while (descFm.stringWidth(displayDesc + "...") > textWidth && displayDesc.length() > 0) {
                        displayDesc = displayDesc.substring(0, displayDesc.length() - 1);
                    }
                    displayDesc += "...";
                }
                
                if (isActive) {
                    g2.setColor(NEUTRAL_GRAY);
                } else {
                    g2.setColor(new Color(255, 255, 255, 180));
                }
                g2.drawString(displayDesc, textX, descY);
            }

            @Override
            public void setHovered(boolean hovered) {
                this.isHovered = hovered;
                super.setHovered(hovered);
            }

            @Override
            public void setActive(boolean active) {
                this.isActive = active;
                super.setActive(active);
            }
        };
        
        btn.setPreferredSize(new Dimension(260, 65)); // Taller for description text
        return btn;
    }

    private Panel createEnhancedUserInfoPanel() {
        Panel userPanel = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Modern glassmorphism background
                GradientPaint userGradient = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 120),
                    0, h, new Color(255, 255, 255, 80)
                );
                g2.setPaint(userGradient);
                g2.fillRoundRect(16, 12, w-32, h-24, 20, 20);
                
                // Border with glow
                g2.setColor(new Color(255, 255, 255, 200));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(16, 12, w-32, h-24, 20, 20);
                
                // Inner highlight
                g2.setColor(new Color(255, 255, 255, 100));
                g2.drawRoundRect(17, 13, w-34, h-26, 18, 18);
                
                super.paint(g);
            }
        };
        
        userPanel.setPreferredSize(new Dimension(0, 100));
        userPanel.setBackground(new Color(0, 0, 0, 0));
        userPanel.setLayout(new BorderLayout());
        
        // User info content
        Panel userContent = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                if (currentUser != null) {
                    // User name
                    g2.setFont(new Font("SansSerif", Font.BOLD, 14));
                    g2.setColor(Color.WHITE);
                    FontMetrics fm = g2.getFontMetrics();
                    int nameY = 25;
                    g2.drawString(currentUser.username, 50, nameY);
                    
                    // Role with badge
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
                    String roleEmoji = "Cashier".equalsIgnoreCase(role) ? "💰" : 
                                      "Manager".equalsIgnoreCase(role) ? "👔" : "👤";
                    String roleText = roleEmoji + " " + role;
                    g2.setColor(new Color(255, 255, 255, 200));
                    g2.drawString(roleText, 50, nameY + 18);
                    
                    // Status indicator
                    g2.setColor(SUCCESS_GREEN);
                    g2.fillOval(50, nameY + 25, 8, 8);
                    g2.setColor(new Color(255, 255, 255, 180));
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
                    g2.drawString("Online", 65, nameY + 33);
                    
                    // User avatar
                    g2.setColor(Color.WHITE);
                    g2.fillOval(15, 15, 30, 30);
                    g2.setColor(PRIMARY_BLUE);
                    g2.setStroke(new BasicStroke(2f));
                    g2.drawOval(15, 15, 30, 30);
                    
                    // Avatar icon
                    g2.setColor(PRIMARY_BLUE);
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
                    FontMetrics avatarFm = g2.getFontMetrics();
                    int avatarX = 15 + (30 - avatarFm.stringWidth("👤")) / 2;
                    int avatarY = 15 + (30 + avatarFm.getAscent() - avatarFm.getDescent()) / 2;
                    g2.drawString("👤", avatarX, avatarY);
                }
            }
        };
        userContent.setBackground(new Color(0, 0, 0, 0));
        userContent.setPreferredSize(new Dimension(0, 60));
        
        Panel userPadding = new Panel(new FlowLayout(FlowLayout.LEFT, 0, 20));
        userPadding.setBackground(new Color(0, 0, 0, 0));
        userPadding.add(userContent);
        
        userPanel.add(userPadding, BorderLayout.CENTER);
        return userPanel;
    }

    private void createModernContentArea() {
        content.setBackground(LIGHT_GRAY);

        // Enhanced panels with modern styling
        DashboardPanel dashboardPanel = new EnhancedDashboardPanel();
        content.add(dashboardPanel, "dashboard");
        
        InventoryPanel inventoryPanel = new EnhancedInventoryPanel();
        content.add(inventoryPanel, "inventory");
        
        SalesPanel salesPanel = new EnhancedSalesPanel(() -> { 
            inventoryPanel.refreshList(); 
            dashboardPanel.refreshFromDB(); 
        });
        content.add(salesPanel, "sales");
        
        content.add(new EnhancedInvoicesPanel(), "invoices");
        content.add(new EnhancedQuotationsPanel(), "quotations");
        content.add(new EnhancedReportsPanel(), "reports");
        content.add(new AnalyticsPanel(), "analytics");

        add(content, BorderLayout.CENTER);
        
        // Add notification overlay - using a wrapper panel to avoid layout issues
        Panel notificationWrapper = new Panel(new BorderLayout()) {
            @Override
            public void paint(Graphics g) {
                // Make sure the background is transparent
                g.setColor(new Color(0, 0, 0, 0));
                g.fillRect(0, 0, getWidth(), getHeight());
                super.paint(g);
            }
        };
        notificationWrapper.setBackground(new Color(0, 0, 0, 0));
        notificationWrapper.add(notificationManager, BorderLayout.EAST);
        add(notificationWrapper, BorderLayout.NORTH);
    }

    private void setupModernMenuBar() {
        MenuBar mb = new MenuBar();
        
        // File menu with modern icons
        Menu file = new Menu("📁 File");
        MenuItem backup = new MenuItem("💾 Backup Database");
        MenuItem restore = new MenuItem("♻️ Restore Database");
        MenuItem exportData = new MenuItem("📤 Export Data");
        MenuItem importData = new MenuItem("📥 Import Data");
        MenuItem logout = new MenuItem("🚪 Logout");
        MenuItem exit = new MenuItem("❌ Exit");
        
        file.add(backup);
        file.add(restore);
        file.addSeparator();
        file.add(exportData);
        file.add(importData);
        file.addSeparator();
        file.add(logout);
        file.add(exit);
        
        // Tools menu
        Menu tools = new Menu("🔧 Tools");
        MenuItem calculator = new MenuItem("🧮 Calculator");
        MenuItem scanner = new MenuItem("📷 Barcode Scanner");
        MenuItem printer = new MenuItem("🖨️ Printer Setup");
        MenuItem settings = new MenuItem("⚙️ Settings");
        
        tools.add(calculator);
        tools.add(scanner);
        tools.add(printer);
        tools.addSeparator();
        tools.add(settings);
        
        // View menu
        Menu view = new Menu("👁️ View");
        MenuItem fullscreen = new MenuItem("⛶ Toggle Fullscreen");
        MenuItem theme = new MenuItem("🎨 Change Theme");
        MenuItem zoom = new MenuItem("🔍 Zoom");
        
        view.add(fullscreen);
        view.add(theme);
        view.add(zoom);
        
        // Help menu
        Menu help = new Menu("❓ Help");
        MenuItem userGuide = new MenuItem("📖 User Guide");
        MenuItem shortcuts = new MenuItem("⌨️ Keyboard Shortcuts");
        MenuItem support = new MenuItem("💬 Contact Support");
        MenuItem about = new MenuItem("ℹ️ About");
        
        help.add(userGuide);
        help.add(shortcuts);
        help.add(support);
        help.addSeparator();
        help.add(about);
        
        mb.add(file);
        mb.add(tools);
        mb.add(view);
        mb.add(help);
        setMenuBar(mb);

        // Event handlers
        backup.addActionListener(e -> doEnhancedBackup());
        restore.addActionListener(e -> doEnhancedRestore());
        exportData.addActionListener(e -> doDataExport());
        importData.addActionListener(e -> doDataImport());
        logout.addActionListener(e -> doLogout());
        exit.addActionListener(e -> { cleanup(); dispose(); System.exit(0); });
        
        fullscreen.addActionListener(e -> toggleFullscreen());
        calculator.addActionListener(e -> openCalculator());
        scanner.addActionListener(e -> openBarcodeScanner());
        settings.addActionListener(e -> openSettings());
        
        userGuide.addActionListener(e -> openUserGuide());
        shortcuts.addActionListener(e -> showKeyboardShortcuts());
        about.addActionListener(e -> showAboutDialog());
    }

    private void setupKeyboardShortcuts() {
        // Add keyboard listeners for common shortcuts
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.isControlDown()) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_1:
                            setActiveButton(tabButtons[0]);
                            showCard("dashboard");
                            break;
                        case KeyEvent.VK_2:
                            setActiveButton(tabButtons[1]);
                            showCard("inventory");
                            break;
                        case KeyEvent.VK_3:
                            setActiveButton(tabButtons[2]);
                            showCard("sales");
                            break;
                        case KeyEvent.VK_S:
                            if (e.isShiftDown()) {
                                // Quick sale shortcut
                                showCard("sales");
                                setActiveButton(tabButtons[2]);
                                notificationManager.showNotification("Quick Sale activated", NotificationManager.Type.SUCCESS);
                            }
                            break;
                        case KeyEvent.VK_F:
                            if (e.isShiftDown()) {
                                toggleFullscreen();
                            }
                            break;
                        case KeyEvent.VK_B:
                            if (e.isShiftDown()) {
                                doEnhancedBackup();
                            }
                            break;
                    }
                }
            }
        });
        setFocusable(true);
    }

    // Enhanced menu action methods
    private void doEnhancedBackup() {
        FileDialog fd = new FileDialog(this, "Save Enhanced Backup", FileDialog.SAVE);
        fd.setFile("bizflow-backup-" + System.currentTimeMillis() + ".db");
        fd.setVisible(true);
        if (fd.getFile() == null) return;
        
        try {
            File dest = new File(fd.getDirectory(), fd.getFile());
            BackupUtil.copyFile(new File("pos.db"), dest);
            
            notificationManager.showNotification(
                "Backup completed successfully to " + dest.getName(), 
                NotificationManager.Type.SUCCESS
            );
            
            // Update connection status to show backup activity
            connectionStatus.setStatus(StatusIndicator.Status.SYNCING);
            Timer resetStatus = new Timer(3000, e -> connectionStatus.setStatus(StatusIndicator.Status.CONNECTED));
            resetStatus.setRepeats(false);
            resetStatus.start();
            
        } catch (Exception ex) {
            notificationManager.showNotification(
                "Backup failed: " + ex.getMessage(), 
                NotificationManager.Type.ERROR
            );
            ex.printStackTrace();
        }
    }

    private void doEnhancedRestore() {
        FileDialog fd = new FileDialog(this, "Restore From Enhanced Backup", FileDialog.LOAD);
        fd.setVisible(true);
        if (fd.getFile() == null) return;
        
        try {
            File src = new File(fd.getDirectory(), fd.getFile());
            BackupUtil.copyFile(src, new File("pos.db"));
            
            notificationManager.showNotification(
                "Database restored successfully from " + src.getName(), 
                NotificationManager.Type.SUCCESS
            );
            
            // Refresh all panels
            // This would typically trigger a full data refresh
            
        } catch (Exception ex) {
            notificationManager.showNotification(
                "Restore failed: " + ex.getMessage(), 
                NotificationManager.Type.ERROR
            );
            ex.printStackTrace();
        }
    }

    private void doDataExport() {
        notificationManager.showNotification("Data export feature coming soon", NotificationManager.Type.INFO);
    }

    private void doDataImport() {
        notificationManager.showNotification("Data import feature coming soon", NotificationManager.Type.INFO);
    }

    private void openCalculator() {
        notificationManager.showNotification("Calculator opened", NotificationManager.Type.INFO);
        // Could open a calculator dialog here
    }

    private void openBarcodeScanner() {
        notificationManager.showNotification("Barcode scanner initialized", NotificationManager.Type.INFO);
        // Could open barcode scanner interface here
    }

    private void openSettings() {
        notificationManager.showNotification("Settings panel opened", NotificationManager.Type.INFO);
        // Could open settings dialog here
    }

    private void openUserGuide() {
        notificationManager.showNotification("Opening user guide...", NotificationManager.Type.INFO);
    }

    private void showKeyboardShortcuts() {
        String shortcuts = "Keyboard Shortcuts:\n" +
                          "Ctrl+1: Dashboard\n" +
                          "Ctrl+2: Inventory\n" +
                          "Ctrl+3: Sales\n" +
                          "Ctrl+Shift+S: Quick Sale\n" +
                          "Ctrl+Shift+F: Toggle Fullscreen\n" +
                          "Ctrl+Shift+B: Backup Database";
        
        // This would show a proper dialog in a full implementation
        notificationManager.showNotification("Check console for shortcuts", NotificationManager.Type.INFO);
        System.out.println(shortcuts);
    }

    private void showAboutDialog() {
        String about = "BizFlow POS System v2.0\n" +
                      "Modern inventory management solution\n" +
                      "Built with Java AWT/Swing\n" +
                      "© 2024 BizFlow Technologies";
        
        notificationManager.showNotification("BizFlow POS v2.0 - Modern Edition", NotificationManager.Type.INFO);
        System.out.println(about);
    }

    // setActiveButton method is already defined, removing duplicate

    private void doLogout() {
        cleanup();
        openLogin();
        
        // Reset UI state
        if (tabButtons != null && tabButtons.length > 0) {
            setActiveButton(tabButtons[0]);
        }
        showCard("dashboard");
    }

    private void openLogin() {
        LoginDialog dlg = new EnhancedLoginDialog(this);
        dlg.setVisible(true);
        User u = dlg.getUser();
        if (u == null) { 
            cleanup();
            dispose(); 
            System.exit(0); 
        }
        this.currentUser = u;
        this.role = u.role;
        applyRoleVisibility();
        showCard("dashboard");
        if (tabButtons != null && tabButtons.length > 0) {
            setActiveButton(tabButtons[0]);
        }
        
        // Welcome notification
        if (notificationManager != null) {
            notificationManager.showNotification(
                "Welcome back, " + currentUser.username + "!", 
                NotificationManager.Type.SUCCESS
            );
        }
    }

    private void applyRoleVisibility() {
        String roleEmoji = "Cashier".equalsIgnoreCase(role) ? "" : 
                          "Manager".equalsIgnoreCase(role) ? "" : "";
        setTitle("BizFlow POS - " + currentUser.username + " [" + roleEmoji + " " + role + "]");
        
        // Update user avatar
        if (userAvatarLabel != null) {
            userAvatarLabel.setText(roleEmoji);
            userAvatarLabel.repaint();
        }
    }

    private void showCard(String name) {
        // Role-based access control
        if ("Cashier".equalsIgnoreCase(role)) {
            if (!("sales".equals(name) || "invoices".equals(name))) {
                name = "sales";
                if (tabButtons != null) {
                    setActiveButton(tabButtons[2]);
                }
                if (notificationManager != null) {
                    notificationManager.showNotification(
                        "Access restricted to Sales and Invoices for Cashier role", 
                        NotificationManager.Type.WARNING
                    );
                }
            }
        }
        
        cards.show(content, name);
    }

    private void cleanup() {
        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
        }
        if (clockTimer != null && clockTimer.isRunning()) {
            clockTimer.stop();
        }
    }

    @Override
    public void dispose() {
        cleanup();
        super.dispose();
    }

    // Enhanced panel classes (placeholders for actual implementations)
    private class EnhancedDashboardPanel extends DashboardPanel {
        // Enhanced dashboard with modern widgets, charts, and real-time data
    }
    
    private class EnhancedInventoryPanel extends InventoryPanel {
        // Enhanced inventory with advanced search, filters, and batch operations
    }
    
    private class EnhancedSalesPanel extends SalesPanel {
        public EnhancedSalesPanel(Runnable refreshCallback) {
            super(refreshCallback);
            // Enhanced sales with quick actions, barcode scanning, and payment processing
        }
    }
    
    private class EnhancedInvoicesPanel extends InvoicesPanel {
        // Enhanced invoices with templates, email integration, and PDF generation
    }
    
    private class EnhancedQuotationsPanel extends QuotationsPanel {
        // Enhanced quotations with approval workflows and conversion tracking
    }
    
    // Interface for hoverable panels
    interface HoverablePanel {
        void setHovered(boolean hovered);
    }
    
    private class EnhancedReportsPanel extends ReportsPanel {
        // Inner class for report cards with hover effect
        private class ReportCard extends Panel implements HoverablePanel {
            private boolean isHovered = false;
            private final String title;
            private final String icon;
            
            public ReportCard(String title, String icon) {
                this.title = title;
                this.icon = icon;
                setLayout(new BorderLayout(10, 10));
                setBackground(Color.WHITE);
                setupCard();
            }
            
            private void setupCard() {
                // Card header
                Panel header = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 0));
                header.setBackground(new Color(0, 0, 0, 0));
                
                Label iconLabel = new Label(icon);
                iconLabel.setFont(new Font("SansSerif", Font.PLAIN, 24));
                
                Label titleLabel = new Label(title);
                titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
                titleLabel.setForeground(Theme.TEXT_PRIMARY);
                
                header.add(iconLabel);
                header.add(titleLabel);
                
                // Add some sample content
                Label content = new Label("Click to view detailed report");
                content.setFont(new Font("SansSerif", Font.PLAIN, 12));
                content.setForeground(Theme.TEXT_SECONDARY);
                
                // Add components to card
                add(header, BorderLayout.NORTH);
                add(content, BorderLayout.CENTER);
                
                // Add hover effect
                addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        setHovered(true);
                        setCursor(new Cursor(Cursor.HAND_CURSOR));
                        repaint();
                    }
                    
                    @Override
                    public void mouseExited(MouseEvent e) {
                        setHovered(false);
                        repaint();
                    }
                });
            }
            
            @Override
            public void setHovered(boolean hovered) {
                this.isHovered = hovered;
            }
            
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(CARD_WIDTH, CARD_HEIGHT);
            }
            
            @Override
            public Dimension getMinimumSize() {
                return new Dimension(CARD_WIDTH / 2, CARD_HEIGHT / 2);
            }
            
            @Override
            public Dimension getMaximumSize() {
                return new Dimension(Integer.MAX_VALUE, CARD_HEIGHT);
            }
            
            @Override
            public Insets getInsets() {
                return new Insets(15, 15, 15, 15);
            }
            
            @Override
            public void paint(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw background
                if (isHovered) {
                    g2d.setColor(new Color(249, 250, 251));
                } else {
                    g2d.setColor(Color.WHITE);
                }
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                // Draw border
                g2d.setColor(new Color(229, 231, 235));
                g2d.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
                
                g2d.dispose();
                super.paint(g);
            }
        }
        
        // HoverablePanel interface is now at the top level
        private static final int CARD_WIDTH = 300;
        private static final int CARD_HEIGHT = 200;
        
        public EnhancedReportsPanel() {
            super(); // Call parent constructor
            setBackground(Theme.BACKGROUND);
            setLayout(new BorderLayout());
            
            // Top panel with title and actions
            Panel topPanel = new Panel(new BorderLayout()) {
                @Override
                public Insets getInsets() {
                    return new Insets(15, 20, 15, 20);
                }
            };
            topPanel.setBackground(Theme.BACKGROUND);
            
            // Title with icon
            Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            titlePanel.setBackground(Theme.BACKGROUND);
            
            Label titleLabel = new Label("📊 Reports");
            titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
            titleLabel.setForeground(Theme.TEXT_PRIMARY);
            titlePanel.add(titleLabel);
            
            topPanel.add(titlePanel, BorderLayout.WEST);
            
            // Add refresh button
            RoundedButton refreshButton = new RoundedButton("🔄 Refresh");
            refreshButton.setPreferredSize(new Dimension(120, 35));
            refreshButton.addActionListener(e -> refreshReports());
            
            Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.setBackground(Theme.BACKGROUND);
            buttonPanel.add(refreshButton);
            topPanel.add(buttonPanel, BorderLayout.EAST);
            
            // Main content panel with cards
            Panel contentPanel = new Panel();
            contentPanel.setBackground(Theme.BACKGROUND);
            contentPanel.setLayout(new GridBagLayout());
            
            // Add some padding around the content
            Panel paddingPanel = new Panel(new BorderLayout()) {
                @Override
                public Insets getInsets() {
                    return new Insets(0, 20, 20, 20);
                }
            };
            paddingPanel.setBackground(Theme.BACKGROUND);
            
            // Create report cards
            createReportCards(contentPanel);
            
            // Add components to the main panel
            paddingPanel.add(contentPanel, BorderLayout.CENTER);
            
            // Add a scroll pane for responsiveness
            ScrollPane scrollPane = new ScrollPane();
            scrollPane.setBackground(Theme.BACKGROUND);
            scrollPane.add(paddingPanel);
            
            // Add all components to the main panel
            add(topPanel, BorderLayout.NORTH);
            add(scrollPane, BorderLayout.CENTER);
            
            // Make sure the panel is visible
            setVisible(true);
        }
        
        private void createReportCards(Panel container) {
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.BOTH;
            
            // Sample report cards - in a real app, these would be generated from data
            String[] reportTitles = {
                "Sales Summary", "Top Products", "Inventory Status", 
                "Revenue Trends", "Customer Reports", "Tax Reports"
            };
            
            String[] icons = {"💰", "📦", "📊", "📈", "👥", "🧾"};
            
            for (int i = 0; i < reportTitles.length; i++) {
                gbc.gridx = i % 3; // 3 columns
                gbc.gridy = i / 3;
                gbc.weightx = 1.0;
                gbc.weighty = 1.0;
                
                Panel card = createReportCard(reportTitles[i], icons[i]);
                container.add(card, gbc);
            }
            
            // Add an empty panel to take up remaining space
            gbc.gridx = 0;
            gbc.gridy = (reportTitles.length + 2) / 3; // Next row
            gbc.gridwidth = 3; // Span all columns
            gbc.weighty = 1.0;
            container.add(new Panel(), gbc);
        }
        
        private Panel createReportCard(String title, String icon) {
            return new ReportCard(title, icon);
        }
        
        private void refreshReports() {
            // In a real app, this would refresh the report data
            notificationManager.showNotification("Refreshing reports...", NotificationManager.Type.INFO);
            System.out.println("Refreshing reports...");
        }
    }
    
    // Using the enhanced AnalyticsPanel from pos.ui.panels package
    
    private class EnhancedLoginDialog extends LoginDialog {
        public EnhancedLoginDialog(Frame parent) {
            super(parent);
            // Enhanced login with modern styling, remember me option, and security features
        }
    }
}