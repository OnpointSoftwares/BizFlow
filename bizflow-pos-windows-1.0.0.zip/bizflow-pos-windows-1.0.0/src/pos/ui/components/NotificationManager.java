package pos.ui.components;

import java.awt.*;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

public class NotificationManager extends Panel {
    public enum Type {
        INFO, SUCCESS, WARNING, ERROR
    }
    
    private static final int NOTIFICATION_WIDTH = 300;
    private static final int NOTIFICATION_HEIGHT = 60;
    private static final int MARGIN = 20;
    private static final int NOTIFICATION_DURATION = 5000; // 5 seconds
    
    private LinkedList<Notification> notifications = new LinkedList<>();
    private Timer timer;
    
    public NotificationManager() {
        setLayout(null);
        setBackground(new Color(0, 0, 0, 0));
        setPreferredSize(new Dimension(NOTIFICATION_WIDTH, 0));
    }
    
    public void showNotification(String message, Type type) {
        Notification notification = new Notification(message, type);
        notifications.addFirst(notification);
        add(notification);
        
        // Position the notification
        positionNotifications();
        
        // Auto-remove after duration
        TimerTask task = new TimerTask() {
            public void run() {
                removeNotification(notification);
            }
        };
        
        if (timer != null) {
            timer.cancel();
        }
        
        timer = new Timer();
        timer.schedule(task, NOTIFICATION_DURATION);
    }
    
    private void removeNotification(Notification notification) {
        if (getComponentZOrder(notification) >= 0) {
            remove(notification);
            notifications.remove(notification);
            positionNotifications();
            validate();
            repaint();
        }
    }
    
    private void positionNotifications() {
        int y = MARGIN;
        for (Notification n : notifications) {
            n.setBounds(getWidth() - NOTIFICATION_WIDTH - MARGIN, y, 
                       NOTIFICATION_WIDTH, NOTIFICATION_HEIGHT);
            y += NOTIFICATION_HEIGHT + 10;
        }
    }
    
    @Override
    public void paint(Graphics g) {
        // Make sure we're transparent
        g.setColor(new Color(0, 0, 0, 0));
        g.fillRect(0, 0, getWidth(), getHeight());
        
        // Paint all child components
        super.paint(g);
    }
    
    private class Notification extends Panel {
        private String message;
        private Type type;
        
        public Notification(String message, Type type) {
            this.message = message;
            this.type = type;
            setBackground(new Color(0, 0, 0, 0));
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Background with shadow
            g2.setColor(new Color(0, 0, 0, 100));
            g2.fillRoundRect(3, 3, getWidth(), getHeight(), 10, 10);
            
            // Main background
            switch (type) {
                case SUCCESS:
                    g2.setColor(new Color(220, 252, 231)); // Light green
                    break;
                case WARNING:
                    g2.setColor(new Color(255, 247, 237)); // Light orange
                    break;
                case ERROR:
                    g2.setColor(new Color(254, 242, 242)); // Light red
                    break;
                default: // INFO
                    g2.setColor(new Color(236, 253, 245)); // Light blue
            }
            g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 10, 10);
            
            // Left border
            switch (type) {
                case SUCCESS:
                    g2.setColor(new Color(34, 197, 94)); // Green
                    break;
                case WARNING:
                    g2.setColor(new Color(249, 115, 22)); // Orange
                    break;
                case ERROR:
                    g2.setColor(new Color(239, 68, 68)); // Red
                    break;
                default: // INFO
                    g2.setColor(new Color(59, 130, 246)); // Blue
            }
            g2.fillRoundRect(0, 0, 6, getHeight() - 3, 10, 10);
            
            // Text
            g2.setColor(Color.BLACK);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            FontMetrics fm = g2.getFontMetrics();
            int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(message, 20, textY);
            
            g2.dispose();
        }
    }
}
