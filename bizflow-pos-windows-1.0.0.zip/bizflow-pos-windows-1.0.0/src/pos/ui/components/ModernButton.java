package pos.ui.components;

import pos.ui.theme.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ModernButton extends JButton {
    private Color defaultBackground;
    private Color hoverBackground;
    private Color pressedBackground;
    private boolean isHovered = false;
    private boolean isPressed = false;
    private int borderRadius = 6;

    public ModernButton(String text) {
        super(text);
        init();
    }

    private void init() {
        // Set default colors
        setBackground(Theme.PRIMARY_500);
        setForeground(Color.WHITE);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(false);
        setContentAreaFilled(false);
        
        // Set padding
        setBorder(new EmptyBorder(8, 16, 8, 16));
        
        // Set font
        setFont(getFont().deriveFont(Font.BOLD));
        
        // Calculate colors
        defaultBackground = getBackground();
        hoverBackground = defaultBackground.darker();
        pressedBackground = hoverBackground.darker();
        
        // Add mouse listener for hover and press effects
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                isPressed = false;
                repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                isPressed = true;
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isPressed = false;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw background
        if (isEnabled()) {
            if (isPressed) {
                g2.setColor(pressedBackground);
            } else if (isHovered) {
                g2.setColor(hoverBackground);
            } else {
                g2.setColor(defaultBackground);
            }
        } else {
            g2.setColor(Color.LIGHT_GRAY);
        }
        
        // Draw rounded rectangle
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), borderRadius, borderRadius);
        
        // Draw text
        g2.setColor(getForeground());
        FontMetrics fm = g2.getFontMetrics();
        Rectangle r = getBounds();
        String text = getText();
        int textX = (r.width - fm.stringWidth(text)) / 2;
        int textY = (r.height - fm.getHeight()) / 2 + fm.getAscent();
        g2.setFont(getFont());
        g2.drawString(text, textX, textY);
        
        g2.dispose();
    }

    @Override
    public void setBackground(Color bg) {
        super.setBackground(bg);
        if (bg != null) {
            defaultBackground = bg;
            hoverBackground = bg.darker();
            pressedBackground = hoverBackground.darker();
        }
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        setForeground(enabled ? Color.WHITE : Color.GRAY);
        repaint();
    }

    public void setBorderRadius(int radius) {
        this.borderRadius = radius;
        repaint();
    }

    public int getBorderRadius() {
        return borderRadius;
    }
}
