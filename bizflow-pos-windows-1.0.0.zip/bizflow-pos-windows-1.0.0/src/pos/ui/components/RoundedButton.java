package pos.ui.components;

import pos.ui.theme.Theme;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class RoundedButton extends Canvas implements MouseListener {
    private String text;
    protected boolean hover = false;
    protected boolean active = false;
    private Color bg = Theme.PRIMARY;
    private Color bgHover = Theme.PRIMARY_HOVER;
    private Color fg = Color.WHITE;
    private List<ActionListener> actionListeners = new ArrayList<>();

    public RoundedButton(String text) {
        this.text = text;
        setSize(120, 36);
        setBackground(new Color(0,0,0,0));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(this);
    }
    
    public void addActionListener(ActionListener listener) {
        actionListeners.add(listener);
    }
    
    public void removeActionListener(ActionListener listener) {
        actionListeners.remove(listener);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "");
        for (ActionListener listener : actionListeners) {
            listener.actionPerformed(event);
        }
    }
    
    @Override
    public void mouseEntered(MouseEvent e) { 
        hover = true; 
        repaint(); 
    }
    
    @Override
    public void mouseExited(MouseEvent e) { 
        hover = false; 
        repaint(); 
    }
    
    @Override
    public void mousePressed(MouseEvent e) {}
    
    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth(); int h = getHeight();
        // shadow
        g2.setColor(Theme.SHADOW);
        g2.fillRoundRect(2, 3, w-1, h, h, h);
        // button
        g2.setColor(hover || active ? bgHover : bg);
        g2.fillRoundRect(0, 0, w-2, h-2, h, h);
        g2.setColor(fg);
        FontMetrics fm = g2.getFontMetrics();
        int tw = fm.stringWidth(text);
        int th = fm.getAscent();
        g2.drawString(text, (w - tw)/2, (h + th)/2 - 4);
    }

    public void setColors(Color bg, Color bgHover, Color fg) {
        if (bg != null) this.bg = bg;
        if (bgHover != null) this.bgHover = bgHover;
        if (fg != null) this.fg = fg;
        repaint();
    }
    
    public void setBackground(Color bg) {
        this.bg = bg;
        repaint();
    }
    
    public void setForeground(Color fg) {
        this.fg = fg;
        repaint();
    }
    
    // setActive method is already defined, removing duplicate
    public void setText(String t){ this.text = t; repaint(); }
    public String getText(){ return this.text; }

    // Navigation helpers for external callers
    public void setHovered(boolean hovered){ this.hover = hovered; repaint(); }
    public void setActive(boolean active){ this.active = active; repaint(); }
}
