package pos.ui.components;

import java.awt.*;

public class StatusIndicator extends Component {
    public enum Status {
        CONNECTED, DISCONNECTED, SYNCING, ERROR
    }
    
    private Status status = Status.DISCONNECTED;
    private static final int SIZE = 10;
    
    public StatusIndicator() {
        this(Status.DISCONNECTED);
    }
    
    public StatusIndicator(Status initialStatus) {
        this.status = initialStatus;
        setPreferredSize(new Dimension(SIZE, SIZE));
    }
    
    public void setStatus(Status status) {
        this.status = status;
        repaint();
    }
    
    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        switch (status) {
            case CONNECTED:
                g2.setColor(new Color(34, 197, 94)); // Green
                break;
            case DISCONNECTED:
                g2.setColor(new Color(156, 163, 175)); // Gray
                break;
            case SYNCING:
                g2.setColor(new Color(250, 204, 21)); // Yellow
                break;
            case ERROR:
                g2.setColor(new Color(239, 68, 68)); // Red
                break;
        }
        
        g2.fillOval(0, 0, SIZE, SIZE);
        
        // Add a subtle highlight
        g2.setColor(new Color(255, 255, 255, 100));
        g2.fillOval(2, 2, SIZE/2, SIZE/3);
        
        g2.dispose();
    }
}
