package pos.ui.components;

import java.awt.*;
import java.awt.event.*;

public class ModernSearchField extends TextField {
    private String placeholder;
    private boolean showingPlaceholder;
    private Color placeholderColor = new Color(156, 163, 175);
    private Color borderColor = new Color(209, 213, 219);
    private Color focusBorderColor = new Color(59, 130, 246);
    private Color backgroundColor = Color.WHITE;
    private boolean hasFocus = false;
    
    public ModernSearchField(String placeholder) {
        super(placeholder);
        this.placeholder = placeholder;
        this.showingPlaceholder = true;
        
        setBackground(backgroundColor);
        setForeground(placeholderColor);
        setFont(new Font("SansSerif", Font.PLAIN, 14));
        
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                hasFocus = true;
                if (showingPlaceholder) {
                    setText("");
                    setForeground(Color.BLACK);
                    showingPlaceholder = false;
                }
                repaint();
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                hasFocus = false;
                if (getText().isEmpty()) {
                    showingPlaceholder = true;
                    setText(placeholder);
                    setForeground(placeholderColor);
                }
                repaint();
            }
        });
    }
    
    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Background
        g2.setColor(backgroundColor);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
        
        // Border
        if (hasFocus) {
            g2.setColor(focusBorderColor);
            g2.setStroke(new BasicStroke(2f));
        } else {
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1f));
        }
        g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 10, 10);
        
        // Search icon
        g2.setColor(hasFocus ? focusBorderColor : placeholderColor);
        g2.setStroke(new BasicStroke(2f));
        g2.drawOval(12, getHeight()/2 - 6, 12, 12);
        g2.drawLine(20, getHeight()/2 + 6, 26, getHeight()/2 + 12);
        
        // Draw text with padding
        g2.setFont(getFont());
        FontMetrics fm = g2.getFontMetrics();
        int textX = 40; // Leave space for the icon
        int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        
        if (showingPlaceholder) {
            g2.setColor(placeholderColor);
        } else {
            g2.setColor(getForeground());
        }
        g2.drawString(getText(), textX, textY);
    }
    
    @Override
    public String getText() {
        String text = super.getText();
        return showingPlaceholder ? "" : text;
    }
    
    @Override
    public void setText(String text) {
        if (text == null || text.isEmpty()) {
            showingPlaceholder = true;
            super.setText(placeholder);
            setForeground(placeholderColor);
        } else {
            showingPlaceholder = false;
            super.setText(text);
            setForeground(Color.BLACK);
        }
    }
}
