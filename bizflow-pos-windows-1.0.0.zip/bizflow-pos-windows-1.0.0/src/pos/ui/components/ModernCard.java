package pos.ui.components;

import pos.ui.theme.Theme;

import java.awt.*;

public class ModernCard extends Panel {
    private String title;
    private String value;
    private Color accent = Theme.ACCENT;

    public ModernCard(String title, String value){
        this.title = title; this.value = value;
        setBackground(new Color(0,0,0,0));
        setPreferredSize(new Dimension(240, 120));
    }

    @Override
    public void paint(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth(); int h = getHeight();
        // shadow
        g2.setColor(Theme.SHADOW);
        g2.fillRoundRect(6, 8, w-6, h-4, 18, 18);
        // gradient background
        GradientPaint gp = new GradientPaint(0,0, Theme.CARD_BG, 0, h, new Color(246,249,252));
        g2.setPaint(gp);
        g2.fillRoundRect(0, 0, w-8, h-8, 18, 18);
        // border
        g2.setColor(Theme.BORDER);
        g2.drawRoundRect(0, 0, w-8, h-8, 18, 18);
        // text
        g2.setFont(Theme.H2);
        g2.setColor(Theme.MUTED_TEXT);
        g2.drawString(title, 16, 36);
        g2.setFont(new Font("SansSerif", Font.BOLD, 28));
        g2.setColor(accent);
        g2.drawString(value, 16, 80);
    }

    public void setValue(String value){ this.value = value; repaint(); }
}
