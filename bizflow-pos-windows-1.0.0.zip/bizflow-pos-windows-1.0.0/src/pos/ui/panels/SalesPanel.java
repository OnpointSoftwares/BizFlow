package pos.ui.panels;

import pos.dao.ProductDAO;
import pos.dao.SaleDAO;
import pos.models.Product;
import pos.models.Sale;
import pos.models.SaleItem;
import pos.ui.components.RoundedButton;
import pos.ui.components.StyledTextField;
import pos.ui.theme.Theme;
import pos.util.Formatter;

import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.text.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.Timer;

public class SalesPanel extends Panel {
    private EnhancedTextField search = new EnhancedTextField("🔍 Search products...", 25);
    private EnhancedTextField barcode = new EnhancedTextField("📱 Scan or enter SKU", 25);
    private List<Product> results = new ArrayList<>();
    private List<SaleItem> cart = new ArrayList<>();
    private Runnable onAfterCheckout;
    
    // Cart update listeners
    public interface CartUpdateListener {
        void onCartUpdated(List<SaleItem> cart);
    }
    
    private final List<CartUpdateListener> cartUpdateListeners = new ArrayList<>();
    
    public void addCartUpdateListener(CartUpdateListener listener) {
        if (listener != null) {
            cartUpdateListeners.add(listener);
        }
    }
    
    public void removeCartUpdateListener(CartUpdateListener listener) {
        cartUpdateListeners.remove(listener);
    }
    
    private void notifyCartUpdated() {
        for (CartUpdateListener listener : new ArrayList<>(cartUpdateListeners)) {
            listener.onCartUpdated(new ArrayList<>(cart));
        }
        repaint();
    }
    
    private int selectedCartIndex = -1;
    private double discount = 0.0;
    private ModernChoice paymentChoice = new ModernChoice();
    private EnhancedTextField discountField = new EnhancedTextField("0.00", 8);
    private EnhancedTextField tenderedField = new EnhancedTextField("0.00", 10);
    private Timer animationTimer;
    private float pulse = 0f;
    private boolean processingCheckout = false;

    public SalesPanel(Runnable onAfterCheckout) {
        this.onAfterCheckout = onAfterCheckout;
        setLayout(new BorderLayout());
        
        setupAnimationTimer();
        createHeader();
        createMainContent();
        createFooter();
        setupEventHandlers();
        
        doSearch();
    }

    private void setupAnimationTimer() {
        animationTimer = new Timer(50, e -> {
            pulse += 0.1f;
            if (pulse > Math.PI * 2) pulse = 0f;
            repaint();
        });
        animationTimer.start();
    }

    private void createHeader() {
        Panel header = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Modern gradient background
                GradientPaint headerGradient = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 250),
                    0, h, new Color(248, 250, 252, 230)
                );
                g2.setPaint(headerGradient);
                g2.fillRect(0, 0, w, h);
                
                // Animated accent line
                float alpha = (float)(Math.sin(pulse) * 0.3 + 0.7);
                g2.setColor(new Color(34, 197, 94, (int)(255 * alpha)));
                g2.fillRect(0, 0, w, 3);
                
                // Bottom border
                g2.setColor(new Color(226, 232, 240, 100));
                g2.drawLine(0, h-1, w, h-1);
            }
        };
        
        header.setLayout(new BorderLayout());
        header.setPreferredSize(new Dimension(0, 80));
        
        // Title section
        Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 24, 20));
        titlePanel.setBackground(new Color(0, 0, 0, 0));
        
        Label title = new Label("💰 Point of Sale") {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                FontMetrics fm = g2.getFontMetrics();
                int x = 0, y = fm.getAscent();
                
                // Text shadow
                g2.setColor(new Color(0, 0, 0, 30));
                g2.drawString(getText(), x + 1, y + 1);
                
                // Main text
                g2.setColor(new Color(30, 41, 59));
                g2.drawString(getText(), x, y);
            }
        };
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        titlePanel.add(title);
        
        // Search section
        Panel searchPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 16, 15));
        searchPanel.setBackground(new Color(0, 0, 0, 0));
        
        searchPanel.add(search);
        searchPanel.add(barcode);
        
        ModernButton addBtn = new ModernButton("➕ Add Item", new Color(59, 130, 246));
        searchPanel.add(addBtn);
        addBtn.addActionListener(e -> addBySKU());
        
        header.add(titlePanel, BorderLayout.WEST);
        header.add(searchPanel, BorderLayout.CENTER);
        add(header, BorderLayout.NORTH);
    }

    private void createMainContent() {
        Panel mainContent = new Panel(new GridLayout(1, 2, 16, 0)) {
            @Override
            public Insets getInsets() {
                return new Insets(16, 16, 16, 16);
            }
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(248, 250, 252));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Padding set via getInsets()
        
        EnhancedResultsPanel resultsPanel = new EnhancedResultsPanel();
        EnhancedCartPanel cartPanel = new EnhancedCartPanel();
        
        mainContent.add(resultsPanel);
        mainContent.add(cartPanel);
        add(mainContent, BorderLayout.CENTER);
    }

    private void createFooter() {
        Panel footer = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Footer gradient
                GradientPaint footerGradient = new GradientPaint(
                    0, 0, new Color(248, 250, 252, 230),
                    0, h, new Color(255, 255, 255, 250)
                );
                g2.setPaint(footerGradient);
                g2.fillRect(0, 0, w, h);
                
                // Top border with gradient
                GradientPaint borderGradient = new GradientPaint(
                    0f, 0f, new Color(226, 232, 240),
                    w/2f, 0f, new Color(34, 197, 94, 100)
                );
                g2.setPaint(borderGradient);
                g2.fillRect(0, 0, w, 2);
            }
        };
        
        footer.setLayout(new BorderLayout());
        footer.setPreferredSize(new Dimension(0, 90));
        
        // Payment controls
        Panel paymentPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 16, 20));
        paymentPanel.setBackground(new Color(0, 0, 0, 0));
        
        paymentPanel.add(createStyledLabel("💳 Payment:"));
        paymentChoice.add("💵 Cash");
        paymentChoice.add("💳 Card");
        paymentChoice.add("📱 Mobile");
        paymentPanel.add(paymentChoice);
        
        paymentPanel.add(createStyledLabel("💰 Discount:"));
        paymentPanel.add(discountField);
        
        paymentPanel.add(createStyledLabel("💵 Tendered:"));
        paymentPanel.add(tenderedField);
        
        // Action buttons
        Panel actionPanel = new Panel(new FlowLayout(FlowLayout.RIGHT, 12, 20));
        actionPanel.setBackground(new Color(0, 0, 0, 0));
        
        ModernButton removeBtn = new ModernButton("🗑️ Remove", new Color(239, 68, 68));
        ModernButton minusBtn = new ModernButton("➖ Qty", new Color(156, 163, 175));
        ModernButton plusBtn = new ModernButton("➕ Qty", new Color(34, 197, 94));
        ModernButton setQtyBtn = new ModernButton("⚙️ Set Qty", new Color(107, 114, 128));
        ModernButton checkoutBtn = new ModernButton("✅ Checkout", new Color(34, 197, 94)) {
            @Override
            public void paint(Graphics g) {
                if (processingCheckout) {
                    Graphics2D g2 = (Graphics2D) g;
                    int w = getWidth(), h = getHeight();
                    
                    // Pulsing effect during processing
                    float alpha = (float)(Math.sin(pulse * 2) * 0.3 + 0.7);
                    setBaseColor(new Color(34, 197, 94, (int)(255 * alpha)));
                }
                super.paint(g);
            }
        };
        
        actionPanel.add(removeBtn);
        actionPanel.add(minusBtn);
        actionPanel.add(plusBtn);
        actionPanel.add(setQtyBtn);
        actionPanel.add(checkoutBtn);
        
        footer.add(paymentPanel, BorderLayout.WEST);
        footer.add(actionPanel, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);
        
        // Button event handlers
        removeBtn.addActionListener(e -> removeSelected());
        minusBtn.addActionListener(e -> adjustSelected(-1));
        plusBtn.addActionListener(e -> adjustSelected(1));
        setQtyBtn.addActionListener(e -> setSelectedQty());
        checkoutBtn.addActionListener(e -> doCheckout());
    }

    private Label createStyledLabel(String text) {
        Label label = new Label(text) {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(new Color(71, 85, 105));
                g2.setFont(new Font("SansSerif", Font.BOLD, 14));
                g2.drawString(getText(), 0, g2.getFontMetrics().getAscent());
            }
        };
        return label;
    }

    // Enhanced TextField with modern styling
    private class EnhancedTextField extends TextField {
        private String placeholder;
        private boolean isFocused = false;
        
        public EnhancedTextField(String placeholder, int columns) {
            super(columns);
            this.placeholder = placeholder;
            setFont(new Font("SansSerif", Font.PLAIN, 14));
            
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    isFocused = true;
                    repaint();
                }
                
                @Override
                public void focusLost(FocusEvent e) {
                    isFocused = false;
                    repaint();
                }
            });
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Background
            if (isFocused) {
                GradientPaint focusGradient = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 255),
                    0, h, new Color(248, 250, 252, 255)
                );
                g2.setPaint(focusGradient);
            } else {
                g2.setColor(new Color(255, 255, 255, 240));
            }
            g2.fillRoundRect(0, 0, w, h, 10, 10);
            
            // Border
            if (isFocused) {
                g2.setColor(new Color(34, 197, 94, 150));
                g2.setStroke(new BasicStroke(2f));
            } else {
                g2.setColor(new Color(203, 213, 225, 120));
                g2.setStroke(new BasicStroke(1f));
            }
            g2.drawRoundRect(0, 0, w-1, h-1, 10, 10);
            
            // Text
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            String displayText = getText();
            
            if (displayText.isEmpty() && !isFocused) {
                g2.setColor(new Color(156, 163, 175));
                displayText = placeholder;
            } else {
                g2.setColor(new Color(30, 41, 59));
            }
            
            int textX = 12;
            int textY = (h + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(displayText, textX, textY);
        }
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(getColumns() * 8 + 24, 36);
        }
    }

    // Modern Choice component
    private class ModernChoice extends Choice {
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Background
            GradientPaint bg = new GradientPaint(
                0, 0, new Color(255, 255, 255, 240),
                0, h, new Color(248, 250, 252, 220)
            );
            g2.setPaint(bg);
            g2.fillRoundRect(0, 0, w, h, 10, 10);
            
            // Border
            g2.setColor(new Color(203, 213, 225, 120));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0, 0, w-1, h-1, 10, 10);
            
            // Dropdown arrow
            g2.setColor(new Color(107, 114, 128));
            int[] xPoints = {w-20, w-15, w-10};
            int[] yPoints = {h/2-3, h/2+3, h/2-3};
            g2.fillPolygon(xPoints, yPoints, 3);
        }
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(140, 36);
        }
    }

    // Modern Button with enhanced styling
    private class ModernButton extends Button {
        private boolean isHovered = false;
        private boolean isPressed = false;
        private Color baseColor;
        
        public ModernButton(String text, Color color) {
            super(text);
            this.baseColor = color;
            setFont(new Font("SansSerif", Font.BOLD, 14));
            
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHovered = true;
                    repaint();
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    isPressed = false;
                    repaint();
                }
                
                @Override
                public void mousePressed(MouseEvent e) {
                    isPressed = true;
                    repaint();
                }
                
                @Override
                public void mouseReleased(MouseEvent e) {
                    isPressed = false;
                    repaint();
                }
            });
        }
        
        public void setBaseColor(Color color) {
            this.baseColor = color;
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Button background
            Color color1, color2;
            if (isPressed) {
                color1 = darker(baseColor, 0.3f);
                color2 = darker(baseColor, 0.4f);
            } else if (isHovered) {
                color1 = lighter(baseColor, 0.1f);
                color2 = baseColor;
            } else {
                color1 = lighter(baseColor, 0.05f);
                color2 = darker(baseColor, 0.1f);
            }
            
            GradientPaint buttonGradient = new GradientPaint(0, 0, color1, 0, h, color2);
            g2.setPaint(buttonGradient);
            g2.fillRoundRect(0, 0, w, h, 10, 10);
            
            // Button highlight
            if (!isPressed) {
                g2.setColor(new Color(255, 255, 255, 40));
                g2.fillRoundRect(0, 0, w, h/2, 10, 10);
            }
            
            // Text
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int textX = (w - fm.stringWidth(getLabel())) / 2;
            int textY = (h + fm.getAscent() - fm.getDescent()) / 2;
            
            // Text shadow
            g2.setColor(new Color(0, 0, 0, 80));
            g2.drawString(getLabel(), textX + 1, textY + 1);
            
            // Main text
            g2.setColor(Color.WHITE);
            g2.drawString(getLabel(), textX, textY);
        }
        
        @Override
        public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(fm.stringWidth(getLabel()) + 32, 36);
        }
        
        private Color lighter(Color color, float factor) {
            int r = Math.min(255, (int)(color.getRed() * (1 + factor)));
            int g = Math.min(255, (int)(color.getGreen() * (1 + factor)));
            int b = Math.min(255, (int)(color.getBlue() * (1 + factor)));
            return new Color(r, g, b, color.getAlpha());
        }
        
        private Color darker(Color color, float factor) {
            int r = Math.max(0, (int)(color.getRed() * (1 - factor)));
            int g = Math.max(0, (int)(color.getGreen() * (1 - factor)));
            int b = Math.max(0, (int)(color.getBlue() * (1 - factor)));
            return new Color(r, g, b, color.getAlpha());
        }
    }

    // Enhanced Results Panel
    private class EnhancedResultsPanel extends Panel {
        private final List<Rectangle> hitBoxes = new ArrayList<>();
        private int hoveredIndex = -1;
        
        public EnhancedResultsPanel() {
            setBackground(Color.WHITE);
            
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int x = e.getX(), y = e.getY();
                    System.out.println("Mouse clicked at: " + x + ", " + y);
                    
                    for (int i = 0; i < hitBoxes.size(); i++) {
                        Rectangle rect = hitBoxes.get(i);
                        System.out.println("Hitbox " + i + ": " + rect);
                        if (rect.contains(x, y)) {
                            System.out.println("Hitbox " + i + " clicked");
                            if (i < results.size()) {
                                System.out.println("Adding to cart: " + results.get(i).name);
                                addToCart(results.get(i), 1);
                                repaint();
                                return;
                            }
                            break;
                        }
                    }
                }
            });
            
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    int x = e.getX(), y = e.getY();
                    int oldHovered = hoveredIndex;
                    hoveredIndex = -1;
                    
                    for (int i = 0; i < hitBoxes.size(); i++) {
                        if (hitBoxes.get(i).contains(x, y)) {
                            hoveredIndex = i;
                            break;
                        }
                    }
                    
                    if (oldHovered != hoveredIndex) {
                        repaint();
                    }
                }
            });
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            hitBoxes.clear();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            
            // Panel background
            GradientPaint panelGradient = new GradientPaint(
                0, 0, new Color(255, 255, 255, 250),
                0, h, new Color(248, 250, 252, 230)
            );
            g2.setPaint(panelGradient);
            g2.fillRoundRect(0, 0, w, h, 16, 16);
            
            // Panel border
            g2.setColor(new Color(226, 232, 240, 150));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0, 0, w-1, h-1, 16, 16);
            
            // Header
            g2.setColor(new Color(241, 245, 249));
            g2.fillRoundRect(8, 8, w-16, 40, 12, 12);
            
            g2.setFont(new Font("SansSerif", Font.BOLD, 16));
            g2.setColor(new Color(71, 85, 105));
            g2.drawString("🛍️ Available Products", 20, 32);
            
            // Product list
            int y = 60;
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            
            for (int i = 0; i < results.size() && y < h - 40; i++) {
                Product p = results.get(i);
                Rectangle itemRect = new Rectangle(12, y - 16, w - 24, 32);
                hitBoxes.add(itemRect);
                
                // Item background
                if (i == hoveredIndex) {
                    GradientPaint hoverGradient = new GradientPaint(
                        0, y - 16, new Color(34, 197, 94, 50),
                        0, y + 16, new Color(34, 197, 94, 20)
                    );
                    g2.setPaint(hoverGradient);
                    g2.fillRoundRect(12, y - 16, w - 24, 32, 8, 8);
                    g2.setColor(new Color(34, 197, 94, 100));
                    g2.drawRoundRect(12, y - 16, w - 24, 32, 8, 8);
                } else if (i % 2 == 0) {
                    g2.setColor(new Color(248, 250, 252, 100));
                    g2.fillRoundRect(12, y - 16, w - 24, 32, 8, 8);
                }
                
                // Stock status indicator
                Color stockColor = p.stockQty > 10 ? new Color(34, 197, 94) : 
                                  p.stockQty > 0 ? new Color(245, 158, 11) : 
                                  new Color(239, 68, 68);
                g2.setColor(stockColor);
                g2.fillOval(w - 40, y - 8, 12, 12);
                
                // Product info
                g2.setColor(new Color(30, 41, 59));
                String productName = truncateText(p.name, 25);
                g2.drawString(productName, 20, y - 2);
                
                g2.setColor(new Color(107, 114, 128));
                String details = p.sku + " • " + Formatter.money(p.sellingPrice) + " • Stock: " + p.stockQty;
                g2.drawString(details, 20, y + 12);
                
                y += 36;
            }
        }
        
        private String truncateText(String text, int maxLength) {
            if (text.length() <= maxLength) return text;
            return text.substring(0, maxLength - 3) + "...";
        }
    }

    // Enhanced Cart Panel
    private class EnhancedCartPanel extends Panel implements CartUpdateListener {
        private final List<Rectangle> hitBoxes = new ArrayList<>();
        
        @Override
        public void onCartUpdated(List<SaleItem> updatedCart) {
            // Update the panel when cart changes
            repaint();
        }
        
        public EnhancedCartPanel() {
            addCartUpdateListener(this);
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int x = e.getX(), y = e.getY();
                    for (int i = 0; i < hitBoxes.size(); i++) {
                        if (hitBoxes.get(i).contains(x, y)) {
                            selectedCartIndex = i;
                            repaint();
                            return;
                        }
                    }
                }
            });
        }
        
        @Override
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            int w = getWidth(), h = getHeight();
            hitBoxes.clear();
            
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            
            // Panel background
            GradientPaint panelGradient = new GradientPaint(
                0, 0, new Color(255, 255, 255, 250),
                0, h, new Color(248, 250, 252, 230)
            );
            g2.setPaint(panelGradient);
            g2.fillRoundRect(0, 0, w, h, 16, 16);
            
            // Panel border
            g2.setColor(new Color(226, 232, 240, 150));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0, 0, w-1, h-1, 16, 16);
            
            // Header
            g2.setColor(new Color(241, 245, 249));
            g2.fillRoundRect(8, 8, w-16, 40, 12, 12);
            
            g2.setFont(new Font("SansSerif", Font.BOLD, 16));
            g2.setColor(new Color(71, 85, 105));
            g2.drawString("🛒 Shopping Cart (" + cart.size() + " items)", 20, 32);
            
            // Cart items
            int y = 70;
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            
            for (int idx = 0; idx < cart.size() && y < h - 120; idx++) {
                SaleItem item = cart.get(idx);
                Rectangle itemRect = new Rectangle(12, y - 16, w - 24, 32);
                hitBoxes.add(itemRect);
                
                // Item background
                if (idx == selectedCartIndex) {
                    GradientPaint selectedGradient = new GradientPaint(
                        0, y - 16, new Color(59, 130, 246, 80),
                        0, y + 16, new Color(59, 130, 246, 40)
                    );
                    g2.setPaint(selectedGradient);
                    g2.fillRoundRect(12, y - 16, w - 24, 32, 8, 8);
                    g2.setColor(new Color(59, 130, 246, 150));
                    g2.setStroke(new BasicStroke(2f));
                    g2.drawRoundRect(12, y - 16, w - 24, 32, 8, 8);
                } else if (idx % 2 == 0) {
                    g2.setColor(new Color(248, 250, 252, 100));
                    g2.fillRoundRect(12, y - 16, w - 24, 32, 8, 8);
                }
                
                // Item details
                g2.setColor(new Color(30, 41, 59));
                String itemName = truncateText(item.name, 20);
                g2.drawString((idx + 1) + ". " + itemName, 20, y - 2);
                
                g2.setColor(new Color(107, 114, 128));
                String details = "Qty: " + item.qty + " × " + Formatter.money(item.price) + " = " + Formatter.money(item.lineTotal);
                g2.drawString(details, 20, y + 12);
                
                y += 36;
            }
            
            // Summary section
            y = h - 100;
            g2.setColor(new Color(241, 245, 249));
            g2.fillRoundRect(8, y, w-16, 80, 12, 12);
            
            g2.setFont(new Font("SansSerif", Font.BOLD, 14));
            g2.setColor(new Color(71, 85, 105));
            
            y += 20;
            g2.drawString("💰 Subtotal: " + Formatter.money(getSubtotal()), 20, y);
            y += 18;
            g2.drawString("🎫 Discount: " + Formatter.money(discount), 20, y);
            y += 18;
            g2.setColor(new Color(34, 197, 94));
            g2.drawString("💵 Total: " + Formatter.money(getTotal()), 20, y);
            
            if ("💵 Cash".equals(paymentChoice.getSelectedItem())) {
                y += 18;
                g2.setColor(new Color(107, 114, 128));
                String changeText = "Change: " + Formatter.money(getChange());
                g2.drawString(changeText, 20, y);
            }
        }
        
        private String truncateText(String text, int maxLength) {
            if (text.length() <= maxLength) return text;
            return text.substring(0, maxLength - 3) + "...";
        }
    }

    private void setupEventHandlers() {
        search.addTextListener(e -> doSearch());
        barcode.addActionListener(e -> addBySKU());
        discountField.addTextListener(e -> parseDiscount());
        paymentChoice.addItemListener(e -> repaint());
        
        // Add enter key support for barcode field
        barcode.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    addBySKU();
                }
            }
        });
    }

    private void doSearch() {
        try {
            String q = search.getText();
            if (q != null && q.startsWith("🔍")) {
                q = q.substring(2).trim();
            }
            results = (q == null || q.isEmpty()) ? ProductDAO.listAll() : ProductDAO.search(q);
            repaint();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void addBySKU() {
        String sku = barcode.getText().trim();
        if (sku.startsWith("📱")) {
            sku = sku.substring(2).trim();
        }
        if (sku.isEmpty()) return;
        
        try {
            Product p = ProductDAO.findBySKU(sku);
            if (p != null) {
                addToCart(p, 1);
                barcode.setText("");
                
                // Visual feedback
                barcode.setBackground(new Color(34, 197, 94, 50));
                Timer resetTimer = new Timer(500, e -> {
                    barcode.setBackground(Color.WHITE);
                    ((Timer)e.getSource()).stop();
                });
                resetTimer.start();
            } else {
                showEnhancedError("Product not found: " + sku);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showEnhancedError("Error adding product: " + ex.getMessage());
        }
    }

    private void addToCart(Product p, int qty) {
        // Check if product already in cart
        for (SaleItem si : cart) {
            if (si.productId == p.id) {
                si.qty += qty;
                si.lineTotal = si.qty * si.price;
                notifyCartUpdated();
                return;
            }
        }
        
        // Add new item to cart
        SaleItem si = new SaleItem();
        si.productId = p.id;
        si.sku = p.sku;
        si.name = p.name;
        si.qty = qty;
        si.price = p.sellingPrice;
        si.lineTotal = si.qty * si.price;
        cart.add(si);
        notifyCartUpdated();
    }

    private double getSubtotal() {
        double subtotal = 0;
        for (SaleItem item : cart) {
            subtotal += item.lineTotal;
        }
        return subtotal;
    }

    private double getTotal() {
        return Math.max(0, getSubtotal() - discount);
    }

    private void parseDiscount() {
        try {
            String discountText = discountField.getText().trim();
            discount = Math.max(0, Double.parseDouble(discountText));
        } catch (Exception ex) {
            discount = 0;
        }
        repaint();
    }

    private double getTendered() {
        try {
            String tenderedText = tenderedField.getText().trim();
            return Double.parseDouble(tenderedText);
        } catch (Exception ex) {
            return 0;
        }
    }

    private double getChange() {
        return Math.max(0, getTendered() - getTotal());
    }

    private void removeSelected() {
        if (selectedCartIndex >= 0 && selectedCartIndex < cart.size()) {
            cart.remove(selectedCartIndex);
            if (selectedCartIndex >= cart.size()) {
                selectedCartIndex = cart.size() - 1;
            }
            notifyCartUpdated();
        }
    }

    private void adjustSelected(int delta) {
        if (selectedCartIndex >= 0 && selectedCartIndex < cart.size()) {
            SaleItem item = cart.get(selectedCartIndex);
            item.qty += delta;
            if (item.qty <= 0) {
                cart.remove(selectedCartIndex);
                selectedCartIndex = -1;
            } else {
                item.lineTotal = item.qty * item.price;
            }
            notifyCartUpdated();
        }
    }

    private void setSelectedQty() {
        if (selectedCartIndex < 0 || selectedCartIndex >= cart.size()) return;
        
        // Create modern quantity dialog
        Dialog qtyDialog = new Dialog((Frame) getTopLevelAncestor(), "Set Quantity", true) {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Background gradient
                GradientPaint bg = new GradientPaint(
                    0, 0, new Color(255, 255, 255),
                    0, h, new Color(248, 250, 252)
                );
                g2.setPaint(bg);
                g2.fillRoundRect(0, 0, w, h, 16, 16);
                
                // Border
                g2.setColor(new Color(59, 130, 246, 150));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w-2, h-2, 16, 16);
            }
        };
        
        qtyDialog.setLayout(new BorderLayout());
        qtyDialog.setSize(300, 150);
        qtyDialog.setLocationRelativeTo(this);
        
        Panel contentPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 16, 20));
        contentPanel.setBackground(new Color(0, 0, 0, 0));
        
        Label qtyLabel = new Label("⚙️ Enter Quantity:");
        qtyLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        
        EnhancedTextField qtyField = new EnhancedTextField(
            String.valueOf(cart.get(selectedCartIndex).qty), 8
        );
        
        ModernButton okBtn = new ModernButton("✓ OK", new Color(34, 197, 94));
        ModernButton cancelBtn = new ModernButton("✗ Cancel", new Color(107, 114, 128));
        
        contentPanel.add(qtyLabel);
        contentPanel.add(qtyField);
        
        Panel buttonPanel = new Panel(new FlowLayout());
        buttonPanel.setBackground(new Color(0, 0, 0, 0));
        buttonPanel.add(okBtn);
        buttonPanel.add(cancelBtn);
        
        qtyDialog.add(contentPanel, BorderLayout.CENTER);
        qtyDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        okBtn.addActionListener(e -> {
            try {
                int qty = Integer.parseInt(qtyField.getText().trim());
                if (qty > 0) {
                    SaleItem item = cart.get(selectedCartIndex);
                    item.qty = qty;
                    item.lineTotal = item.qty * item.price;
                    notifyCartUpdated();
                }
                qtyDialog.dispose();
            } catch (Exception ex) {
                qtyDialog.dispose();
            }
        });
        
        cancelBtn.addActionListener(e -> qtyDialog.dispose());
        
        // Enter key support
        qtyField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    try {
                        int qty = Integer.parseInt(qtyField.getText().trim());
                        if (qty > 0) {
                            SaleItem item = cart.get(selectedCartIndex);
                            item.qty = qty;
                            item.lineTotal = item.qty * item.price;
                            notifyCartUpdated();
                        }
                        qtyDialog.dispose();
                    } catch (Exception ex) {
                        qtyDialog.dispose();
                    }
                }
            }
        });
        
        qtyDialog.setVisible(true);
    }

    private void doCheckout() {
        if (cart.isEmpty() || processingCheckout) return;
        
        try {
            processingCheckout = true;
            
            // Validate stock
            for (SaleItem item : cart) {
                Product p = ProductDAO.findBySKU(item.sku);
                if (p == null) {
                    showEnhancedError("Product not found: " + item.sku);
                    return;
                }
                if (item.qty > p.stockQty) {
                    showEnhancedError("Insufficient stock for " + p.name + 
                        "\nRequested: " + item.qty + ", Available: " + p.stockQty);
                    return;
                }
            }
            
            parseDiscount();
            
            // Validate payment for cash transactions
            if ("💵 Cash".equals(paymentChoice.getSelectedItem())) {
                if (getTendered() + 1e-6 < getTotal()) {
                    showEnhancedError("Tendered amount is less than total\nTotal: " + 
                        Formatter.money(getTotal()) + "\nTendered: " + Formatter.money(getTendered()));
                    return;
                }
            }
            
            // Create and save sale
            Sale sale = new Sale();
            sale.customerName = "Walk-in Customer";
            sale.paymentMethod = paymentChoice.getSelectedItem().substring(2).trim(); // Remove emoji
            sale.subtotal = getSubtotal();
            sale.discount = discount;
            sale.total = getTotal();
            sale.items.addAll(cart);
            
            try {
                SaleDAO.createSale(sale);
                showSuccessDialog("Sale completed successfully!\nTotal: " + Formatter.money(getTotal()));
                
                cart.clear();
                selectedCartIndex = -1;
                discount = 0.0;
                discountField.setText("0.00");
                tenderedField.setText("0.00");
                notifyCartUpdated();
                
                if (onAfterCheckout != null) {
                    onAfterCheckout.run();
                }
                
            } catch (Exception daoErr) {
                showEnhancedError("Failed to save sale: " + daoErr.getMessage());
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
            showEnhancedError("Checkout failed: " + ex.getMessage());
        } finally {
            processingCheckout = false;
        }
    }

    private void showEnhancedError(String message) {
        Dialog errorDialog = new Dialog((Frame) getTopLevelAncestor(), "Error", true) {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Background gradient
                GradientPaint bg = new GradientPaint(
                    0, 0, new Color(254, 242, 242),
                    0, h, new Color(255, 255, 255)
                );
                g2.setPaint(bg);
                g2.fillRoundRect(0, 0, w, h, 16, 16);
                
                // Border
                g2.setColor(new Color(239, 68, 68, 150));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w-2, h-2, 16, 16);
            }
        };
        
        errorDialog.setLayout(new BorderLayout());
        errorDialog.setSize(400, 180);
        errorDialog.setLocationRelativeTo(this);
        
        Panel messagePanel = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                // Error icon
                g2.setColor(new Color(239, 68, 68));
                g2.setFont(new Font("SansSerif", Font.BOLD, 32));
                g2.drawString("⚠️", 20, 45);
                
                // Message text
                g2.setColor(new Color(127, 29, 29));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
                
                String[] lines = message.split("\n");
                int y = 30;
                for (String line : lines) {
                    g2.drawString(line, 70, y);
                    y += 20;
                }
            }
        };
        messagePanel.setPreferredSize(new Dimension(0, 100));
        
        Panel buttonPanel = new Panel(new FlowLayout());
        buttonPanel.setBackground(new Color(0, 0, 0, 0));
        ModernButton okButton = new ModernButton("✓ OK", new Color(239, 68, 68));
        okButton.addActionListener(e -> errorDialog.dispose());
        buttonPanel.add(okButton);
        
        errorDialog.add(messagePanel, BorderLayout.CENTER);
        errorDialog.add(buttonPanel, BorderLayout.SOUTH);
        errorDialog.setVisible(true);
    }

    // Helper method to truncate text with ellipsis if needed
    private String truncateText(String text, int maxLength) {
        if (text.length() <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength - 3) + "...";
    }
    
    private void showSuccessDialog(String message) {
        // Store the sale details for receipt printing
        final double total = getTotal();
        final double tendered = getTendered();
        final double change = getChange();
        final String paymentMethod = paymentChoice.getSelectedItem().toString();
        final List<SaleItem> receiptItems = new ArrayList<>(cart);
        
        Dialog successDialog = new Dialog((Frame) getTopLevelAncestor(), "Success", true) {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                int w = getWidth(), h = getHeight();
                
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Background gradient
                GradientPaint bg = new GradientPaint(
                    0, 0, new Color(236, 253, 245),
                    0, h, new Color(255, 255, 255)
                );
                g2.setPaint(bg);
                g2.fillRoundRect(0, 0, w, h, 16, 16);
                
                // Border
                g2.setColor(new Color(34, 197, 94, 150));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w-2, h-2, 16, 16);
            }
        };
        
        successDialog.setLayout(new BorderLayout());
        successDialog.setSize(350, 200);
        successDialog.setLocationRelativeTo(this);
        
        Panel messagePanel = new Panel() {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                // Success icon
                g2.setColor(new Color(34, 197, 94));
                g2.setFont(new Font("SansSerif", Font.BOLD, 32));
                g2.drawString("✅", 20, 45);
                
                // Message text
                g2.setColor(new Color(21, 128, 61));
                g2.setFont(new Font("SansSerif", Font.BOLD, 14));
                
                String[] lines = message.split("\n");
                int y = 30;
                for (String line : lines) {
                    g2.drawString(line, 70, y);
                    y += 20;
                }
            }
        };
        messagePanel.setPreferredSize(new Dimension(0, 100));
        
        // Create buttons panel with insets for padding
        Panel buttonPanel = new Panel(new GridLayout(1, 2, 10, 0)) {
            @Override
            public Insets getInsets() {
                return new Insets(0, 20, 10, 20);
            }
        };
        buttonPanel.setBackground(new Color(0, 0, 0, 0));
        
        // Print Receipt button
        ModernButton printButton = new ModernButton("🖨️ Print Receipt", new Color(59, 130, 246));
        printButton.addActionListener(e -> {
            printReceipt(receiptItems, total, tendered, change, paymentMethod);
            successDialog.dispose();
        });
        
        // OK button
        ModernButton okButton = new ModernButton("✓ Done", new Color(34, 197, 94));
        okButton.addActionListener(e -> successDialog.dispose());
        
        buttonPanel.add(printButton);
        buttonPanel.add(okButton);
        
        successDialog.add(messagePanel, BorderLayout.CENTER);
        successDialog.add(buttonPanel, BorderLayout.SOUTH);
        successDialog.setVisible(true);
    }
    
    private void printReceipt(List<SaleItem> items, double total, double tendered, double change, String paymentMethod) {
        try {
            // Create a frame for the print dialog
            Frame frame = new Frame("Print Receipt");
            frame.setSize(300, 400);
            
            // Create a printable component for the receipt
            Printable printable = (graphics, pageFormat, pageIndex) -> {
                if (pageIndex > 0) {
                    return Printable.NO_SUCH_PAGE;
                }
                
                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                
                // Set up fonts
                Font headerFont = new Font("Monospaced", Font.BOLD, 14);
                Font itemFont = new Font("Monospaced", Font.PLAIN, 10);
                Font totalFont = new Font("Monospaced", Font.BOLD, 12);
                
                // Draw header
                g2d.setFont(headerFont);
                g2d.drawString("BIZFLOW RETAIL", 40, 15);
                g2d.drawString("----------------------------", 5, 30);
                
                // Draw date and time
                g2d.setFont(itemFont);
                g2d.drawString(new java.util.Date().toString(), 5, 45);
                g2d.drawString("----------------------------", 5, 55);
                
                // Draw items
                int y = 70;
                for (SaleItem item : items) {
                    String line = String.format("%-20s %2d x %6.2f", 
                        truncateText(item.name, 15), 
                        item.qty, 
                        item.price);
                    g2d.drawString(line, 5, y);
                    g2d.drawString(String.format("%8.2f", item.lineTotal), 180, y);
                    y += 15;
                }
                
                // Draw totals
                g2d.drawString("----------------------------", 5, y + 10);
                g2d.setFont(totalFont);
                g2d.drawString(String.format("TOTAL: %24.2f", total), 5, y + 30);
                
                if (paymentMethod.startsWith("💵")) {
                    g2d.drawString(String.format("TENDERED: %19.2f", tendered), 5, y + 50);
                    g2d.drawString(String.format("CHANGE: %21.2f", change), 5, y + 70);
                }
                
                g2d.drawString("----------------------------", 5, y + 90);
                g2d.setFont(itemFont);
                g2d.drawString("Thank you for shopping with us!", 30, y + 110);
                g2d.drawString("BizFlow Retail POS", 60, y + 125);
                
                return Printable.PAGE_EXISTS;
            };
            
            // Show print dialog
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setPrintable(printable);
            
            if (job.printDialog()) {
                try {
                    job.print();
                } catch (PrinterException ex) {
                    showEnhancedError("Failed to print receipt: " + ex.getMessage());
                }
            }
            
            frame.dispose();
        } catch (Exception ex) {
            showEnhancedError("Error generating receipt: " + ex.getMessage());
        }
    }

    private Frame getTopLevelAncestor() {
        Container parent = getParent();
        while (parent != null && !(parent instanceof Frame)) {
            parent = parent.getParent();
        }
        return (Frame) parent;
    }

    @Override
    public void removeNotify() {
        if (animationTimer != null) {
            animationTimer.stop();
        }
        super.removeNotify();
    }
}