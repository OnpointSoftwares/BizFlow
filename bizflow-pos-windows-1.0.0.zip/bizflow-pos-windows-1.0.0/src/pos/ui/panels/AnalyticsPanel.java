package pos.ui.panels;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import java.text.SimpleDateFormat;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import pos.dao.SaleDAO;
import pos.models.Sale;
import pos.models.SaleItem;
import pos.ui.components.ModernButton;
import pos.ui.theme.Theme;

import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class AnalyticsPanel extends JPanel {
    private final JComboBox<String> timeRangeCombo;
    private final JButton refreshButton;
    private final JPanel chartPanel;
    private final JTabbedPane tabbedPane;
    private LocalDate startDate;
    private LocalDate endDate;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
    private final NumberFormat currencyFormat;

    public AnalyticsPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        
        // Initialize currency format for KES
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("sw", "KE"));
        currencyFormat.setCurrency(Currency.getInstance("KES"));
        
        // Create toolbar with date range selector
        JPanel toolbar = new JPanel(new BorderLayout(10, 0));
        toolbar.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        toolbar.setBackground(Theme.BACKGROUND);
        
        // Date range selector
        JPanel dateRangePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        dateRangePanel.setOpaque(false);
        
        String[] timeRanges = {"Last 7 Days", "This Month", "Last Month", "This Year", "Custom Range"};
        timeRangeCombo = new JComboBox<>(timeRanges);
        timeRangeCombo.setSelectedItem("This Month");
        timeRangeCombo.addActionListener(e -> updateDateRange());
        
        dateRangePanel.add(new JLabel("Time Range:"));
        dateRangePanel.add(timeRangeCombo);
        
        // Refresh button
        refreshButton = new ModernButton("Refresh");
        refreshButton.addActionListener(e -> refreshCharts());
        
        toolbar.add(dateRangePanel, BorderLayout.WEST);
        toolbar.add(refreshButton, BorderLayout.EAST);
        
        // Create tabbed pane for different charts
        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(Theme.BACKGROUND);
        tabbedPane.setForeground(Theme.TEXT_PRIMARY);
        
        // Create chart panel
        chartPanel = new JPanel(new BorderLayout());
        chartPanel.setBackground(Theme.BACKGROUND);
        
        // Set initial date range first
        updateDateRange();
        
        // Add tabs after date range is set
        tabbedPane.addTab("Sales Trend", createSalesTrendPanel());
        tabbedPane.addTab("Top Products", createTopProductsPanel());
        tabbedPane.addTab("Categories", createCategoriesPanel());
        
        // Add components to main panel
        add(toolbar, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);
    }
    
    private void updateDateRange() {
        String range = (String) timeRangeCombo.getSelectedItem();
        LocalDate today = LocalDate.now();
        
        switch (range) {
            case "Last 7 Days":
                startDate = today.minusDays(6);
                endDate = today;
                break;
            case "This Month":
                startDate = today.withDayOfMonth(1);
                endDate = today;
                break;
            case "Last Month":
                startDate = today.minusMonths(1).withDayOfMonth(1);
                endDate = today.withDayOfMonth(1).minusDays(1);
                break;
            case "This Year":
                startDate = today.withDayOfYear(1);
                endDate = today;
                break;
            case "Custom Range":
                // TODO: Implement custom date range picker
                JOptionPane.showMessageDialog(this, "Custom date range selection will be implemented here");
                timeRangeCombo.setSelectedItem("This Month");
                return;
        }
        
        refreshCharts();
    }
    
    private void refreshCharts() {
        // Don't update charts if the tabbed pane doesn't have any tabs yet
        if (tabbedPane.getTabCount() == 0) {
            return;
        }
        
        try {
            // Update sales trend chart if the tab exists
            if (tabbedPane.getTabCount() > 0) {
                updateSalesTrendChart();
            }
            
            // Update top products chart if the tab exists
            if (tabbedPane.getTabCount() > 1) {
                updateTopProductsChart();
            }
            
            // Update categories chart if the tab exists
            if (tabbedPane.getTabCount() > 2) {
                updateCategoriesChart();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error refreshing charts: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // Update tab titles to show last update time
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        String timeString = timeFormat.format(new Date());
        
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            tabbedPane.setTitleAt(i, tabbedPane.getTitleAt(i).replaceAll(" \\(.*\\)", "") + 
                                    " (Updated: " + timeString + ")");
        }
    }
    
    private JPanel createSalesTrendPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Theme.BACKGROUND);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add chart to panel
        JFreeChart chart = createSalesTrendChart();
        ChartPanel chartPanel = new ChartPanel(chart, true);
        chartPanel.setPreferredSize(new Dimension(800, 400));
        chartPanel.setBackground(Theme.BACKGROUND);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);
        panel.add(chartPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createTopProductsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Theme.BACKGROUND);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add chart to panel
        JFreeChart chart = createTopProductsChart();
        ChartPanel chartPanel = new ChartPanel(chart, true);
        chartPanel.setPreferredSize(new Dimension(800, 400));
        chartPanel.setBackground(Theme.BACKGROUND);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);
        panel.add(chartPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createCategoriesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Theme.BACKGROUND);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add chart to panel
        JFreeChart chart = createCategoriesChart();
        ChartPanel chartPanel = new ChartPanel(chart, true);
        chartPanel.setPreferredSize(new Dimension(800, 400));
        chartPanel.setBackground(Theme.BACKGROUND);
        chartPanel.setDomainZoomable(true);
        chartPanel.setRangeZoomable(true);
        panel.add(chartPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JFreeChart createSalesTrendChart() {
        System.out.println("\n=== Starting createSalesTrendChart() ===");
        System.out.println("Date range: " + startDate + " to " + endDate);
        
        // Create dataset with sales data
        TimeSeriesCollection dataset = new TimeSeriesCollection();
        TimeSeries series = new TimeSeries("Daily Sales");
        
        // Initialize with default values in case of no data
        if (startDate == null || endDate == null) {
            startDate = LocalDate.now().minusDays(7);
            endDate = LocalDate.now();
            System.out.println("Using default date range: " + startDate + " to " + endDate);
        }
        
        try {
            // Get all sales (in a real app, we would filter by date range in the DAO)
            System.out.println("Fetching all sales from database...");
            List<Sale> allSales = SaleDAO.listAll();
            System.out.println("Total sales found: " + (allSales != null ? allSales.size() : "null"));
            
            if (allSales != null && !allSales.isEmpty()) {
                // Filter sales by date range and group by date
                Map<LocalDate, Double> dailySales = new TreeMap<>();
                
                // Initialize all dates in range with 0 sales
                System.out.println("Initializing date range with zero values...");
                LocalDate current = startDate;
                while (!current.isAfter(endDate)) {
                    dailySales.put(current, 0.0);
                    System.out.println("  - Initialized date: " + current);
                    current = current.plusDays(1);
                }
                
                // Process each sale
                System.out.println("\nProcessing sales data...");
                for (int i = 0; i < allSales.size(); i++) {
                    Sale sale = allSales.get(i);
                    System.out.println("\nProcessing sale #" + (i + 1) + ":");
                    
                    if (sale == null) {
                        System.out.println("  - Sale is null, skipping...");
                        continue;
                    }
                    
                    // Since there's no date field in Sale, we'll use the current date
                    // In a real app, you might want to add a createdAt field to the Sale class
                    LocalDate saleDate = LocalDate.now();
                    System.out.println("  - Sale date: " + saleDate);
                    
                    // Only include sales within the selected date range
                    if (!saleDate.isBefore(startDate) && !saleDate.isAfter(endDate)) {
                        System.out.println("  - Sale is within date range");
                        System.out.println("  - Sale total: " + sale.total);
                        dailySales.merge(saleDate, sale.total, Double::sum);
                        System.out.println("  - Updated daily sales for " + saleDate + ": " + dailySales.get(saleDate));
                    } else {
                        System.out.println("  - Sale is outside date range, skipping...");
                    }
                }
                
                // Add data points to the series
                System.out.println("\nAdding data points to chart...");
                for (Map.Entry<LocalDate, Double> entry : dailySales.entrySet()) {
                    LocalDate date = entry.getKey();
                    double value = entry.getValue();
                    System.out.println(String.format("  - Date: %s, Value: %.2f", date, value));
                    series.add(new Day(date.getDayOfMonth(), date.getMonthValue(), date.getYear()), value);
                }
            } else {
                // If no sales, add a single point at 0
                series.add(new Day(startDate.getDayOfMonth(), startDate.getMonthValue(), startDate.getYear()), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Add a single point to show there was an error
            series.add(new Day(startDate.getDayOfMonth(), startDate.getMonthValue(), startDate.getYear()), 0);
            throw new RuntimeException("Error creating sales trend chart", e);
        }
        
        dataset.addSeries(series);
        
        // Create chart - using TimeSeriesChart for time-based data
        JFreeChart chart = ChartFactory.createTimeSeriesChart(
            "Sales Trend",
            "Date",
            "Amount (KES)",
            dataset,
            true,
            true,
            false
        );
        
        // Customize chart appearance
        chart.setBackgroundPaint(Theme.BACKGROUND);
        chart.getTitle().setPaint(Theme.TEXT_PRIMARY);
        chart.getLegend().setItemPaint(Theme.TEXT_PRIMARY);
        
        // Customize plot
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setBackgroundPaint(Theme.BACKGROUND);
        plot.setRangeGridlinePaint(Theme.DIVIDER);
        plot.setDomainGridlinePaint(Theme.DIVIDER);
        
        // Customize renderer
        XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
        renderer.setDefaultShapesVisible(true);
        renderer.setSeriesPaint(0, Theme.PRIMARY_500);
        renderer.setSeriesStroke(0, new BasicStroke(2.0f));
        
        // Customize axes
        DateAxis dateAxis = (DateAxis) plot.getDomainAxis();
        dateAxis.setLabelPaint(Theme.TEXT_SECONDARY);
        dateAxis.setTickLabelPaint(Theme.TEXT_SECONDARY);
        dateAxis.setDateFormatOverride(new SimpleDateFormat("MMM dd"));
        
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setLabelPaint(Theme.TEXT_SECONDARY);
        rangeAxis.setTickLabelPaint(Theme.TEXT_SECONDARY);
        rangeAxis.setNumberFormatOverride(currencyFormat);
        
        return chart;
    }
    
    private JFreeChart createTopProductsChart() {
        System.out.println("=== Starting createTopProductsChart() ===");
        System.out.println("Date range: " + startDate + " to " + endDate);
        
        // Get top selling products
        Map<String, Double> productSales = new HashMap<>();
        
        try {
            System.out.println("Fetching all sales from database...");
            List<Sale> sales = SaleDAO.listAll();
            
            System.out.println("Total sales found: " + (sales != null ? sales.size() : "null"));
            
            if (sales == null || sales.isEmpty()) {
                System.out.println("No sales data found in the database");
            } else {
                // Aggregate sales by product, filtered by date range
                for (int i = 0; i < sales.size(); i++) {
                    Sale sale = sales.get(i);
                    System.out.println("\nProcessing sale #" + (i + 1) + ":");
                    
                    if (sale == null) {
                        System.out.println("  - Sale is null, skipping...");
                        continue;
                    }
                    
                    if (sale.items == null) {
                        System.out.println("  - Sale has no items, skipping...");
                        continue;
                    }
                    
                    // Since there's no date field in Sale, we'll use the current date
                    LocalDate saleDate = LocalDate.now();
                    System.out.println("  - Sale date: " + saleDate);
                    
                    // Only include sales within the selected date range
                    if (!saleDate.isBefore(startDate) && !saleDate.isAfter(endDate)) {
                        System.out.println("  - Sale is within date range");
                        System.out.println("  - Number of items: " + sale.items.size());
                        
                        for (int j = 0; j < sale.items.size(); j++) {
                            SaleItem item = sale.items.get(j);
                            if (item == null) {
                                System.out.println("    - Item #" + (j + 1) + " is null, skipping...");
                                continue;
                            }
                            
                            String productName = item.name != null ? item.name : "[No Name]";
                            double total = item.price * item.qty;
                            
                            System.out.println(String.format("    - Item #%d: %s (Qty: %d, Price: %.2f, Total: %.2f)", 
                                j + 1, productName, item.qty, item.price, total));
                            
                            // Update product sales total
                            productSales.merge(productName, total, Double::sum);
                        }
                    } else {
                        System.out.println("  - Sale is outside date range, skipping...");
                    }
                }
            }
            
            // Sort products by sales amount (descending)
            List<Map.Entry<String, Double>> sortedProducts = new ArrayList<>(productSales.entrySet());
            sortedProducts.sort((a, b) -> b.getValue().compareTo(a.getValue()));
            
            // Take top 10 products
            if (sortedProducts.size() > 10) {
                sortedProducts = sortedProducts.subList(0, 10);
            }
            
            // Create dataset
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (Map.Entry<String, Double> entry : sortedProducts) {
                dataset.addValue(entry.getValue(), "Sales", entry.getKey());
            }
            
            // Create chart
            JFreeChart chart = ChartFactory.createBarChart(
                "Top Selling Products",
                "Product",
                "Revenue (KES)",
                dataset,
                PlotOrientation.VERTICAL,
                false,
                true,
                false
            );
            
            // Customize chart appearance
            chart.setBackgroundPaint(Theme.BACKGROUND);
            chart.getTitle().setPaint(Theme.TEXT_PRIMARY);
            
            // Customize plot
            CategoryPlot plot = chart.getCategoryPlot();
            plot.setBackgroundPaint(Theme.BACKGROUND);
            plot.setRangeGridlinePaint(Theme.DIVIDER);
            
            // Customize renderer
            BarRenderer renderer = (BarRenderer) plot.getRenderer();
            renderer.setSeriesPaint(0, Theme.PRIMARY_500);
            
            // Set tooltip generator
            renderer.setDefaultToolTipGenerator(
                new StandardCategoryToolTipGenerator("{1}: {2}", currencyFormat));
            
            // Customize axes
            CategoryAxis domainAxis = plot.getDomainAxis();
            domainAxis.setLabelPaint(Theme.TEXT_SECONDARY);
            domainAxis.setTickLabelPaint(Theme.TEXT_SECONDARY);
            domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
            
            NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setLabelPaint(Theme.TEXT_SECONDARY);
            rangeAxis.setTickLabelPaint(Theme.TEXT_SECONDARY);
            rangeAxis.setNumberFormatOverride(currencyFormat);
            
            return chart;
            
        } catch (Exception e) {
            e.printStackTrace();
            // Return an empty chart in case of error
            return ChartFactory.createBarChart(
                "Error Loading Data",
                "",
                "",
                new DefaultCategoryDataset(),
                PlotOrientation.VERTICAL,
                false,
                true,
                false
            );
        }
    }
    
    private JFreeChart createCategoriesChart() {
        // Get sales data
        Map<String, Double> categorySales = new HashMap<>();
        
        try {
            // Get all sales (since we don't have date filtering yet)
            List<Sale> sales = SaleDAO.listAll();
            System.out.println("Total sales for categories: " + sales.size());
            
            // Aggregate sales by category
            for (Sale sale : sales) {
                if (sale != null && sale.items != null) {
                    for (SaleItem item : sale.items) {
                        if (item != null) {
                            // Since SaleItem doesn't have a category, we'll use a default category
                            String category = "All Products";
                            double total = item.price * item.qty;
                            
                            System.out.println("Category: " + category + ", Product: " + item.name + ", Total: " + total);
                            
                            if (categorySales.containsKey(category)) {
                                categorySales.put(category, categorySales.get(category) + total);
                            } else {
                                categorySales.put(category, total);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Add a sample category to show there was an error
            categorySales.put("Error loading data", 0.0);
        }
        
        // Create dataset
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Double> entry : categorySales.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }
        
        // Create chart
        JFreeChart chart = ChartFactory.createPieChart(
            "Sales by Category",
            dataset,
            true,
            true,
            false
        );
        
        // Customize chart appearance
        chart.setBackgroundPaint(Theme.BACKGROUND);
        chart.getTitle().setPaint(Theme.TEXT_PRIMARY);
        chart.getLegend().setItemPaint(Theme.TEXT_PRIMARY);
        
        // Customize plot
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setBackgroundPaint(Theme.BACKGROUND);
        plot.setLabelBackgroundPaint(Theme.BACKGROUND);
        plot.setLabelPaint(Theme.TEXT_PRIMARY);
        
        // Set colors for categories
        Color[] colors = {
            Theme.PRIMARY_500, Theme.PRIMARY_400, Theme.PRIMARY_300,
            Theme.PRIMARY_600, Theme.PRIMARY_200, Theme.PRIMARY_700,
            Theme.PRIMARY_800, Theme.PRIMARY_100, Theme.PRIMARY_900
        };
        
        int i = 0;
        for (Object key : dataset.getKeys()) {
            if (key instanceof Comparable) {
                plot.setSectionPaint((Comparable<?>) key, colors[i % colors.length]);
                i++;
            }
        }
        
        return chart;
    }
    
    private void updateSalesTrendChart() {
        try {
            if (tabbedPane.getTabCount() > 0) {
                JFreeChart chart = createSalesTrendChart();
                if (tabbedPane.getComponentAt(0) != null) {
                    JPanel tabPanel = (JPanel) tabbedPane.getComponentAt(0);
                    if (tabPanel.getComponentCount() > 0 && tabPanel.getComponent(0) instanceof ChartPanel) {
                        ChartPanel chartPanel = (ChartPanel) tabPanel.getComponent(0);
                        chartPanel.setChart(chart);
                    } else {
                        // If no chart panel exists yet, create one
                        ChartPanel chartPanel = new ChartPanel(chart);
                        tabPanel.removeAll();
                        tabPanel.add(chartPanel, BorderLayout.CENTER);
                        tabPanel.revalidate();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating sales trend chart: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateTopProductsChart() {
        try {
            if (tabbedPane.getTabCount() > 1) {
                JFreeChart chart = createTopProductsChart();
                if (tabbedPane.getComponentAt(1) != null) {
                    JPanel tabPanel = (JPanel) tabbedPane.getComponentAt(1);
                    if (tabPanel.getComponentCount() > 0 && tabPanel.getComponent(0) instanceof ChartPanel) {
                        ChartPanel chartPanel = (ChartPanel) tabPanel.getComponent(0);
                        chartPanel.setChart(chart);
                    } else {
                        // If no chart panel exists yet, create one
                        ChartPanel chartPanel = new ChartPanel(chart);
                        tabPanel.removeAll();
                        tabPanel.add(chartPanel, BorderLayout.CENTER);
                        tabPanel.revalidate();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating top products chart: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateCategoriesChart() {
        try {
            if (tabbedPane.getTabCount() > 2) {
                JFreeChart chart = createCategoriesChart();
                if (tabbedPane.getComponentAt(2) != null) {
                    JPanel tabPanel = (JPanel) tabbedPane.getComponentAt(2);
                    if (tabPanel.getComponentCount() > 0 && tabPanel.getComponent(0) instanceof ChartPanel) {
                        ChartPanel chartPanel = (ChartPanel) tabPanel.getComponent(0);
                        chartPanel.setChart(chart);
                    } else {
                        // If no chart panel exists yet, create one
                        ChartPanel chartPanel = new ChartPanel(chart);
                        tabPanel.removeAll();
                        tabPanel.add(chartPanel, BorderLayout.CENTER);
                        tabPanel.revalidate();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating categories chart: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
