package pos.ui.dialogs;

import pos.dao.ProductDAO;
import pos.models.Product;
import pos.ui.components.RoundedButton;
import pos.ui.components.StyledTextField;
import pos.ui.theme.Theme;

import java.awt.*;
import java.awt.event.*;
import java.util.function.Consumer;
import javax.swing.JPanel;
import javax.swing.JLabel;

/**
 * A dialog for adding or editing a product in the inventory.
 */
public class ProductEditorDialog extends Dialog {
    private final Product product;
    private final Consumer<Boolean> onSave;
    private boolean saved = false;
    
    // Form fields
    private StyledTextField nameField;
    private StyledTextField skuField;
    private StyledTextField categoryField;
    private StyledTextField purchasePriceField;
    private StyledTextField sellingPriceField;
    private StyledTextField stockQtyField;
    private StyledTextField expiryDateField;
    
    public ProductEditorDialog(Frame owner, Product product, Consumer<Boolean> onSave) {
        super(owner, product == null ? "Add New Product" : "Edit Product", true);
        this.product = product != null ? product : new Product();
        this.onSave = onSave;
        
        setLayout(new BorderLayout());
        setSize(500, 500);
        setResizable(false);
        
        // Center the dialog on the parent window
        setLocationRelativeTo(owner);
        
        initUI();
        loadProductData();
        
        // Close on Escape key
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    dispose();
                }
            }
        });
        
        // Handle window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                onSave.accept(saved);
            }
        });
    }
    
    private void initUI() {
        // Header panel
        Panel header = new Panel(new BorderLayout());
        header.setBackground(Theme.SURFACE);
        header.setPreferredSize(new Dimension(getWidth(), 60));
        
        Label title = new Label(getTitle());
        title.setFont(Theme.H2);
        title.setForeground(Theme.TEXT_PRIMARY);
        
        Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        titlePanel.setBackground(Theme.SURFACE);
        titlePanel.add(title);
        
        header.add(titlePanel, BorderLayout.WEST);
        
        // Close button
        RoundedButton closeButton = new RoundedButton("✕");
        closeButton.setBackground(Theme.ERROR);
        closeButton.setForeground(Color.WHITE);
        closeButton.setPreferredSize(new Dimension(40, 40));
        closeButton.addActionListener(e -> {
            saved = false;
            dispose();
        });
        
        Panel closeButtonPanel = new Panel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        closeButtonPanel.setBackground(Theme.SURFACE);
        closeButtonPanel.add(closeButton);
        
        header.add(closeButtonPanel, BorderLayout.EAST);
        
        add(header, BorderLayout.NORTH);
        
        // Form panel with padding
        Panel formPanel = new Panel() {
            private final Insets insets = new Insets(20, 30, 20, 30);
            
            @Override
            public Insets getInsets() {
                return insets;
            }
            
            @Override
            public void paint(Graphics g) {
                super.paint(g);
                // Draw a border if needed
                g.setColor(Theme.BORDER);
                g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
            }
        };
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(Theme.BACKGROUND);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Name field
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new Label("Product Name:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        nameField = new StyledTextField(20);
        nameField.setPlaceholder("Enter product name");
        formPanel.add(nameField, gbc);
        
        // SKU field
        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new Label("SKU:"), gbc);
        
        gbc.gridx = 1;
        skuField = new StyledTextField(20);
        skuField.setPlaceholder("Enter SKU");
        formPanel.add(skuField, gbc);
        
        // Category field
        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new Label("Category:"), gbc);
        
        gbc.gridx = 1;
        categoryField = new StyledTextField(20);
        categoryField.setPlaceholder("Enter category");
        formPanel.add(categoryField, gbc);
        
        // Purchase Price field
        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new Label("Purchase Price:"), gbc);

        gbc.gridx = 1;
        JPanel purchasePricePanel = new JPanel(new BorderLayout(5, 0));
        purchasePriceField = new StyledTextField(15);
        purchasePriceField.setPlaceholder("0.00");
        purchasePricePanel.add(purchasePriceField, BorderLayout.CENTER);
        purchasePricePanel.add(new JLabel("KES"), BorderLayout.EAST);
        formPanel.add(purchasePricePanel, gbc);

        // Selling Price field
        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new Label("Selling Price:"), gbc);

        gbc.gridx = 1;
        JPanel sellingPricePanel = new JPanel(new BorderLayout(5, 0));
        sellingPriceField = new StyledTextField(15);
        sellingPriceField.setPlaceholder("0.00");
        sellingPricePanel.add(sellingPriceField, BorderLayout.CENTER);
        sellingPricePanel.add(new JLabel("KES"), BorderLayout.EAST);
        formPanel.add(sellingPricePanel, gbc);
        
        // Stock Quantity field
        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new Label("Stock Quantity:"), gbc);
        
        gbc.gridx = 1;
        stockQtyField = new StyledTextField(20);
        stockQtyField.setPlaceholder("0");
        formPanel.add(stockQtyField, gbc);
        
        // Expiry Date field
        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new Label("Expiry Date (YYYY-MM-DD):"), gbc);
        
        gbc.gridx = 1;
        expiryDateField = new StyledTextField(20);
        expiryDateField.setPlaceholder("Optional");
        formPanel.add(expiryDateField, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Theme.BACKGROUND);
        
        // Cancel button
        RoundedButton cancelButton = new RoundedButton("Cancel");
        cancelButton.setBackground(Theme.BORDER);
        cancelButton.setForeground(Theme.TEXT_PRIMARY);
        cancelButton.setPreferredSize(new Dimension(120, 40));
        cancelButton.addActionListener(e -> {
            saved = false;
            dispose();
        });
        
        // Save button
        RoundedButton saveButton = new RoundedButton("Save Product");
        saveButton.setBackground(Theme.PRIMARY);
        saveButton.setForeground(Color.WHITE);
        saveButton.setPreferredSize(new Dimension(160, 40));
        saveButton.addActionListener(e -> saveProduct());
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        
        formPanel.add(buttonPanel, gbc);
        
        add(formPanel, BorderLayout.CENTER);
        
        // Set initial focus
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                if (nameField.getText().isEmpty()) {
                    nameField.requestFocus();
                } else {
                    skuField.requestFocus();
                }
            }
        });
    }
    
    private void loadProductData() {
        if (product != null) {
            nameField.setText(product.name != null ? product.name : "");
            skuField.setText(product.sku != null ? product.sku : "");
            categoryField.setText(product.category != null ? product.category : "");
            purchasePriceField.setText(String.format("%.2f", product.purchasePrice));
            sellingPriceField.setText(String.format("%.2f", product.sellingPrice));
            stockQtyField.setText(String.valueOf(product.stockQty));
            expiryDateField.setText(product.expiryDate != null ? product.expiryDate : "");
        }
    }
    
    private void saveProduct() {
        try {
            // Validate required fields
            if (nameField.getText().trim().isEmpty()) {
                showError("Product name is required");
                nameField.requestFocus();
                return;
            }
            
            if (skuField.getText().trim().isEmpty()) {
                showError("SKU is required");
                skuField.requestFocus();
                return;
            }
            
            // Parse numeric fields
            double purchasePrice = 0;
            try {
                purchasePrice = Double.parseDouble(purchasePriceField.getText().trim());
                if (purchasePrice < 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                showError("Please enter a valid purchase price");
                purchasePriceField.requestFocus();
                return;
            }
            
            double sellingPrice = 0;
            try {
                sellingPrice = Double.parseDouble(sellingPriceField.getText().trim());
                if (sellingPrice < 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                showError("Please enter a valid selling price");
                sellingPriceField.requestFocus();
                return;
            }
            
            int stockQty = 0;
            try {
                stockQty = Integer.parseInt(stockQtyField.getText().trim());
                if (stockQty < 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                showError("Please enter a valid stock quantity");
                stockQtyField.requestFocus();
                return;
            }
            
            // Update product object
            product.name = nameField.getText().trim();
            product.sku = skuField.getText().trim();
            product.category = categoryField.getText().trim();
            product.purchasePrice = purchasePrice;
            product.sellingPrice = sellingPrice;
            product.stockQty = stockQty;
            
            String expiryDate = expiryDateField.getText().trim();
            product.expiryDate = expiryDate.isEmpty() ? null : expiryDate;
            
            // Save to database
            if (product.id == 0) {
                // New product
                ProductDAO.insert(product);
            } else {
                // Update existing product
                ProductDAO.update(product);
            }
            
            saved = true;
            dispose();
            
        } catch (Exception e) {
            e.printStackTrace();
            showError("An error occurred while saving the product: " + e.getMessage());
        }
    }
    
    private void showError(String message) {
        // In a real application, you might want to show this in a more user-friendly way
        System.err.println("Error: " + message);
        // You could also show a dialog:
        // JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    @Override
    public void dispose() {
        onSave.accept(saved);
        super.dispose();
    }
}
