package pos.models;

import java.util.ArrayList;
import java.util.List;

public class Quotation {
    public int id;
    public String quoteNo;
    public String customerName;
    public String status; // pending, accepted, rejected
    public double subtotal;
    public double discount;
    public double total;
    public List<QuotationItem> items = new ArrayList<>();
}
