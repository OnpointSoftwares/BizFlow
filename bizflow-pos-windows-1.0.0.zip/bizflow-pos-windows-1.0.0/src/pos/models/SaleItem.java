package pos.models;

public class SaleItem {
    public int id;
    public int saleId;
    public int productId;
    public String sku;
    public String name;
    public int qty;
    public double price;
    public double lineTotal;
}
