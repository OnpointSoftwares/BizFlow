# Java AWT POS System (SQLite)

A lightweight Point of Sale (POS) desktop application built in pure Java with AWT for the UI and SQLite for the database.

Features (v1):
- AWT modern-styled UI with custom tabs and rounded buttons
- Dashboard, Inventory, Sales, Invoices, Quotations, Reports sections (initial implementation for Inventory and Sales)
- SQLite database with schema migrations on first run
- Inventory: add, edit, delete products; search and low-stock indicator
- Sales: simple cart, search by name/SKU, barcode text input simulation, stock auto-updates after checkout
- Role-based login: Admin and Cashier (basic)
- Backup/restore utility (file copy)

Planned/Optional:
- PDF export for invoices/quotations (Apache PDFBox or iText)
- Charts for reports (JFreeChart)

Requirements:
- Java 11+ (AWT is part of JDK)
- SQLite JDBC driver jar (required): place in lib/
  - Download: https://github.com/xerial/sqlite-jdbc/releases (e.g., sqlite-jdbc-3.45.3.0.jar)
- jBCrypt (required for production-grade password hashing): place in lib/
  - Download: https://mvnrepository.com/artifact/org.mindrot/jbcrypt/0.4 (jbcrypt-0.4.jar)
- Optional jars (place in lib/ if you want advanced features):
  - Apache PDFBox (for PDF export): https://pdfbox.apache.org/download.html
  - JFreeChart (for charts): https://www.jfree.org/jfreechart/download.html

Project Structure:
- src/pos/... Java sources
- lib/ third-party jars (not committed)
- pos.db SQLite database (created on first run)

Build and Run (Linux/macOS):
1) Ensure you have a JDK installed (java -version)
2) Create lib/ and place both sqlite-jdbc-<version>.jar and jbcrypt-<version>.jar inside.
3) Build and run using the helper scripts:

   ./build.sh
   ./run.sh

Alternatively, compile manually:

   mkdir -p out
   javac -encoding UTF-8 -cp "lib/*" -d out $(find src -name "*.java")
   java -cp "out:lib/*" pos.Main

Notes:
- First run will create pos.db and all tables.
- Default users:
  - admin / admin (Admin)
  - cashier / cashier (Cashier)

Backups:
- Use the menu: File -> Backup DB (choose a destination)
- Restore by selecting a .db file via File -> Restore DB

Production readiness notes:
- Authentication: BCrypt password hashing via jBCrypt (12 rounds). Consider account lockouts and password policies.
- Authorization: Cashier role restricted to Sales & Invoices; extend checks per action in DAOs if needed.
- Data validation: Inventory prevents negative values; checkout verifies stock.
- Database: Foreign keys enabled; core indexes created; ensure regular backups.
- Packaging: Externalize configuration (paths, locale, currency), set logging.
- Auditing: Consider logs for sales/inventory mutations, sequence controls, and tax/VAT compliance.
